function redraw_figures(outdir, codever)

outdir = char(outdir);
while numel(outdir) > 3 && any(outdir(end) == '/\'), outdir(end) = []; end
f = fullfile(outdir, 'BUILD_COMPLETE.txt');
if exist(f, 'file') ~= 2
    error('run_everything:notComplete', ['%s holds no completed run (no BUILD_COMPLETE.txt).\n' ...
          'The figures-only mode redraws the figures of a COMPLETED run.'], outdir);
end
if exist(fullfile(outdir, 'BUILD_IN_PROGRESS.txt'), 'file') == 2
    error('run_everything:inProgress', '%s holds a run still in progress (BUILD_IN_PROGRESS.txt).', outdir);
end
done = strtrim(fileread(f));
t = regexp(done, 'version (\d+\.\d+\.\d+)', 'tokens', 'once');
ok = {'1.0.56', '1.0.57', '1.0.58', '1.0.59', '1.0.60', '1.0.61'};
if isempty(t), by = 'an unknown version'; else, by = ['version ' t{1}]; end
if isempty(t) || ~any(strcmp(t{1}, ok))
    error('run_everything:figuresVersion', ['%s was completed by %s; the figures of this code version read the results ' ...
          'of versions %s only.'], outdir, by, strjoin(ok, ', '));
end
diary(fullfile(outdir, sprintf('figures_log_%s.txt', datestr(now, 'yyyymmdd_HHMM'))));
c = onCleanup(@() diary('off'));
fprintf('FIGURES ONLY: dcmtwin version %s redraws every figure of the run in %s\n', codever, outdir);
fprintf('That run: %s\n', done);
fprintf('No result is recomputed and no result file is written; only the figures are (see redraw_figures).\n');
fd = fullfile(outdir, 'figures');  if ~exist(fd, 'dir'), mkdir(fd); end
old = [dir(fullfile(fd, '*.svg')); dir(fullfile(fd, 'validation', '*.svg')); ...
       dir(fullfile(fd, 'appendix_c', '*.svg')); dir(fullfile(outdir, 'ensemble_*.svg'))];
for k = 1:numel(old), delete(fullfile(old(k).folder, old(k).name)); end
fprintf('Removed %d earlier figure files.\n', numel(old));
t0 = tic;  bad = {};
step = @(s) fprintf('\n==== %s   (%.1f min)\n', s, toc(t0)/60);

step('validation figures (stage 2): recomputed exactly as stage 2 computes them');
bad = attempt(bad, 'validation, friction', @() validate_friction(fullfile(fd, 'validation')));
bad = attempt(bad, 'validation, bearing',  @() validate_bearing(fullfile(fd, 'validation')));
step('ensemble figures (stage 3)');
bad = attempt(bad, 'ensemble', @() plot_ensemble(outdir));
step('results figures and the adequacy table (stage 9)');
bad = attempt(bad, 'results figures', @() make_figures(outdir));
bad = attempt(bad, 'learning curves and mixed training', @() plot_learning_mixed(outdir));
step('onset figures (stage 10)');
bad = attempt(bad, 'onset', @() plot_onset_figures(outdir));
step('Appendix C and signal figures (stage 11)');
bad = attempt(bad, 'Appendix C', @() make_appendix_c_figures(fullfile(fd, 'appendix_c')));
bad = attempt(bad, 'signal figures', @() make_signal_figures(outdir));
step('integrated diagnosis tool (stage 13)');
bad = attempt(bad, 'integrated tool', @() plot_integrated(outdir));
step('hold-out test (stage 14)');
bad = attempt(bad, 'hold-out', @() plot_holdout(outdir));
step('sensitivity analysis (stage 15)');
bad = attempt(bad, 'sensitivity', @() plot_sensitivity(outdir));

now_ = [dir(fullfile(fd, '*.svg')); dir(fullfile(fd, 'validation', '*.svg')); ...
        dir(fullfile(fd, 'appendix_c', '*.svg')); dir(fullfile(outdir, 'ensemble_*.svg'))];
fid = fopen(fullfile(outdir, 'FIGURES_REDRAWN.txt'), 'a');
fprintf(fid, 'Figures redrawn %s by dcmtwin version %s: %d figures, from the results of the run completed by version %s.\n', ...
        datestr(now), codever, numel(now_), t{1});
fclose(fid);
step('done');
fprintf('%d figures drawn in %.1f min, recorded in FIGURES_REDRAWN.txt.\n', numel(now_), toc(t0)/60);
if isempty(bad)
    fprintf('No step failed.  Any single figure that could not be drawn is reported above by a line beginning ''skipped''.\n');
else
    fprintf('%d step(s) FAILED, each printed above after the word FAILED: %s\n', numel(bad), strjoin(bad, '; '));
end
end

function bad = attempt(bad, name, fn)
try
    fn();
catch err
    s = err.message;
    if ~isempty(err.stack), s = sprintf('%s (%s, line %d)', s, err.stack(1).name, err.stack(1).line); end
    fprintf('\nFAILED: %s: %s\n', name, s);
    bad{end+1} = name;
end
end
