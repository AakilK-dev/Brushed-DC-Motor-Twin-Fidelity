function make_appendix_c_figures(outdir)

if nargin < 1 || isempty(outdir), outdir = fullfile(pwd, 'appendix_c_figures'); end
if ~exist(outdir, 'dir'), mkdir(outdir); end
p = params_default();  S = fig_style();

dunker_J = [1800 3200];   % Dunkermotoren GR 80x40 and GR 80x80 data sheets
dunker_m = [2.8  4.0];   % Dunkermotoren GR 80x40 and GR 80x80 data sheets
sd320_pair_packed = 37*0.45359;   % SuperDroid Robots, TD-311-000 product listing
ec82_200_pair_packed = 10.7;   % Electronics Panga, product listing
brake_cont = 75;   % Magtrol, HB/MHB data sheet
isoG = [2.5 6.3];   % ISO 1940-1:2003
% Abdullah et al., IJEECS, vol. 27, no. 2, pp. 592-600, 2022, Table 4
wA = [23.35 53.19 82.61 112.13 142.71 169.72 206.78 224.27 261.75 288.66 320.07 348.55];
TA = [0.0228 0.0270 0.0305 0.0338 0.0362 0.0395 0.0400 0.0438 0.0437 0.0449 0.0460 0.0475];
r_rot = 0.025;
r_pin = 0.005;  phi = 20;

[fig, ax] = new_figure();
slope = diff(dunker_m)/diff(dunker_J);  m_ext = dunker_m(2) + slope*(4600 - dunker_J(2));
check(m_ext, p.M, 'rigid-body modal mass from the Dunkermotoren line');
xs = linspace(1500, 4900, 50);
h(4) = plot(ax, [1500 4900], sd320_pair_packed/2*[1 1], ':', 'Color', S.black, 'LineWidth', S.ref);
h(5) = plot(ax, [1500 4900], ec82_200_pair_packed/2*[1 1], '-.', 'Color', S.dark, 'LineWidth', S.ref);
h(1) = plot(ax, xs, dunker_m(1) + slope*(xs - dunker_J(1)), '--', 'Color', S.dark, 'LineWidth', S.ref);
h(2) = plot(ax, dunker_J, dunker_m, 'o', 'Color', S.black, 'MarkerFaceColor', S.black, 'MarkerSize', S.marker);
h(3) = errorbar(ax, 4600, p.M, p.M - p.M_range(1), p.M_range(2) - p.M, 's');
set(h(3), 'Color', S.black, 'MarkerFaceColor', S.black, 'MarkerSize', S.marker, 'LineWidth', S.line);
xlim(ax, [1500 4900]);  ylim(ax, [0 16]);
style_axes(ax, 'Rotor inertia (g·cm²)', 'Mass (kg)');
style_legend(legend(ax, h, {'Dunkermotoren line, extended', 'Dunkermotoren GR 80x40, GR 80x80', ...
    sprintf('Adopted %.1f kg, range %.1f to %.1f kg', p.M, p.M_range(1), p.M_range(2)), ...
    '320 W gearmotor with brake, packed, each', '200 W EC82 gearmotor, packed, each'}, ...
    'Location', 'northwest'));
save_figure(fig, fullfile(outdir, 'Figure_C1_motor_mass_against_inertia'));  close(fig);  clear h

gpdf = @(z) exp(-z.^2/2)/sqrt(2*pi);  gsf = @(d) 0.5*erfc(d/sqrt(2));
ds = linspace(0.25, 3.0, 23);  cv = zeros(size(ds));
for k = 1:numel(ds)
    d  = ds(k);  pc = gsf(d);
    m1 = integral(@(z) (z - d).^1.5.*gpdf(z), d, Inf)/pc;
    m2 = integral(@(z) (z - d).^3.0.*gpdf(z), d, Inf)/pc;
    cv(k) = sqrt(m2/m1^2 - 1);
end
[fig, ax] = new_figure();
h(1) = plot(ax, ds, cv, '-', 'Color', S.black, 'LineWidth', S.line);
h(2) = plot(ax, [0 3.1], p.brg.cv*[1 1], '--', 'Color', S.dark, 'LineWidth', S.ref);
xlim(ax, [0 3.1]);  ylim(ax, [0 1.8]);
style_axes(ax, 'Separation over summit height deviation, d/s', 'Coefficient of variation of summit force');
style_legend(legend(ax, h, {'Derived: Gaussian summits, Hertzian contact', sprintf('Adopted, c_v = %.1f', p.brg.cv)}, 'Location', 'southeast'));
save_figure(fig, fullfile(outdir, 'Figure_C2_summit_force_spread'));  close(fig);  clear h

th = linspace(0, 2*pi, 200001);  Cs = [8 10 12 16 20 24 32 40 48];  rip = zeros(size(Cs));
for i = 1:numel(Cs)
    e = zeros(size(th));
    for k = 0:Cs(i) - 1, e = e + abs(sin(th + 2*pi*k/Cs(i))); end
    rip(i) = 100*(max(e) - min(e))/2/mean(e);
end
[fig, ax] = new_figure();
set(ax, 'XScale', 'log', 'YScale', 'log');
h(1) = plot(ax, Cs, rip, 'o-', 'Color', S.black, 'MarkerFaceColor', S.black, 'MarkerSize', S.marker, 'LineWidth', S.line);
i24 = find(Cs == p.nbars);
h(2) = plot(ax, Cs(i24), rip(i24), 's', 'Color', S.black, 'MarkerFaceColor', 'w', 'MarkerSize', 12, 'LineWidth', 2);
h(3) = plot(ax, [7 52], 100*p.eps_c*[1 1], '--', 'Color', S.dark, 'LineWidth', S.ref);
xlim(ax, [7 52]);  ylim(ax, [0.08 20]);
set(ax, 'XTick', [8 12 16 24 32 48], 'YTick', [0.1 0.2 0.5 1 2 5 10 20], ...
    'YTickLabel', {'0.1','0.2','0.5','1','2','5','10','20'}, 'XTickLabel', {'8','12','16','24','32','48'});
style_axes(ax, 'Number of commutator bars', 'EMF ripple, half-amplitude (% of mean)');
style_legend(legend(ax, h, {'Derived: ideal winding, sinusoidal field', sprintf('%d bars: %.2f%%', p.nbars, rip(i24)), ...
    sprintf('Adopted surrogate depth, %.1f%%', 100*p.eps_c)}, 'Location', 'northeast'));
save_figure(fig, fullfile(outdir, 'Figure_C3_commutation_ripple'));  close(fig);  clear h

m_rot = 2*p.J/r_rot^2;  Wr = m_rot*p.g;
TL = p.TLfrac*p.Kt*p.Irated;  Fs = TL/r_pin*tand(phi);
Wb_row = Wr/4;  Ws_row = (Wr/2 + Fs)/2;
check(Wb_row, p.brg.W, 'bench bearing load per row');  check(Ws_row, p.brg.W_svc, 'service bearing load per row');
[fig, ax] = new_figure();  axis(ax, [0 10 0 7]);  axis(ax, 'off');
plot(ax, [0.6 8.87], [3.5 3.5], '-', 'Color', S.black, 'LineWidth', 4);
rectangle(ax, 'Position', [3.4 2.6 3.2 1.8], 'FaceColor', S.fill, 'EdgeColor', S.black, 'LineWidth', 1.5);
text(ax, 5.0, 3.5, sprintf('rotor\n%.2f kg', m_rot), 'HorizontalAlignment', 'center', 'FontSize', 16, 'FontWeight', 'bold');
xb = [1.6 8.0];  lbl = {'non-drive end', 'drive end'};  xl = [1.6 7.75];
for k = 1:2
    rectangle(ax, 'Position', [xb(k)-0.35 2.95 0.7 1.1], 'FaceColor', 'w', 'EdgeColor', S.black, 'LineWidth', 1.5);
    plot(ax, xb(k) + [-0.35 0.35], [2.95 4.05], '-', 'Color', S.black, 'LineWidth', 1.2);
    plot(ax, xb(k) + [-0.35 0.35], [4.05 2.95], '-', 'Color', S.black, 'LineWidth', 1.2);
    text(ax, xl(k), 4.35, lbl{k}, 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom', 'FontSize', 15, 'FontWeight', 'bold');
    arrow(ax, [xb(k) 1.5], [xb(k) 2.9], S.black);
end
rectangle(ax, 'Position', [8.42 3.15 0.45 0.7], 'FaceColor', S.dark, 'EdgeColor', S.black);
text(ax, 9.0, 3.5, 'pinion', 'FontSize', 15, 'FontWeight', 'bold');
arrow(ax, [5.0 2.55], [5.0 1.15], S.black);
text(ax, 5.15, 1.3, sprintf('weight %.1f N', Wr), 'FontSize', 15, 'FontWeight', 'bold', 'VerticalAlignment', 'bottom');
text(ax, 1.6, 1.0, sprintf('%.2f N\n(%.2f N per row)', Wr/2, Wb_row), 'HorizontalAlignment', 'center', 'VerticalAlignment', 'top', 'FontSize', 14, 'FontWeight', 'bold');
text(ax, 8.0, 1.0, sprintf('bench %.2f N\nservice %.1f N\n(%.2f and %.2f N per row)', Wr/2, Wr/2 + Fs, Wb_row, Ws_row), ...
     'HorizontalAlignment', 'center', 'VerticalAlignment', 'top', 'FontSize', 14, 'FontWeight', 'bold');
arrow(ax, [8.645 5.55], [8.645 3.9], S.dark);
text(ax, 7.6, 5.7, sprintf('service only: pinion separating force %.1f N\n(%.3f N·m over a %.0f mm pinion radius, %.0f°)', Fs, TL, 1e3*r_pin, phi), ...
     'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom', 'FontSize', 14, 'FontWeight', 'bold', 'Color', S.dark);
save_figure(fig, fullfile(outdir, 'Figure_C4_bearing_loads'));  close(fig);

w_max = p.nNL*2*pi/60;  mr = linspace(0, 3e-5, 50);  G = mr/m_rot*w_max*1e3;
[fig, ax] = new_figure();
h(1) = patch(ax, [5 25 25 5], [0 0 12 12], S.fill, 'EdgeColor', 'none');
h(2) = plot(ax, mr*1e6, G, '-', 'Color', S.black, 'LineWidth', S.line);
h(3) = plot(ax, [0 30], isoG(1)*[1 1], ':', 'Color', S.dark, 'LineWidth', S.ref);
h(4) = plot(ax, [0 30], isoG(2)*[1 1], '--', 'Color', S.dark, 'LineWidth', S.ref);
xlim(ax, [0 30]);  ylim(ax, [0 12]);  set(ax, 'Layer', 'top');
style_axes(ax, 'Imbalance, mass-radius product (g·mm)', 'Balance quality grade, e·Ω (mm/s)');
style_legend(legend(ax, h, {'Study range', sprintf('Imbalance grade (%.2f kg rotor, %.0f rad/s)', m_rot, w_max), ...
    'G 2.5', 'G 6.3: motors, shaft height < 80 mm'}, 'Location', 'northwest'));
save_figure(fig, fullfile(outdir, 'Figure_C5_imbalance_grades'));  close(fig);  clear h

s = linspace(0, 32, 50);
[fig, ax] = new_figure();
h(1) = patch(ax, [0 32 32 0], [0 0 p.th.rise p.th.rise], S.fill, 'EdgeColor', 'none');
h(2) = plot(ax, s, s/100/p.alpha, '-', 'Color', S.black, 'LineWidth', S.line);
h(3) = plot(ax, [2 2], [0 105], '--', 'Color', S.dark, 'LineWidth', S.ref);
plot(ax, [30 30], [0 105], '--', 'Color', S.dark, 'LineWidth', S.ref);
xlim(ax, [0 32]);  ylim(ax, [0 105]);  set(ax, 'Layer', 'top');
style_axes(ax, 'Resistance rise from the fault (%)', 'Equivalent temperature change (°C)');
lg = legend(ax, h, {'Normal thermal range', sprintf('Equivalent temperature, α = %.3f /°C', p.alpha), 'Study range, 2 to 30%'}, 'Location', 'northwest');
style_legend(lg);  drawnow;  pos = get(lg, 'Position');  pos(1) = pos(1) + 0.05;  set(lg, 'Position', pos);
save_figure(fig, fullfile(outdir, 'Figure_C6_resistive_against_temperature'));  close(fig);  clear h

wl = @(dd) (p.Kt*dd*p.Vs/p.R - p.Tc - TL)./(p.Kt*p.Ke/p.R + p.b);
Pb = @(dd) TL*wl(dd);
d = linspace(0.3, 1.0, 50);  dd = [0.4 0.6 0.8];
[fig, ax] = new_figure();
h(1) = plot(ax, 100*d, Pb(d), '-', 'Color', S.black, 'LineWidth', S.line);
h(2) = plot(ax, 100*dd, Pb(dd), 'o', 'Color', S.black, 'MarkerFaceColor', S.black, 'MarkerSize', S.marker);
h(3) = plot(ax, [30 100], brake_cont*[1 1], '--', 'Color', S.dark, 'LineWidth', S.ref);
xlim(ax, [30 100]);  ylim(ax, [0 90]);
style_axes(ax, 'Duty (%)', 'Brake power (W)');
style_legend(legend(ax, h, {sprintf('Power absorbed at %.0f%% load', 100*p.TLfrac), 'Study duties, 40, 60, 80%', ...
    sprintf('HB-140M-2 continuous rating, %.0f W', brake_cont)}, 'Location', 'southeast'));
save_figure(fig, fullfile(outdir, 'Figure_C7_brake_power_against_duty'));  close(fig);  clear h
d75 = fzero(@(x) Pb(x) - brake_cont, [0.5 1.0]);

w_ref = p.w_ref;  Tc_ref = p.fr.Tc_ref;  b_ref = p.fr.b_ref;
frac = Tc_ref/(Tc_ref + b_ref*w_ref);  check(frac*p.b_lin*w_ref, p.Tc, 'Coulomb torque');
bv = (wA*TA')/(wA*wA');  xin = linspace(0, wA(end), 50);  xout = linspace(wA(end), w_ref, 20);
[fig, ax] = new_figure();
h(1) = plot(ax, wA, 1e3*TA, 'o', 'Color', S.black, 'MarkerFaceColor', S.black, 'MarkerSize', S.marker);
h(2) = plot(ax, xin, 1e3*(Tc_ref + b_ref*xin), '-', 'Color', S.black, 'LineWidth', S.line);
h(3) = plot(ax, xout, 1e3*(Tc_ref + b_ref*xout), ':', 'Color', S.black, 'LineWidth', 2.2);
h(4) = plot(ax, [0 360], 1e3*bv*[0 360], '--', 'Color', S.dark, 'LineWidth', S.ref);
h(5) = plot(ax, [0 w_ref], 1e3*Tc_ref*[1 1], '-.', 'Color', S.dark, 'LineWidth', S.ref);
h(6) = plot(ax, w_ref, 1e3*(Tc_ref + b_ref*w_ref), 's', 'Color', S.black, 'MarkerFaceColor', 'w', 'MarkerSize', 11, 'LineWidth', 2);
xlim(ax, [0 500]);  ylim(ax, [0 115]);
style_axes(ax, 'Speed (rad/s)', 'No-load torque (mN·m)');
style_legend(legend(ax, h, {'Measured (Abdullah et al.)', 'Coulomb plus viscous, fitted', ...
    'Extrapolated beyond the data', 'Viscous only', sprintf('Coulomb part, %.1f mN·m', 1e3*Tc_ref), ...
    sprintf('Split at %.0f rad/s: %.1f%% Coulomb', w_ref, 100*frac)}, 'Location', 'northwest'));
save_figure(fig, fullfile(outdir, 'Figure_C8_friction_structure'));  close(fig);  clear h

Pshaft = @(i) p.Kt*i.*(p.Vs - i*p.R)/p.Ke - p.b_lin*((p.Vs - i*p.R)/p.Ke).^2;
iNL = p.b_lin*p.w_ref/p.Kt;
Ir  = fzero(@(i) Pshaft(i) - p.Prated, [5 40]);
I300 = fzero(@(i) Pshaft(i) - 300, [5 40]);
check(Ir, p.Irated, 'rated current from the rated power');
wr = (p.Vs - Ir*p.R)/p.Ke;
ii = linspace(iNL, 22, 200);  i3 = 3;
[fig, ax] = new_figure();
h(1) = plot(ax, ii, Pshaft(ii), '-', 'Color', S.black, 'LineWidth', S.line);
h(2) = plot(ax, [0 22], p.Prated*[1 1], ':', 'Color', S.black, 'LineWidth', S.ref);
h(3) = plot(ax, i3, Pshaft(i3), 'o', 'Color', S.black, 'MarkerFaceColor', 'w', 'MarkerSize', 11, 'LineWidth', 2);
h(4) = plot(ax, Ir, p.Prated, 's', 'Color', S.black, 'MarkerFaceColor', S.black, 'MarkerSize', 11);
xlim(ax, [0 22]);  ylim(ax, [0 600]);
style_axes(ax, 'Armature current (A)', 'Shaft power (W)');
style_legend(legend(ax, h, {'At 24 V, measured parameters', sprintf('Rated output, %.0f W', p.Prated), ...
    sprintf('Published 3 A: %.0f W', Pshaft(i3)), sprintf('Derived rated current, %.1f A', Ir)}, 'Location', 'northwest'));
save_figure(fig, fullfile(outdir, 'Figure_rated_current'));  close(fig);  clear h

fprintf('\nAppendix C figures, values for the text\n');
fprintf('C1  extended mass %.2f kg; adopted %.1f kg, range %.1f to %.1f kg; shipping weight each: 320 W gearmotor with brake %.2f kg, 200 W EC82 gearmotor %.2f kg\n', ...
        m_ext, p.M, p.M_range(1), p.M_range(2), sd320_pair_packed/2, ec82_200_pair_packed/2);
fprintf('C2  c_v %.2f to %.2f for d/s %.1f to %.1f\n', cv(find(ds >= 0.5, 1)), cv(end), 0.5, ds(end));
fprintf('C3  ripple at %d bars %.3f%%; adopted %.1f%%\n', p.nbars, rip(i24), 100*p.eps_c);
fprintf('C4  rotor %.2f kg, weight %.2f N, pinion force %.2f N; per row bench %.2f N, service %.2f N\n', m_rot, Wr, Fs, Wb_row, Ws_row);
fprintf('C5  study range spans G %.1f to G %.1f; G 6.3 limit %.2e kg.m\n', 5e-6/m_rot*w_max*1e3, 25e-6/m_rot*w_max*1e3, 6.3e-3*m_rot/w_max);
fprintf('C6  2%% = %.0f degC, 30%% = %.0f degC\n', 0.02/p.alpha, 0.30/p.alpha);
fprintf('C7  brake power at 40, 60, 80%% duty: %.1f, %.1f, %.1f W; rating reached at %.1f%% duty\n', Pb(0.4), Pb(0.6), Pb(0.8), 100*d75);
fprintf('C8  Coulomb fraction %.1f%% at %.1f rad/s, %.0f%% beyond the fastest measurement\n', 100*frac, w_ref, 100*(w_ref/wA(end) - 1));
fprintf(['3.3.1  at 3 A: shaft %.1f W from %.0f W input; no-load %.3f A at %.1f rad/s (%.0f rpm, %.1f%% below %d rpm);\n' ...
         '       rated %.2f A at %.1f rad/s, efficiency %.1f%%, rated torque %.4f N.m, %.0f%% load %.1f mN.m; at 300 W %.2f A (%.1f%% lower)\n\n'], ...
        Pshaft(i3), p.Vs*i3, iNL, p.w_ref, p.w_ref*60/(2*pi), 100*(1 - p.w_ref*60/(2*pi)/p.nNL), p.nNL, ...
        Ir, wr, 100*p.Prated/(p.Vs*Ir), p.Kt*Ir, 100*p.TLfrac, 1e3*p.TLfrac*p.Kt*Ir, I300, 100*(1 - I300/Ir));
end

function arrow(ax, p0, p1, col)
plot(ax, [p0(1) p1(1)], [p0(2) p1(2)], '-', 'Color', col, 'LineWidth', 2.2);
u = (p1 - p0)/norm(p1 - p0);  n = [-u(2) u(1)];  L = 0.25;  W = 0.11;
tri = [p1; p1 - L*u + W*n; p1 - L*u - W*n];
patch(ax, tri(:,1), tri(:,2), col, 'EdgeColor', col);
end

function check(derived, used, name)
if abs(derived - used) > 0.01*abs(used)
    warning('appendixC:mismatch', '%s: rederived %.4g, parameter file %.4g', name, derived, used);
else
    fprintf('consistent with the parameter file: %s (%.4g)\n', name, used);
end
end
