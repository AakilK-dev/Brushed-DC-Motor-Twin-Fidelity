function make_figures(outdir)

fd = fullfile(outdir, 'figures');  if ~exist(fd, 'dir'), mkdir(fd); end
S = fig_style();  p = params_default();
cls  = {'normal', 'resistive', 'shorted_bar', 'bearing_outer', 'imbalance'};
lab  = {'Normal', 'Resistive', 'Shorted bar', 'Bearing defect', 'Imbalance'};
mk   = {'o', 's', '^', 'd', 'x'};
F3 = []; F2 = [];
try, F3 = load_ft(outdir, 3); catch err, fprintf('no reference features: %s\n', err.message); end
try, F2 = load_ft(outdir, 2); catch err, fprintf('no Model 2 features: %s\n', err.message); end
try
    T  = F3.B.T2;
    kn = is_state(T.state, 'normal');  kr = is_state(T.state, 'resistive');
    ks = is_state(T.state, 'shorted_bar');
    kb = is_state(T.state, 'bearing_outer');  ki = is_state(T.state, 'imbalance');
    R  = 100*T.B_R;  Ke = 100*T.B_Ke;
    [fig, ax] = new_figure();
    hn = plot(ax, R(kn), Ke(kn), 'o', 'Color', S.light, 'MarkerSize', S.marker, 'LineWidth', 1.2);
    hr = plot(ax, R(kr), Ke(kr), 's', 'Color', S.dark, 'MarkerFaceColor', S.dark, 'MarkerSize', S.marker);
    m  = max(1, ceil(20*max(abs(Ke(kn | kr))))/10);
    xlim(ax, [-2, 5*ceil(max(R(kr))/5)]);  ylim(ax, [-m m]);
    style_axes(ax, 'Change in estimated resistance (%)', 'Change in estimated K_e (%)');
    style_legend(legend(ax, [hn hr], {'Normal', 'Resistive'}, 'Location', 'northeast'));
    save_figure(fig, fullfile(fd, 'fig_fingerprint_resistive'));  close(fig);
    fprintf(['written: fig_fingerprint_resistive (Ke change: resistive runs %+.3f to %+.3f%%, ' ...
             'normal runs %+.3f to %+.3f%%; y-range +/-%.1f%%)\n'], min(Ke(kr)), max(Ke(kr)), min(Ke(kn)), max(Ke(kn)), m);
    [fig, ax] = new_figure();
    v  = [R(kn | ks); Ke(kn | ks)];
    lo = floor(2*min(v))/2 - 0.5;  hi = ceil(2*max(v))/2 + 0.5;
    he = plot(ax, [lo hi], [lo hi], '--', 'Color', S.dark, 'LineWidth', S.ref);
    hn = plot(ax, R(kn), Ke(kn), 'o', 'Color', S.light, 'MarkerSize', S.marker, 'LineWidth', 1.2);
    hs = plot(ax, R(ks), Ke(ks), '^', 'Color', S.black, 'MarkerSize', S.marker, 'LineWidth', 1.2);
    xlim(ax, [lo hi]);  ylim(ax, [lo hi]);  set(ax, 'DataAspectRatio', [1 1 1]);
    style_axes(ax, 'Change in estimated resistance (%)', 'Change in estimated K_e (%)');
    style_legend(legend(ax, [hn hs he], {'Normal', 'Shorted bar', 'Equal change'}, 'Location', 'southeast'));
    save_figure(fig, fullfile(fd, 'fig_fingerprint_shorted'));  close(fig);
    fprintf('written: fig_fingerprint_shorted (median change R %+.2f%%, Ke %+.2f%%; both axes %g to %g%%)\n', ...
            median(R(ks)), median(Ke(ks)), lo, hi);
    fprintf('  not drawn, median change in R and Ke: bearing %+.3f%%, %+.3f%%; imbalance %+.3f%%, %+.3f%%; normal %+.3f%%, %+.3f%%\n', ...
            median(R(kb)), median(Ke(kb)), median(R(ki)), median(Ke(ki)), median(R(kn)), median(Ke(kn)));
catch err, fprintf('skipped fingerprint: %s\n', err.message); end
try
    [fig, ax] = new_figure();
    T2 = F2.A;  T3 = F3.A;
    k2 = is_state(T2.state, 'imbalance');  k3 = is_state(T3.state, 'imbalance');
    plot(ax, 1e3*T2.A_v1(k2), exp(T2.A_vrms(k2)), 'o', 'Color', S.black, 'MarkerSize', S.marker, 'LineWidth', 1.2, 'DisplayName', 'Model 2');
    plot(ax, 1e3*T3.A_v1(k3), exp(T3.A_vrms(k3)), 's', 'Color', S.dark, 'MarkerFaceColor', S.dark, 'MarkerSize', S.marker, 'DisplayName', 'Reference (Model 3)');
    set(ax, 'YScale', 'log');
    style_axes(ax, 'Once-per-revolution vibration (mg)', 'Vibration level relative to baseline');
    style_legend(legend(ax, 'Location', 'northwest'));
    save_figure(fig, fullfile(fd, 'fig_imbalance_mechanism'));  close(fig);
    fprintf('written: fig_imbalance_mechanism\n');
catch err, fprintf('skipped imbalance mechanism: %s\n', err.message); end
try
    T = F3.A;  k6 = T.duty == 0.6;
    q = p;  q.theta = 35;  V = 0.6*p.Vs;  TL = p.TLfrac*p.Kt*p.Irated;  [w0, i0] = op_point(q, V, TL);
    sb = p.brake.reg*p.brake.Tfs/3;
    [wa, ia] = op_point(q, V, TL - 3*sb);  [wb, ib] = op_point(q, V, TL + 3*sb);
    bx = 100*([ia ib]/i0 - 1);  by = 100*([wa wb]/w0 - 1);
    smin = 1/(1 + p.sc.range(2));  smax = 1/(1 + p.sc.range(1));
    fl = {'resistive', linspace(0, 0.30, 31);  'shorted_bar', linspace(0, 1, 31);  'bearing_outer', linspace(0, 1, 31)};
    Pd = cell(1, 3);  E = zeros(3, 2);
    for f = 1:3
        sv = fl{f,2};  di = zeros(size(sv));  dw = di;
        for j = 1:numel(sv)
            s = sv(j);
            if strcmp(fl{f,1}, 'shorted_bar')
                s = min(max(1/(smin + s*(smax - smin)) - 1, p.sc.range(1)), p.sc.range(2));
            end
            [wj, ij] = op_point(apply_fault(q, fl{f,1}, s), V, TL);
            di(j) = 100*(ij/i0 - 1);  dw(j) = 100*(wj/w0 - 1);
        end
        Pd{f} = [di(:) dw(:)];  E(f,:) = [di(end) dw(end)];
    end
    xs = [100*T.A_cur(k6); E(:,1); bx(:)];  ys = [100*T.A_spv(k6); E(:,2); by(:)];
    xl = [min(xs) max(xs)] + [-0.08 0.08]*(max(xs) - min(xs));  yl = [min(ys) max(ys)] + [-0.10 0.10]*(max(ys) - min(ys));
    files = {'resistive', 'shorted_bar', 'bearing', 'imbalance'};
    where = {'northeast', 'southeast', 'northeast', 'northeast'};
    kn = k6 & is_state(T.state, 'normal');
    for f = 1:4
        [fig, ax] = new_figure();
        hb = plot(ax, bx, by, '-', 'Color', S.grid, 'LineWidth', 14);
        hn = plot(ax, 100*T.A_cur(kn), 100*T.A_spv(kn), 'o', 'Color', S.light, 'MarkerSize', S.marker, 'LineWidth', 1.2);
        kf = k6 & is_state(T.state, cls{f+1});
        hf = plot(ax, 100*T.A_cur(kf), 100*T.A_spv(kf), mk{f+1}, 'Color', S.black, 'MarkerSize', S.marker, ...
                  'LineWidth', 1.2, 'MarkerFaceColor', ifelse(f == 1, S.black, 'none'));
        h = [hn hf];  hl = {'Normal', lab{f+1}};
        if f <= 3
            h(end+1) = plot(ax, Pd{f}(:,1), Pd{f}(:,2), '--', 'Color', S.black, 'LineWidth', S.line);
            hl{end+1} = 'Predicted at 60% duty';
        end
        h(end+1) = hb;  hl{end+1} = 'Brake offset, \pm3\sigma_{brk}';
        xlim(ax, xl);  ylim(ax, yl);
        style_axes(ax, 'Change in mean current (%)', 'Change in speed per volt (%)');
        style_legend(legend(ax, h, hl, 'Location', where{f}));
        save_figure(fig, fullfile(fd, ['fig_operating_point_map_' files{f}]));  close(fig);
    end
    fprintf(['written: fig_operating_point_map_resistive, _shorted_bar, _bearing, _imbalance (60%% duty: predicted ends, ', ...
             'current and speed: resistive %+.2f, %+.2f; shorted bar %+.2f, %+.2f; bearing %+.2f, %+.2f; ', ...
             'brake offset +/-3 sd %+.2f, %+.2f)\n'], E', bx(2), by(2));
    for c = 1:5
        k = k6 & is_state(T.state, cls{c});
        fprintf('  %-14s median current %+6.2f%%, speed per volt %+6.2f%%; sd %5.2f, %5.2f\n', lab{c}, ...
                100*median(T.A_cur(k)), 100*median(T.A_spv(k)), 100*std(T.A_cur(k)), 100*std(T.A_spv(k)));
    end
catch err, fprintf('skipped operating-point map: %s\n', err.message); end
G = [];
try, L = load(fullfile(outdir, 'results', 'grid.mat'), 'G');  G = L.G; catch, fprintf('no grid results: grid figures skipped\n'); end
if ~isempty(G)
    try
        spec = {'within 3->3', 'Within the reference', 'fig_recall_resistive_within';
                'forward 2->3', 'From Model 2',        'fig_recall_resistive_forward2'};
        mth = {'RF A', 'RF A+B'};  st = {'--', '-'};  mkr = {'o', 's'};  cl = {S.dark, S.black};  fc = {'w', S.black};
        e = linspace(2, 30, 8);  xc = (e(1:end-1) + e(2:end))/2;
        for c = 1:2
            [fig, ax] = new_figure();  h = [];
            for m = 1:2
                g = pick(G, spec{c,1}, mth{m});
                k = is_state(g.ytrue, 'resistive');  s = 100*g.sev(k);  ok = is_state(g.ypred(k), 'resistive');
                rc = nan(size(xc));
                for b = 1:numel(xc), in = s >= e(b) & s <= e(b+1); rc(b) = 100*mean(ok(in)); end
                h(end+1) = plot(ax, xc, rc, 'LineStyle', st{m}, 'Marker', mkr{m}, 'Color', cl{m}, 'LineWidth', S.line, ...
                                'MarkerSize', S.marker, 'MarkerFaceColor', fc{m});
                fprintf('  recall, resistive, %s, %s: %s %% by severity bin\n', spec{c,1}, mth{m}, sprintf('%.0f ', rc));
            end
            xlim(ax, [0 30]);  ylim(ax, [40 102]);
            style_axes(ax, 'Resistive fault severity, resistance increase (%)', 'Recall (%)');
            style_legend(legend(ax, h, {[spec{c,2} ', Set A'], [spec{c,2} ', Set A+B']}, 'Location', 'southeast'));
            save_figure(fig, fullfile(fd, spec{c,3}));  close(fig);
        end
        fprintf('written: fig_recall_resistive_within, fig_recall_resistive_forward2\n');
    catch err, fprintf('skipped recall figures: %s\n', err.message); end
    try
        meth = {'RF A', 'RF A+B', 'SVM A', 'SVM A+B', 'Rule'};
        four = {'within 1->1', 'within 1 to 1';  'SHARED 4: within 2->2', 'within 2 to 2';  'SHARED 4: within 3->3', 'within 3 to 3';
                'forward 1->3', 'forward 1 to 3';  'SHARED 4: forward 2->3', 'forward 2 to 3';
                'reverse 3->1', 'reverse 3 to 1';  'SHARED 4: reverse 3->2', 'reverse 3 to 2'};
        five = {'within 2->2', 'within 2 to 2';  'within 3->3', 'within 3 to 3';  'within 3->3 (Model 1 filter)', 'within 3 to 3, filter 1';
                'forward 2->3', 'forward 2 to 3';  'reverse 3->2', 'reverse 3 to 2'};
        grid_heatmap(G, four, meth, false, fullfile(fd, 'fig_grid_accuracy_four'), S);
        grid_heatmap(G, five, meth, true,  fullfile(fd, 'fig_grid_accuracy_five'), S);
        fprintf('written: fig_grid_accuracy_four (7 cells), fig_grid_accuracy_five (5 cells; filter 1 = Set B from Model 1''s filter)\n');
    catch err, fprintf('skipped heatmaps: %s\n', err.message); end
    for mth = {'RF A', 'RF A+B'}
        try
            g = pick(G, 'forward 2->3', mth{1});  C = g.m.C;
            [fig, ax] = new_figure();
            imagesc(ax, C./sum(C,2), [0 1]);  colormap(ax, flipud(gray(256))*0.85 + 0.15);
            for i = 1:size(C,1), for j = 1:size(C,2)
                text(ax, j, i, sprintf('%d', C(i,j)), 'HorizontalAlignment', 'center', 'FontSize', S.tick, ...
                     'FontWeight', 'bold', 'Color', ifelse(C(i,j)/sum(C(i,:)) > 0.5, 'w', 'k'));
            end, end
            set(ax, 'XTick', 1:5, 'XTickLabel', lab, 'YTick', 1:5, 'YTickLabel', lab, 'YDir', 'reverse');
            style_axes(ax, 'Predicted', 'True');  grid(ax, 'off');  axis(ax, 'tight');
            nm = ['fig_confusion_forward2_' strrep(strrep(mth{1}, ' ', ''), '+', 'plus')];
            save_figure(fig, fullfile(fd, nm));  close(fig);
            fprintf('written: %s\n', nm);
        catch err, fprintf('skipped confusion: %s\n', err.message); end
    end
end
try
    T = F3.A;  B2 = F3.B.T2;  B1 = F3.B.T1;
    rng_ = [0.02 0.30; 0.1 1; 0.05 1; 5e-6 2.5e-5];
    one = {'resistive', 1, B2, 'Resistive, Model 2''s filter', 's', 'fig_severity_physics_resistive';
           'bearing_outer', 3, B2, 'Bearing, Model 2''s filter', 'd', 'fig_severity_physics_bearing';
           'bearing_outer', 3, B1, 'Bearing, Model 1''s filter', 'p', 'fig_severity_physics_bearing_model1';
           'imbalance', 4, B2, 'Imbalance', 'x', 'fig_severity_physics_imbalance'};
    yl = [-0.25 1.25];  yin = 0.025*(yl(2) - yl(1));
    for r = 1:size(one, 1)
        f = one{r,2};  k = is_state(T.state, one{r,1});  s = T.severity(k);
        sh = physics(one{r,1}, rows_of(T, k), rows_of(one{r,3}, k), p);
        nrm = @(x) (x - rng_(f,1))/(rng_(f,2) - rng_(f,1));
        xs = nrm(s(:));  ys = nrm(sh(:));
        up = isfinite(xs) & ys > yl(2);  dn = isfinite(xs) & ys < yl(1);  in = isfinite(xs) & isfinite(ys) & ~up & ~dn;
        [fig, ax] = new_figure();
        h2 = plot(ax, [0 1], [0 1], '-', 'Color', S.dark, 'LineWidth', S.ref);
        h1 = plot(ax, xs(in), ys(in), one{r,5}, 'Color', S.black, 'MarkerSize', S.marker - 2, 'LineWidth', 1.2);
        h = [h1 h2];  hl = {one{r,4}, 'Estimate equals truth'};
        if any(up)
            h(end+1) = plot(ax, xs(up), (yl(2) - yin)*ones(nnz(up), 1), '^', 'Color', S.black, ...
                            'MarkerFaceColor', 'none', 'MarkerSize', S.marker, 'LineWidth', 1.2);
            hl{end+1} = sprintf('Above the axis: %d', nnz(up));
        end
        if any(dn)
            h(end+1) = plot(ax, xs(dn), (yl(1) + yin)*ones(nnz(dn), 1), 'v', 'Color', S.black, ...
                            'MarkerFaceColor', 'none', 'MarkerSize', S.marker, 'LineWidth', 1.2);
            hl{end+1} = sprintf('Below the axis: %d', nnz(dn));
        end
        xlim(ax, [-0.05 1.05]);  ylim(ax, yl);
        style_axes(ax, 'True severity, fraction of its range', 'Physics estimate, fraction of range');
        lg = legend(ax, h, hl, 'Location', 'northoutside');
        try, set(lg, 'NumColumns', 1 + (numel(h) > 2), 'Orientation', 'vertical'); catch, end
        style_legend(lg);
        drawnow;  pl = get(lg, 'Position');
        if pl(1) < 0 || pl(1) + pl(3) > 1
            fprintf('  warning: the legend of %s is wider than the canvas\n', one{r,6});
        end
        save_figure(fig, fullfile(fd, one{r,6}));  close(fig);
        e = ys - xs;  e = e(isfinite(e));
        fprintf(['written: %s (%d runs; error median %+.3f, mean absolute %.3f of the range; ' ...
                 '%d above and %d below the axis, drawn at its edge)\n'], one{r,6}, numel(e), median(e), ...
                mean(abs(e)), nnz(up), nnz(dn));
    end
catch err, fprintf('skipped severity figures: %s\n', err.message); end
sid = NaN;
try
    Ssn = load(fullfile(outdir, 'datasets', 'sessions.mat'), 'S');  Ssn = Ssn.S;  sid = Ssn.session(mid_session(Ssn));
    fprintf('feature figures: session %d (60%% duty, fault sizes nearest the middles of their ranges)\n', sid);
catch err, fprintf('no session plan: feature figures skipped (%s)\n', err.message); end
try
    L = load(fullfile(outdir, 'estimates', 'D3_T2', sprintf('session_%04d.mat', sid)), 'Z');  Z = L.Z;  o = Z.settings;
    Rb = Z.runs(1).final.R;
    y2 = 100*(Z.runs(2).x(:,4)/Rb - 1);  y3 = 100*(Z.runs(3).x(:,4)/Rb - 1);
    t2 = o.tStart + Z.runs(2).t;  t3 = o.tStart + Z.runs(3).t;  tA = t3(end) - o.tAvg;
    fR = 100*(Z.runs(3).final.R/Rb - 1);
    lo = min([y2; y3; 0]);  hi = max([y2; y3]);  pad = 0.12*(hi - lo);
    [fig, ax] = new_figure();
    patch(ax, [tA t3(end) t3(end) tA], [lo - pad, lo - pad, hi + pad, hi + pad], S.grid, 'EdgeColor', 'none', ...
          'HandleVisibility', 'off');
    plot(ax, t2, y2, '-', 'Color', S.light, 'LineWidth', S.line, 'DisplayName', 'Normal test run');
    plot(ax, t3, y3, '-', 'Color', S.black, 'LineWidth', S.line, ...
         'DisplayName', sprintf('Resistive fault, %.0f%% increase', 100*Z.runs(3).severity));
    plot(ax, [0 t3(end)], [fR fR], '--', 'Color', S.dark, 'LineWidth', S.ref, ...
         'DisplayName', sprintf('Mean over the shaded %.1f s: %+.1f%%', o.tAvg, fR));
    xlim(ax, [0 t3(end)]);  ylim(ax, [lo - pad, hi + pad]);
    style_axes(ax, 'Time in the run (s)', 'Estimated resistance change (%)');
    style_legend(legend(ax, 'Location', 'southeast'));
    save_figure(fig, fullfile(fd, 'fig_filter_resistance'));  close(fig);
    fprintf('written: fig_filter_resistance (B_R %+.2f%%; table %+.2f%%)\n', fR, ...
            100*feature_value(F3, sid, 'resistive', 'B_R', 2));
catch err, fprintf('skipped filter figure: %s\n', err.message); end
try
    L = load(fullfile(outdir, 'calibration.mat'), 'T');  T = L.T;
    ff = T.true_b/p.b;  eJ = 100*(T.M1_J./T.true_J - 1);  eJ2 = 100*(T.M2_J./T.true_J - 1);
    [fig, ax] = new_figure();
    xr = [min(ff) max(ff)] + [-0.03 0.03]*(max(ff) - min(ff));
    plot(ax, xr, [0 0], '-', 'Color', S.light, 'LineWidth', S.ref);
    h1 = plot(ax, ff, eJ, 'o', 'Color', S.dark, 'MarkerSize', S.marker - 3, 'LineWidth', 1.0);
    h2 = plot(ax, ff, eJ2, 's', 'Color', S.black, 'MarkerFaceColor', S.black, 'MarkerSize', S.marker - 4);
    xlim(ax, xr);
    style_axes(ax, 'Friction relative to nominal', 'Identified inertia error (%)');
    style_legend(legend(ax, [h1 h2], {'Model 1', 'Model 2'}, 'Location', 'northwest'));
    save_figure(fig, fullfile(fd, 'fig_calibration_inertia'));  close(fig);
    fprintf('written: fig_calibration_inertia (inertia error, median: Model 1 %+.1f%%, Model 2 %+.2f%%)\n', median(eJ), median(eJ2));
catch err, fprintf('skipped calibration figure: %s\n', err.message); end
try
    V = readtable(fullfile(outdir, 'adequacy_verdicts_service.csv'), 'TextType', 'string');
    cond = cellstr(V.condition);  fault = cellstr(V.fault);  level = cellstr(V.level);
    tw = double(V.twin);  ok = double(V.adequate_twin);  det = double(V.detectable);
    conds = unique(cond, 'stable');
    fls = {'resistive', 'shorted_bar', 'bearing_outer', 'imbalance'};  flab = {'Resistive', 'Shorted bar', 'Bearing defect', 'Imbalance'};
    levs = {'smallest', 'middle'};
    fid = fopen(fullfile(fd, 'table_adequacy.csv'), 'w');
    hd = {'fault', 'severity'};
    for c = 1:numel(conds)
        hd = [hd, strcat(conds{c}, {': Model 1 adequate (%)', ': Model 2 adequate (%)', ': detectable (%)'})];
    end
    fprintf(fid, '%s\n', strjoin(hd, ','));
    fprintf('\nADEQUACY: percentage of machines for which each twin is adequate (twin-supported verdict),\n');
    fprintf('and in which the fault is detectable at all (any channel), by condition\n');
    fprintf('%-16s %-9s', 'fault', 'severity');
    for c = 1:numel(conds), fprintf(' | %-12s %8s %8s %10s', conds{c}, 'Model 1', 'Model 2', 'detectable'); end
    fprintf('\n');
    for f = 1:4
        for l = 1:2
            row = {flab{f}, levs{l}};  fprintf('%-16s %-9s', flab{f}, levs{l});
            for c = 1:numel(conds)
                k = strcmp(cond, conds{c}) & strcmp(fault, fls{f}) & strcmp(level, levs{l});
                v1 = 100*mean(ok(k & tw == 1));  v2 = 100*mean(ok(k & tw == 2));  vd = 100*mean(det(k & tw == 2));
                if strcmp(fls{f}, 'imbalance'), s1 = 'not modelled'; else, s1 = sprintf('%.0f', v1); end
                row = [row, {s1, sprintf('%.0f', v2), sprintf('%.0f', vd)}];
                fprintf(' | %-12s %8s %8.0f %10.0f', '', s1, v2, vd);
            end
            fprintf(fid, '%s\n', strjoin(row, ','));  fprintf('\n');
        end
    end
    fclose(fid);
    fprintf('Model 1 has no vibration output, so it cannot represent imbalance: "not modelled".\n');
    fprintf('written: table_adequacy.csv (in place of the adequacy charts)\n\n');
catch err, fprintf('skipped the adequacy table: %s\n', err.message); end
try
    L = load(fullfile(outdir, 'datasets', 'M3', sprintf('session_%04d.mat', sid)), 'X');  X = L.X;
    [oN, An] = tsa_orders(X.runs(2).rec.cur, X.runs(2).rec.enc, 30);
    [oF, Af] = tsa_orders(X.runs(4).rec.cur, X.runs(4).rec.enc, 30);
    [~,  Ab] = tsa_orders(X.runs(1).rec.cur, X.runs(1).rec.enc, 2);
    [fig, ax] = new_figure();
    yl = [min(1e-2, 10^floor(log10(1e3*min([An; Af])))), 10^ceil(log10(1e3*max([An; Af])) + 0.5)];
    al = {'right', 'left', 'center'};  ox = [-0.25 0.25 0];
    for q = 1:3
        od = [1 2 24];  od = od(q);
        plot(ax, [od od], yl, '--', 'Color', S.light, 'LineWidth', S.ref, 'HandleVisibility', 'off');
        text(ax, od + ox(q), yl(2)/2.2, sprintf('%d\\times', od), 'HorizontalAlignment', al{q}, ...
             'FontSize', S.tick, 'FontWeight', 'bold', 'BackgroundColor', 'w');
    end
    stem(ax, oN - 0.15, 1e3*An, 'Color', S.blue, 'Marker', 'o', 'MarkerSize', S.marker - 2, ...
         'LineWidth', 1.2, 'BaseValue', yl(1), 'DisplayName', 'Normal');
    stem(ax, oF + 0.15, 1e3*Af, 'Color', S.orange, 'Marker', 's', 'MarkerFaceColor', S.orange, ...
         'MarkerSize', S.marker - 2, 'LineWidth', 1.2, 'BaseValue', yl(1), ...
         'DisplayName', sprintf('Shorted bar, severity %.2f', X.runs(4).severity));
    set(ax, 'YScale', 'log');  xlim(ax, [0 30.5]);  ylim(ax, yl);
    style_axes(ax, 'Shaft order (cycles per revolution)', 'Synchronous current amplitude (mA)');
    style_legend(legend(ax, 'Location', 'northoutside', 'Orientation', 'horizontal'));
    save_figure(fig, fullfile(fd, 'fig_spectrum_current'));  close(fig);
    fprintf(['written: fig_spectrum_current (at 2x: normal %.1f, fault %.1f mA; check: fault minus baseline ' ...
             '%+.1f mA against A_i2 %+.1f mA from the table)\n'], 1e3*An(2), 1e3*Af(2), 1e3*(Af(2) - Ab(2)), ...
            1e3*feature_value(F3, sid, 'shorted_bar', 'A_i2'));
catch err, fprintf('skipped current spectrum: %s\n', err.message); end
try
    L = load(fullfile(outdir, 'datasets', 'M3', sprintf('session_%04d.mat', sid)), 'X');  X = L.X;
    [oN, An] = envelope_spectrum(X.runs(2).rec, 256);
    [oF, Af] = envelope_spectrum(X.runs(5).rec, 256);
    [fig, ax] = new_figure();
    in = oF >= 0.5 & oF <= 30;  yl = [min([An(oN >= 0.5 & oN <= 30); Af(in)]), 4*max(Af(in))];
    for h = 1:4
        plot(ax, [h h]*5.787, yl, '--', 'Color', S.dark, 'LineWidth', S.ref, 'HandleVisibility', 'off');
    end
    text(ax, 5.787, yl(2)/1.8, '5.787\times', 'HorizontalAlignment', 'center', 'FontSize', S.tick, ...
         'FontWeight', 'bold', 'BackgroundColor', 'w');
    plot(ax, oN, An, '-', 'Color', S.blue, 'LineWidth', S.line, 'DisplayName', 'Normal');
    plot(ax, oF, Af, '-', 'Color', S.orange, 'LineWidth', S.line - 0.5, ...
         'DisplayName', sprintf('Outer-race defect, D = %.2f', X.runs(5).severity));
    set(ax, 'YScale', 'log');  xlim(ax, [0.5 30]);  ylim(ax, yl);
    style_axes(ax, 'Order (cycles per revolution)', 'Envelope amplitude (g)');
    style_legend(legend(ax, 'Location', 'northeast'));
    save_figure(fig, fullfile(fd, 'fig_spectrum_envelope'));  close(fig);
    fprintf('written: fig_spectrum_envelope (A_env %+.2f, log ratio, from the table)\n', feature_value(F3, sid, 'bearing_outer', 'A_env'));
catch err, fprintf('skipped envelope spectrum: %s\n', err.message); end
try
    L = load(fullfile(outdir, 'datasets', 'M3', sprintf('session_%04d.mat', sid)), 'X');  X = L.X;
    [oN, An] = vib_orders(X.runs(2).rec, 10);
    [oF, Af] = vib_orders(X.runs(6).rec, 10);
    [~,  Ab] = vib_orders(X.runs(1).rec, 1);
    [fig, ax] = new_figure();
    yl = [10^floor(log10(1e3*min([An; Af]))), 10^ceil(log10(1e3*max([An; Af])) + 0.5)];
    plot(ax, [1 1], yl, '--', 'Color', S.light, 'LineWidth', S.ref, 'HandleVisibility', 'off');
    text(ax, 1, yl(2)/2.2, '1\times', 'HorizontalAlignment', 'center', 'FontSize', S.tick, ...
         'FontWeight', 'bold', 'BackgroundColor', 'w');
    stem(ax, oN - 0.12, 1e3*An, 'Color', S.blue, 'Marker', 'o', 'MarkerSize', S.marker - 2, ...
         'LineWidth', 1.2, 'BaseValue', yl(1), 'DisplayName', 'Normal');
    stem(ax, oF + 0.12, 1e3*Af, 'Color', S.orange, 'Marker', 's', 'MarkerFaceColor', S.orange, ...
         'MarkerSize', S.marker - 2, 'LineWidth', 1.2, 'BaseValue', yl(1), ...
         'DisplayName', sprintf('Imbalance, %.0f g\\cdotmm', 1e6*X.runs(6).severity));
    set(ax, 'YScale', 'log');  xlim(ax, [0.4 10.6]);  ylim(ax, yl);
    style_axes(ax, 'Shaft order (cycles per revolution)', 'Synchronous vibration amplitude (mg)');
    style_legend(legend(ax, 'Location', 'northeast'));
    save_figure(fig, fullfile(fd, 'fig_spectrum_vibration'));  close(fig);
    fprintf(['written: fig_spectrum_vibration (at 1x: normal %.4f, imbalance %.2f mg; check: imbalance minus ' ...
             'baseline %+.2f mg against A_v1 %+.2f mg from the table)\n'], 1e3*An(1), 1e3*Af(1), ...
            1e3*(Af(1) - Ab(1)), 1e3*feature_value(F3, sid, 'imbalance', 'A_v1'));
catch err, fprintf('skipped vibration spectrum: %s\n', err.message); end
fprintf('\nFigures in %s\n\n', fd);
end

function grid_heatmap(G, cells, meth, star, file, S)
M = nan(size(cells, 1), numel(meth));
for i = 1:size(cells, 1)
    for j = 1:numel(meth)
        g = pick(G, cells{i,1}, meth{j});
        if ~isempty(g), M(i,j) = 100*g.m.acc; end
    end
end
[fig, ax] = new_figure();
imagesc(ax, M, [30 100]);  colormap(ax, flipud(gray(256))*0.85 + 0.15);
for i = 1:size(M,1), for j = 1:size(M,2)
    if isnan(M(i,j)), continue; end
    sf = '';  if star && strcmp(meth{j}, 'Rule'), sf = '*'; end
    text(ax, j, i, [sprintf('%.1f', M(i,j)) sf], 'HorizontalAlignment', 'center', 'FontSize', S.tick - 2, ...
         'FontWeight', 'bold', 'Color', ifelse(M(i,j) > 70, 'w', 'k'));
end, end
set(ax, 'XTick', 1:numel(meth), 'XTickLabel', meth, 'YTick', 1:size(cells, 1), 'YTickLabel', cells(:,2), 'YDir', 'reverse');
style_axes(ax, 'Method', '');  grid(ax, 'off');  axis(ax, 'tight');
save_figure(fig, file);  close(fig);
fprintf('  %s:\n', file);
for i = 1:size(M,1), fprintf('    %-26s %s\n', cells{i,2}, sprintf('%7.1f', M(i,:))); end
end

function [o, A] = tsa_orders(ch, enc, nOrd)
fs = ch.fs;  k0 = round(0.5*fs) + 1;
y  = double(ch.y(:));  yc = y(k0:end) - mean(y(k0:end));
th = double(enc.y(:));  tc = th(k0:end);
o = (1:nOrd)';  A = zeros(nOrd, 1);
for n = 1:nOrd, A(n) = abs(order_coef(yc, tc, n)); end
end

function [o, A] = envelope_spectrum(rec, perRev)
fa = rec.acc.fs;  a0 = round(0.5*fa) + 1;
a  = double(rec.acc.y(a0:end));  a = a(:) - mean(a);
[bb, aa] = butter(4, [5500 7000]/(fa/2), 'bandpass');
env = abs(hilbert(filtfilt(bb, aa, a)));  env = env - mean(env);
fs = rec.cur.fs;  th = double(rec.enc.y(:));  tcg = (0:numel(th) - 1)'/fs;
ta = (a0 - 1:numel(rec.acc.y) - 1)'/fa;
tha = interp1(tcg, th, ta, 'linear', 'extrap');
nrev = floor((tha(end) - tha(1))/(2*pi));
fr = (tha(end) - tha(1))/(2*pi*(ta(end) - ta(1)));
[bl, al] = butter(4, min(0.4*perRev*fr/(fa/2), 0.95));
env = filtfilt(bl, al, env);
tg = tha(1) + (0:nrev*perRev - 1)'*(2*pi/perRev);
eg = interp1(tha, env, tg, 'linear');
Y  = fft(eg);  n = numel(eg);
A  = 2*abs(Y(1:floor(n/2)))/n;  o = (0:floor(n/2) - 1)'/nrev;
end

function [o, A] = vib_orders(rec, nOrd)
fs = rec.cur.fs;  th = double(rec.enc.y(:));  nth = numel(th);
fa = rec.acc.fs;  a0 = round(0.5*fa) + 1;
a  = double(rec.acc.y(a0:end));  a = a(:) - mean(a);
ta = (a0 - 1:numel(rec.acc.y) - 1)'/fa;  tcg = (0:nth - 1)'/fs;
tha = interp1(tcg, th, ta, 'linear', 'extrap');
o = (1:nOrd)';  A = zeros(nOrd, 1);
for n = 1:nOrd, A(n) = abs(order_coef(a, tha, n)); end
end

function c = order_coef(x, th, n)
t0 = th(1);  nrev = floor((th(end) - t0)/(2*pi));
k  = th <= t0 + nrev*2*pi;  tt = th(k);  xx = x(k);  dth = gradient(tt);
c  = 2*sum(xx.*exp(-1i*n*tt).*dth)/sum(dth);
end

function j = mid_session(Ssn)
k = find(Ssn.duty == 0.6);
d = abs(Ssn.res_s(k) - 0.16)/0.28 + abs(Ssn.sc_f(k) - 0.55)/0.9 + ...
    abs(Ssn.brg_D(k) - 0.525)/0.95 + abs(Ssn.imb_mr(k) - 1.5e-5)/2.0e-5;
[~, i] = min(d);  j = k(i);
end

function v = feature_value(F3, sid, state, name, tw)
v = NaN;
try
    T = F3.A;  if nargin >= 5, T = F3.B.(sprintf('T%d', tw)); end
    k = F3.A.session == sid & is_state(F3.A.state, state);
    v = T.(name)(k);  v = v(1);
catch
end
end

function FT = load_ft(outdir, d)
L = load(fullfile(outdir, 'features', sprintf('F_D%d.mat', d)), 'FT');  FT = L.FT;
end
function g = pick(G, cellName, method)
g = G(strcmp({G.cell}, cellName) & strcmp({G.method}, method));
end
function v = ifelse(c, a, b)
if c, v = a; else, v = b; end
end
function k = is_state(y, name)
k = strcmp(cellstr(y(:)), name);
end
function U = rows_of(T, k)
if isstruct(T)
    U = T;
    for f = fieldnames(T)'
        v = T.(f{1});  if size(v, 1) == numel(k), U.(f{1}) = v(k, :); end
    end
else
    U = T(k, :);
end
end
function s = physics(fname, A, B, p)
w = B.X_w;  bb = B.X_bbase;
switch fname
    case 'resistive',     s = B.B_R;
    case 'shorted_bar',   s = -B.B_Ke/p.sc.dK;
    case 'bearing_outer', s = B.B_Tf./(p.brg.kf*bb.*w);
    case 'imbalance'
        a = A.A_v1*9.81;  wn = 2*pi*p.modes.f(1);  z = p.modes.zeta(1);
        s = a.*p.M.*sqrt((wn^2 - w.^2).^2 + (2*z*wn*w).^2)./w.^4;
end
end
function [w, i] = op_point(q, V, TL)
R = q.R*(1 + q.alpha*q.theta);
w = (q.Kt*V/R - q.Tc - TL)/(q.Kt*q.Ke/R + q.b);
i = (V - q.Ke*w)/R;
end
