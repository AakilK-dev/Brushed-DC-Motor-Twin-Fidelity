function make_signal_figures(outdir)

fd = fullfile(outdir, 'figures');  if ~exist(fd, 'dir'), mkdir(fd); end
S = fig_style();  p = params_default();  c3 = cfg_model3();
fsFine = 1/c3.dt;
t0 = 0.5;  Tseg = 0.5;
check_welch();

Ssn = load(fullfile(outdir, 'datasets', 'sessions.mat'), 'S');  Ssn = Ssn.S;
sid = Ssn.session(mid_session(Ssn));
X3 = load_session(outdir, 'M3', sid);
X2 = try_session(outdir, 'M2', sid);  X1 = try_session(outdir, 'M1', sid);
rN = X3.runs(2).rec;
fsC = rN.cur.fs;  fsA = rN.acc.fs;  fr = shaft_rate(rN, t0);
if isstruct(X3.mounting), f1 = X3.mounting.f1; else, f1 = p.modes.f(1); end
fHm = mean(p.modes.f(5:6));
fprintf('\nSIGNAL FIGURES: diagnosis session %d, 60%% duty, shaft rate %.1f Hz (%.1f rad/s); mounting mode of this installation %.1f Hz\n', ...
        sid, fr, 2*pi*fr, f1);
lsbI = p.cur_svc.vfs/2^p.cur_svc.bits/p.cur_svc.sens;
lsbA = 2*p.acc.vfs/2^p.acc.bits/p.acc.sens;
EI = @(f) expected_floor(f, p.cur_svc.nd, lsbI, fsC, fsFine, p.aa);
EA = @(f) expected_floor(f, p.acc.nd, lsbA, fsA, fsFine, p.aa);
fprintf('  expected floors in the flat band: current %.2e A^2/Hz (%.2e A/rtHz), vibration %.2e g^2/Hz (%.2e g/rtHz)\n', ...
        EI(1000), sqrt(EI(1000)), EA(1000), sqrt(EA(1000)));

try
    if isempty(X1), error('the Model 1 records are needed'); end
    r1 = X1.runs(2).rec;
    [f, P] = welch_psd(after(r1.cur, t0), fsC, Tseg);  b = f >= 3000 & f <= 3800;
    fprintf('  instrument check, current, Model 1, 3.0 to 3.8 kHz: measured %.2e, expected %.2e A^2/Hz, ratio %.2f\n', ...
            mean(P(b)), mean(EI(f(b))), mean(P(b))/mean(EI(f(b))));
    [f, P] = welch_psd(after(r1.acc, t0), fsA, Tseg);  b = f >= 1000 & f <= 15000;
    fprintf('  instrument check, vibration, Model 1, 1 to 15 kHz: measured %.2e, expected %.2e g^2/Hz, ratio %.2f\n', ...
            mean(P(b)), mean(EA(f(b))), mean(P(b))/mean(EA(f(b))));
catch err, fprintf('skipped the instrument check: %s\n', err.message); end

try
    k = round(1.0*fsC) + 1:round(1.2*fsC);  y = double(rN.cur.y(k));
    [fig, ax] = new_figure();
    plot(ax, (k - 1)/fsC, y, '-', 'Color', S.black, 'LineWidth', 1.2);
    xlim(ax, [1.0 1.2]);
    style_axes(ax, 'Time in the run (s)', 'Armature current (A)');
    save_figure(fig, fullfile(fd, 'fig_sp_current_time'));  close(fig);
    fprintf('written: fig_sp_current_time (1.0 to 1.2 s: mean %.3f A, range %.3f to %.3f A; one converter step %.1f mA)\n', ...
            mean(y), min(y), max(y), 1e3*lsbI);
catch err, fprintf('skipped the current record: %s\n', err.message); end

try
    [f, P] = welch_psd(after(rN.cur, t0), fsC, Tseg);  xl = [2 fsC/2];  E = EI(f);
    yl = psd_ylim(f, P, xl, E);
    [fig, ax] = new_figure();
    marks(ax, S, fr*[1 2 p.nbars], {'1\times', '2\times', sprintf('%d\\times', p.nbars)}, yl, xl, true);
    h1 = plot(ax, f(2:end), P(2:end), '-', 'Color', S.blue, 'LineWidth', 1.0);
    h2 = plot(ax, f(2:end), E(2:end), '--', 'Color', S.dark, 'LineWidth', S.line);
    set(ax, 'XScale', 'log', 'YScale', 'log');  xlim(ax, xl);  ylim(ax, yl);
    style_axes(ax, 'Frequency (Hz)', 'Current PSD (A^2/Hz)');
    style_legend(legend(ax, [h1 h2], {'Normal run', 'Expected noise floor'}, 'Location', 'northoutside', 'Orientation', 'horizontal'));
    save_figure(fig, fullfile(fd, 'fig_sp_current_psd'));  close(fig);
    fprintf('written: fig_sp_current_psd (lines: 1x %.2e, 2x %.2e, %dx %.2e A^2/Hz; mean 3.0 to 3.8 kHz %.2e against %.2e expected)\n', ...
            at(f, P, fr), at(f, P, 2*fr), p.nbars, at(f, P, p.nbars*fr), mean(P(f >= 3000 & f <= 3800)), mean(E(f >= 3000 & f <= 3800)));
catch err, fprintf('skipped the current PSD: %s\n', err.message); end

try
    [f, P] = welch_psd(after(rN.acc, t0), fsA, Tseg);  xl = [2 fsA/2];  E = EA(f);
    yl = psd_ylim(f, P, xl, E);
    [fig, ax] = new_figure();
    marks(ax, S, [f1 fHm], {'mounting mode', 'housing modes'}, yl, xl, true);
    h1 = plot(ax, f(2:end), P(2:end), '-', 'Color', S.blue, 'LineWidth', 1.0);
    h2 = plot(ax, f(2:end), E(2:end), '--', 'Color', S.dark, 'LineWidth', S.line);
    set(ax, 'XScale', 'log', 'YScale', 'log');  xlim(ax, xl);  ylim(ax, yl);
    style_axes(ax, 'Frequency (Hz)', 'Vibration PSD (g^2/Hz)');
    style_legend(legend(ax, [h1 h2], {'Normal run', 'Expected noise floor'}, 'Location', 'northoutside', 'Orientation', 'horizontal'));
    save_figure(fig, fullfile(fd, 'fig_sp_vibration_psd'));  close(fig);
    [~, j1] = max(P .* (f >= 0.6*f1 & f <= 1.5*f1));  [~, jH] = max(P .* (f >= 5500 & f <= 7000));
    fprintf(['written: fig_sp_vibration_psd (peaks: %.0f Hz, %.2e, and %.0f Hz, %.2e g^2/Hz; ', ...
             'mean 12 to 18 kHz %.2e against %.2e expected)\n'], f(j1), P(j1), f(jH), P(jH), ...
             mean(P(f >= 12e3 & f <= 18e3)), mean(E(f >= 12e3 & f <= 18e3)));
catch err, fprintf('skipped the vibration PSD: %s\n', err.message); end

try
    a = double(X3.runs(6).rec.acc.y);
    [t, f, P] = stft_psd(a, fsA, 0.1, 0.005, 2^16, 0, [0 300]);
    fig = spectro(S, t, f, P, [0 300], 'Time in the run (s)', 'PSD (dB re 1 g^2/Hz)', t0, 'analysis starts', [0 1]);
    save_figure(fig, fullfile(fd, 'fig_sp_startup_spectrogram'));  close(fig);
    b = abs(f - f1) <= 10;  e = 10*log10(sum(P(b, :), 1));  es = median(e(t >= 1.0));
    tq = [0.05 0.1 0.2 0.5];  eq = arrayfun(@(v) e(find(t >= v, 1)) - es, tq);
    fprintf('written: fig_sp_startup_spectrogram (band %.0f +/- 10 Hz against its level after 1 s: %+.1f, %+.1f, %+.1f, %+.1f dB at 0.05, 0.1, 0.2, 0.5 s)\n', f1, eq);
catch err, fprintf('skipped the start-up spectrogram: %s\n', err.message); end

try
    rF = X3.runs(4).rec;  frF = shaft_rate(rF, t0);  xl = [2 fsC/2];
    [f, Pn] = welch_psd(after(rN.cur, t0), fsC, Tseg);  [~, Pf] = welch_psd(after(rF.cur, t0), fsC, Tseg);
    yl = psd_ylim(f, [Pn Pf], xl);
    [fig, ax] = new_figure();
    marks(ax, S, frF*[1 2 p.nbars], {'1\times', '2\times', sprintf('%d\\times', p.nbars)}, yl, xl, true);
    h1 = plot(ax, f(2:end), Pn(2:end), '-', 'Color', S.blue, 'LineWidth', 2.4);
    h2 = plot(ax, f(2:end), Pf(2:end), '-', 'Color', S.orange, 'LineWidth', 1.0);
    set(ax, 'XScale', 'log', 'YScale', 'log');  xlim(ax, xl);  ylim(ax, yl);
    style_axes(ax, 'Frequency (Hz)', 'Current PSD (A^2/Hz)');
    style_legend(legend(ax, [h1 h2], {'Normal', sprintf('Shorted bar, severity %.2f', X3.runs(4).severity)}, ...
                        'Location', 'northoutside', 'Orientation', 'horizontal'));
    save_figure(fig, fullfile(fd, 'fig_sp_psd_shorted_bar'));  close(fig);
    fprintf('written: fig_sp_psd_shorted_bar (at 2x: normal %.2e, fault %.2e A^2/Hz, ratio %.1f; shaft rate %.1f to %.1f Hz)\n', ...
            at(f, Pn, 2*fr), at(f, Pf, 2*frF), at(f, Pf, 2*frF)/at(f, Pn, 2*fr), fr, frF);
catch err, fprintf('skipped the shorted-bar PSD: %s\n', err.message); end

try
    rF = X3.runs(5).rec;  xl = [2 fsA/2];
    [f, Pn] = welch_psd(after(rN.acc, t0), fsA, Tseg);  [~, Pf] = welch_psd(after(rF.acc, t0), fsA, Tseg);
    yl = psd_ylim(f, [Pn Pf], xl);
    [fig, ax] = new_figure();
    patch(ax, [5500 7000 7000 5500], yl([1 1 2 2]), S.grid, 'EdgeColor', 'none', 'HandleVisibility', 'off');
    text(ax, sqrt(5500*7000), 10^(log10(yl(2)) - 0.07*diff(log10(yl))), 'envelope band', 'HorizontalAlignment', 'center', ...
         'FontSize', S.tick, 'FontWeight', 'bold');
    h1 = plot(ax, f(2:end), Pn(2:end), '-', 'Color', S.blue, 'LineWidth', 2.4);
    h2 = plot(ax, f(2:end), Pf(2:end), '-', 'Color', S.orange, 'LineWidth', 0.8);
    set(ax, 'XScale', 'log', 'YScale', 'log', 'Layer', 'top');  xlim(ax, xl);  ylim(ax, yl);
    style_axes(ax, 'Frequency (Hz)', 'Vibration PSD (g^2/Hz)');
    style_legend(legend(ax, [h1 h2], {'Normal', sprintf('Outer-race defect, D = %.2f', X3.runs(5).severity)}, ...
                        'Location', 'northoutside', 'Orientation', 'horizontal'));
    save_figure(fig, fullfile(fd, 'fig_sp_psd_bearing'));  close(fig);
    b = f >= 5500 & f <= 7000;  lo = f >= 10 & f <= 2000;
    fprintf('written: fig_sp_psd_bearing (mean PSD 5.5 to 7 kHz: normal %.2e, fault %.2e g^2/Hz, ratio %.0f; 10 Hz to 2 kHz ratio %.2f)\n', ...
            mean(Pn(b)), mean(Pf(b)), mean(Pf(b))/mean(Pn(b)), mean(Pf(lo))/mean(Pn(lo)));
catch err, fprintf('skipped the bearing PSD: %s\n', err.message); end

try
    rF = X3.runs(6).rec;  frF = shaft_rate(rF, t0);  xl = [0 300];
    [f, Pn] = welch_psd(after(rN.acc, t0), fsA, Tseg);  [~, Pf] = welch_psd(after(rF.acc, t0), fsA, Tseg);
    yl = psd_ylim(f, [Pn Pf], [2 300]);
    [fig, ax] = new_figure();
    marks(ax, S, [frF f1], {'1\times', 'mounting mode'}, yl, xl, false);
    h1 = plot(ax, f, Pn, '-', 'Color', S.blue, 'LineWidth', 3.0);
    h2 = plot(ax, f, Pf, '-', 'Color', S.orange, 'LineWidth', 1.4);
    set(ax, 'YScale', 'log');  xlim(ax, xl);  ylim(ax, yl);
    style_axes(ax, 'Frequency (Hz)', 'Vibration PSD (g^2/Hz)');
    style_legend(legend(ax, [h1 h2], {'Normal', sprintf('Imbalance, %.0f g\\cdotmm', 1e6*X3.runs(6).severity)}, ...
                        'Location', 'northoutside', 'Orientation', 'horizontal'));
    save_figure(fig, fullfile(fd, 'fig_sp_psd_imbalance'));  close(fig);
    fprintf('written: fig_sp_psd_imbalance (at 1x, %.1f Hz: normal %.2e, fault %.2e g^2/Hz, ratio %.0f)\n', ...
            frF, at(f, Pn, frF), at(f, Pf, frF), at(f, Pf, frF)/at(f, Pn, frF));
catch err, fprintf('skipped the imbalance PSD: %s\n', err.message); end

try
    rF = X3.runs(5).rec;  k = round(1.0*fsA) + 1:round(1.02*fsA);  tt = 1e3*((k - 1)/fsA - 1.0);
    yn = double(rN.acc.y(k));  yf = double(rF.acc.y(k));
    two = {yn, 'Normal', 'fig_sp_time_bearing_normal';
           yf, sprintf('Outer-race defect, D = %.2f', X3.runs(5).severity), 'fig_sp_time_bearing_defect'};
    for c = 1:2
        y = two{c,1};  m = max(abs(y));
        [fig, ax] = new_figure();
        h = plot(ax, tt, y, '-', 'Color', S.black, 'LineWidth', 1.0);
        xlim(ax, [0 20]);  ylim(ax, m*[-1.15 1.6]);
        style_axes(ax, 'Time from 1.0 s into the run (ms)', 'Vibration (g)');
        style_legend(legend(ax, h, two(c,2), 'Location', 'north'));
        save_figure(fig, fullfile(fd, two{c,3}));  close(fig);
    end
    an = after(rN.acc, t0);  af = after(rF.acc, t0);
    fprintf(['written: fig_sp_time_bearing_normal, fig_sp_time_bearing_defect (outer-race passes every %.2f ms; ', ...
             'in the 20 ms shown, peak %.3f g against %.3f g normal; over the analysed 2.0 s, rms %.4f g against %.4f g, ratio %.1f)\n'], ...
            1e3/(p.brg.BPFO*shaft_rate(rF, t0)), max(abs(yf)), max(abs(yn)), std(af), std(an), std(af)/std(an));
catch err, fprintf('skipped the bearing records: %s\n', err.message); end

try
    if isempty(X1) || isempty(X2), error('the Model 1 and Model 2 records are needed'); end
    R = {X1.runs(2).rec, X2.runs(2).rec, rN};
    for ch = {'cur', 'acc'}
        c = ch{1};  fs = rN.(c).fs;  xl = [2 fs/2];  Pm = cell(1, 3);
        for m = 1:3, [f, Pm{m}] = welch_psd(after(R{m}.(c), t0), fs, Tseg); end
        same12 = max(abs(Pm{1} - Pm{2})) <= 1e-9*max(Pm{2});
        yl = psd_ylim(f, [Pm{1} Pm{2} Pm{3}], xl);
        [fig, ax] = new_figure();
        if same12
            h = [plot(ax, f(2:end), Pm{1}(2:end), '-', 'Color', S.green, 'LineWidth', 3.0), ...
                 plot(ax, f(2:end), Pm{3}(2:end), '-', 'Color', S.blue, 'LineWidth', 0.9)];
            lab = {'Models 1 and 2', 'Reference (Model 3)'};
        else
            h = [plot(ax, f(2:end), Pm{1}(2:end), '-', 'Color', S.magenta, 'LineWidth', 3.4), ...
                 plot(ax, f(2:end), Pm{2}(2:end), '-', 'Color', S.green, 'LineWidth', 1.8), ...
                 plot(ax, f(2:end), Pm{3}(2:end), '-', 'Color', S.blue, 'LineWidth', 0.8)];
            lab = {'Model 1', 'Model 2', 'Reference (Model 3)'};
        end
        set(ax, 'XScale', 'log', 'YScale', 'log');  xlim(ax, xl);  ylim(ax, yl);
        if strcmp(c, 'cur')
            style_axes(ax, 'Frequency (Hz)', 'Current PSD (A^2/Hz)');  nmf = 'fig_sp_models_current_psd';
            band = [3000 3800];  un = 'A^2/Hz';  fl = p.nbars*fr;
        else
            style_axes(ax, 'Frequency (Hz)', 'Vibration PSD (g^2/Hz)');  nmf = 'fig_sp_models_vibration_psd';
            band = [1000 15000];  un = 'g^2/Hz';  fl = f1;
        end
        style_legend(legend(ax, h, lab, 'Location', 'northoutside', 'Orientation', 'horizontal'));
        save_figure(fig, fullfile(fd, nmf));  close(fig);
        b = f >= band(1) & f <= band(2);
        fprintf('written: %s (Models 1 and 2 identical: %d; mean %.0f to %.0f Hz: %.2e, %.2e, %.2e %s; at %.0f Hz: %.2e, %.2e, %.2e)\n', ...
                nmf, same12, band, mean(Pm{1}(b)), mean(Pm{2}(b)), mean(Pm{3}(b)), un, fl, at(f, Pm{1}, fl), at(f, Pm{2}, fl), at(f, Pm{3}, fl));
    end
catch err, fprintf('skipped the model comparison PSDs: %s\n', err.message); end

try
    nmr = {'Normal', 'Resistive', 'Shorted bar', 'Bearing defect', 'Imbalance'};
    fid = fopen(fullfile(fd, 'table_signal_statistics.csv'), 'w');
    fprintf(fid, 'run,shaft_speed_rad_s,current_mean_A,current_std_A,vibration_rms_g,vibration_peak_g,crest_factor,kurtosis\n');
    fprintf('\nTIME-DOMAIN STATISTICS, session %d, after the first 0.5 s (the definitions of the features)\n', sid);
    fprintf('%-15s %11s %10s %10s %12s %12s %7s %9s\n', 'run', 'w (rad/s)', 'I mean (A)', 'I std (A)', 'vib rms (g)', 'vib peak (g)', 'crest', 'kurtosis');
    for i = 2:6
        r = X3.runs(i).rec;  ic = after(r.cur, t0);  a = after(r.acc, t0);  a = a - mean(a);
        vr = sqrt(mean(a.^2));
        st = [2*pi*shaft_rate(r, t0), mean(ic), std(ic), vr, max(abs(a)), max(abs(a))/vr, mean(a.^4)/vr^4];
        fprintf(fid, '%s,%.6g,%.6g,%.6g,%.6g,%.6g,%.6g,%.6g\n', nmr{i-1}, st);
        fprintf('%-15s %11.2f %10.3f %10.3f %12.4f %12.4f %7.2f %9.2f\n', nmr{i-1}, st);
    end
    fclose(fid);
    fprintf('written: table_signal_statistics.csv\n\n');
catch err, fprintf('skipped the statistics table: %s\n', err.message); end

try
    [Xo, so] = typical_onset(outdir);
    fprintf('ONSET SPECTROGRAMS: onset session %d; onsets %.2f, %.2f, %.2f s; severities %.2f, D = %.2f, %.0f g.mm\n', ...
            so, Xo.runs(4).onset, Xo.runs(5).onset, Xo.runs(6).onset, Xo.runs(4).severity, Xo.runs(5).severity, 1e6*Xo.runs(6).severity);
    r = Xo.runs(4);  [t, f, P] = stft_psd(double(r.rec.cur.y), r.rec.cur.fs, 0.25, 0.01, 2^14, -r.onset, [0 300]);
    fig = spectro(S, t, f, P, [0 300], 'Time from the fault''s onset (s)', 'PSD (dB re 1 A^2/Hz)', 0, 'onset', [-1 1.5]);
    save_figure(fig, fullfile(fd, 'fig_sp_onset_shorted_bar'));  close(fig);
    fprintf('written: fig_sp_onset_shorted_bar (2x at %.1f Hz)\n', 2*shaft_rate(r.rec, t0));
    r = Xo.runs(5);  fa = r.rec.acc.fs;  k = round((r.onset - 0.1)*fa) + 1:round((r.onset + 0.1)*fa);
    [t, f, P] = stft_psd(double(r.rec.acc.y(k)), fa, 0.002, 0.0002, 1024, (k(1) - 1)/fa - r.onset, [3000 10000]);
    fig = spectro(S, t, f, P, [3000 10000], 'Time from the fault''s onset (s)', 'PSD (dB re 1 g^2/Hz)', 0, 'onset', [-0.1 0.1]);
    save_figure(fig, fullfile(fd, 'fig_sp_onset_bearing'));  close(fig);
    fprintf('written: fig_sp_onset_bearing (outer-race passes every %.2f ms)\n', 1e3/(p.brg.BPFO*shaft_rate(r.rec, t0)));
    r = Xo.runs(6);  [t, f, P] = stft_psd(double(r.rec.acc.y), r.rec.acc.fs, 0.25, 0.01, 2^16, -r.onset, [0 300]);
    fig = spectro(S, t, f, P, [0 300], 'Time from the fault''s onset (s)', 'PSD (dB re 1 g^2/Hz)', 0, 'onset', [-1 1.5]);
    save_figure(fig, fullfile(fd, 'fig_sp_onset_imbalance'));  close(fig);
    fprintf('written: fig_sp_onset_imbalance (1x at %.1f Hz)\n', shaft_rate(r.rec, t0));
catch err, fprintf('skipped the onset spectrograms: %s\n', err.message); end
fprintf('\nSignal figures in %s\n\n', fd);
end

function [f, P] = welch_psd(x, fs, Tseg)
x = x(:) - mean(x);  N = round(Tseg*fs);  H = floor(N/2);
w = 0.5 - 0.5*cos(2*pi*(0:N - 1)'/N);  U = sum(w.^2);
nseg = floor((numel(x) - N)/H) + 1;  nf = floor(N/2) + 1;  acc = zeros(nf, 1);
for s = 1:nseg
    X = fft(x((s - 1)*H + (1:N)).*w);  acc = acc + abs(X(1:nf)).^2;
end
P = acc/(nseg*fs*U);  P(2:nf - 1) = 2*P(2:nf - 1);  f = (0:nf - 1)'*fs/N;
end

function [t, f, P] = stft_psd(x, fs, Tw, Th, nfft, tShift, fband)
x = x(:) - mean(x);  N = round(Tw*fs);  H = max(1, round(Th*fs));  nfft = max(nfft, N);
w = 0.5 - 0.5*cos(2*pi*(0:N - 1)'/N);  U = sum(w.^2);
nf = floor(nfft/2) + 1;  fa = (0:nf - 1)'*fs/nfft;  keep = find(fa >= fband(1) & fa <= fband(2));
nfr = floor((numel(x) - N)/H) + 1;  P = zeros(numel(keep), nfr);
for k = 1:nfr
    X = fft(x((k - 1)*H + (1:N)).*w, nfft);  P(:, k) = abs(X(keep)).^2;
end
P = P/(fs*U);  two = keep > 1 & keep < nf;  P(two, :) = 2*P(two, :);
t = ((0:nfr - 1)*H + N/2)/fs + tShift;  f = fa(keep);
end

function check_welch()
old = rng();  rng(20261102, 'twister');
fs = 10e3;  d = 1e-3;  x = d*sqrt(fs/2)*randn(round(2.0*fs), 1);
rng(old);
[f, P] = welch_psd(x, fs, 0.5);  r = mean(P(f > 10 & f < 4900))/d^2;
fprintf('PSD scaling check: white noise of density %.0e returns %.3f times its square (mean over 10 to 4900 Hz)\n', d, r);
if abs(r - 1) > 0.05, warning('make_signal_figures:scaling', 'PSD scaling off by more than 5%%'); end
end

function E = expected_floor(f, nd, lsb, fs, fsFine, aa)
H2 = @(g) 1./(1 + (tan(pi*g/fsFine)/tan(pi*aa.frac*fs/fsFine)).^(2*aa.order));
f = f(:);  E = H2(f);
for k = 1:ceil(fsFine/fs)
    for g = {k*fs - f, k*fs + f}
        in = g{1} <= fsFine/2;  E(in) = E(in) + H2(g{1}(in));
    end
end
E = nd^2*E + (lsb^2/12)/(fs/2);
end

function fig = spectro(S, t, f, P, fband, xlab, cunit, tmark, mlab, tlim)
[fig, ax] = new_figure();
kHz = fband(2) >= 3000;  sc = 1;  if kHz, sc = 1e-3; end
it = t >= tlim(1) & t <= tlim(2);  D = 10*log10(P(:, it) + realmin);  top = max(D(:));
imagesc(ax, t(it), f*sc, D);
if exist('parula', 'file') || exist('parula', 'builtin'), cm = parula(256); else, cm = viridis(256); end
set(ax, 'YDir', 'normal', 'CLim', [top - 50, top]);  colormap(ax, cm);
plot(ax, [tmark tmark], fband*sc, '-', 'Color', 'w', 'LineWidth', 4);
plot(ax, [tmark tmark], fband*sc, '--', 'Color', S.black, 'LineWidth', 2);
text(ax, tmark, sc*(fband(1) + 0.93*diff(fband)), [' ' mlab ' '], 'HorizontalAlignment', 'left', ...
     'FontSize', S.tick, 'FontWeight', 'bold', 'BackgroundColor', 'w');
xlim(ax, tlim);  ylim(ax, fband*sc);
if kHz, ylab = 'Frequency (kHz)'; else, ylab = 'Frequency (Hz)'; end
style_axes(ax, xlab, ylab);  grid(ax, 'off');  set(ax, 'Layer', 'top');
cb = colorbar(ax);  set(cb, 'FontSize', S.tick);
ylabel(cb, cunit, 'FontSize', S.label, 'FontWeight', 'bold');
end

function marks(ax, S, fv, labels, yl, xl, xlog)
if xlog, u = (log10(fv) - log10(xl(1)))/diff(log10(xl)); else, u = (fv - xl(1))/diff(xl); end
[u, o] = sort(u);  fv = fv(o);  labels = labels(o);
wd = cellfun(@(s) 0.017*numel(regexprep(s, '\\[a-z]+', 'x')), labels);
row = zeros(size(u));
for q = 2:numel(u)
    if u(q) - u(q-1) < (wd(q) + wd(q-1))/2 + 0.02 && row(q-1) == 0, row(q) = 1; end
end
L = log10(yl);
for q = 1:numel(fv)
    plot(ax, [fv(q) fv(q)], yl, '--', 'Color', S.light, 'LineWidth', S.ref, 'HandleVisibility', 'off');
    text(ax, fv(q), 10^(L(2) - (0.07 + 0.09*row(q))*diff(L)), labels{q}, 'HorizontalAlignment', 'center', ...
         'FontSize', S.tick, 'FontWeight', 'bold', 'BackgroundColor', 'w');
end
end

function yl = psd_ylim(f, P, band, E)
k = f >= max(band(1), f(2)) & f <= band(2);  v = P(k, :);  v = sort(v(v > 0));
if isempty(v), error('the spectrum is zero throughout the band: is the record constant?'); end
lo = v(max(1, round(0.005*numel(v))));  hi = v(end);
if nargin > 3, lo = min(lo, min(E(k))); end
yl = [10^floor(log10(lo) - 0.3), 10^(ceil(log10(hi)) + 1.5)];
end

function v = at(f, P, fq)
[~, j] = min(abs(f - fq));  v = max(P(max(1, j - 1):min(numel(P), j + 1)));
end

function y = after(ch, t0)
y = double(ch.y(round(t0*ch.fs) + 1:end));  y = y(:);
end

function fr = shaft_rate(rec, t0)
th = double(rec.enc.y);  fs = rec.enc.fs;  k0 = round(t0*fs) + 1;  n = numel(th);
fr = (th(n) - th(k0))/(2*pi*(n - k0)/fs);
end

function X = load_session(outdir, folder, sid)
L = load(fullfile(outdir, 'datasets', folder, sprintf('session_%04d.mat', sid)), 'X');  X = L.X;
end

function X = try_session(outdir, folder, sid)
try, X = load_session(outdir, folder, sid); catch, X = []; end
end

function [X, sid] = typical_onset(outdir)
L = load(fullfile(outdir, 'results', 'onset.mat'), 'R', 'S');  R = L.R;  Ses = L.S;
sco = find(~Ses.calib);  faults = {'resistive', 'shorted_bar', 'bearing_outer', 'imbalance'};
D = nan(numel(sco), 4);
for f = 1:4, k = find([R.twin] == 2 & strcmp({R.fault}, faults{f}), 1);  D(:, f) = R(k).delay(:); end
md = zeros(1, 4);  for f = 1:4, md(f) = median(D(~isnan(D(:, f)), f)); end
M = repmat(md, size(D, 1), 1);
[~, jj] = min(sum(abs(D - M)./M, 2));
sid = Ses.session(sco(jj));
X = load_session(outdir, 'onset_M3', sid);
end

function j = mid_session(Ssn)
k = find(Ssn.duty == 0.6);
d = abs(Ssn.res_s(k) - 0.16)/0.28 + abs(Ssn.sc_f(k) - 0.55)/0.9 + ...
    abs(Ssn.brg_D(k) - 0.525)/0.95 + abs(Ssn.imb_mr(k) - 1.5e-5)/2.0e-5;
[~, i] = min(d);  j = k(i);
end
