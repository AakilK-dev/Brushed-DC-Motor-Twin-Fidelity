function plot_sensitivity(outdir)

L = load(fullfile(outdir, 'results', 'sensitivity.mat'), 'Z');  Z = L.Z;
fd = fullfile(outdir, 'figures');  if ~exist(fd, 'dir'), mkdir(fd); end
S = fig_style();  nV = numel(Z.V);  x = 1:nV;
files = {'fig_sensitivity_within_accuracy', 'fig_sensitivity_transfer_gap', ...
         'fig_sensitivity_fidelity_shared', 'fig_sensitivity_setB_resistive'};
ylabs = {'Change in accuracy (pp)', 'Transfer gap (pp)', ...
         'Model 2 minus Model 1 (pp)', 'Gain in recall from Set B (pp)'};
grp = {Z.V.group};  edges = find(~strcmp(grp(2:end), grp(1:end-1))) + 0.5;
for r = 1:4
    R = Z.R(:, r);
    if r == 1
        y = 100*[R.d];  lo = 100*[R.dlo];  hi = 100*[R.dhi];  good = ~[R.moved];
        lab = {'no change detected', 'change detected'};
    else
        y = 100*cellfun(@(t) t.v(r), Z.Tv);  lo = 100*[R.lo];  hi = 100*[R.hi];  good = [R.holds];
        lab = {'conclusion holds', 'conclusion changes'};
    end
    [fig, ax] = new_figure();
    if r == 1, yl = [min([lo 0]) max([hi 0])];
    else,      yl = [min([lo 0 100*Z.base.lo(r)]) max([hi 0 100*Z.base.hi(r)])]; end
    yl = yl + [-0.08 0.08]*max(diff(yl), 1);
    for e = edges, plot(ax, [e e], yl, '-', 'Color', S.grid, 'LineWidth', 1); end
    plot(ax, [0.5 nV + 0.5], [0 0], '-', 'Color', S.dark, 'LineWidth', S.ref);
    h = gobjects(0);  hl = {};
    if r > 1
        h(end+1) = plot(ax, [0.5 nV + 0.5], 100*Z.base.v(r)*[1 1], '--', 'Color', S.black, 'LineWidth', S.ref);
        hl{end+1} = 'base';
    end
    for iv = 1:nV, plot(ax, [iv iv], [lo(iv) hi(iv)], '-', 'Color', S.black, 'LineWidth', S.line); end
    if any(good)
        h(end+1) = plot(ax, x(good), y(good), 'o', 'MarkerSize', S.marker, 'MarkerEdgeColor', S.black, ...
                        'MarkerFaceColor', S.black, 'LineStyle', 'none');
        hl{end+1} = lab{1};
    end
    if any(~good)
        h(end+1) = plot(ax, x(~good), y(~good), 'o', 'MarkerSize', S.marker, 'MarkerEdgeColor', S.black, ...
                        'MarkerFaceColor', 'w', 'LineStyle', 'none', 'LineWidth', S.line);
        hl{end+1} = lab{2};
    end
    xlim(ax, [0.5 nV + 0.5]);  ylim(ax, yl);
    set(ax, 'XTick', 1:nV, 'XTickLabelRotation', 90);
    style_axes(ax, 'Variant', ylabs{r});
    lg = legend(ax, h, hl, 'Location', 'best');  style_legend(lg);
    save_figure(fig, fullfile(fd, files{r}));  close(fig);
end
end
