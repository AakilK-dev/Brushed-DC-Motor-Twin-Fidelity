function [pRef, pTwin, pBench] = sens_params(p, v)

pRef = p;  pTwin = p;  pBench = p;
if nargin < 2 || isempty(v), return; end
switch v.code
    case 'TLfrac'
        pRef.TLfrac = v.value;  pTwin.TLfrac = v.value;
    case {'coolbase', 'spread'}
    case 'kf'
        pRef.brg.kf = v.value;  pTwin.brg.kf = v.value;
    case 'growth'
        pRef.sc.growth = v.value;
    case 'dK'
        pRef.sc.dK = v.value;  pTwin.sc.dK = v.value;
    case 'coulomb'
        Ttot = p.b_lin*p.w_ref;
        Tc = v.value*Ttot;  b = (1 - v.value)*Ttot/p.w_ref;  Ts = (p.Ts/p.Tc)*Tc;
        pRef.Tc   = Tc;  pRef.b   = b;  pRef.Ts   = Ts;
        pBench.Tc = Tc;  pBench.b = b;  pBench.Ts = Ts;
    case 'M'
        pRef.M = v.value;  pTwin.M = v.value;
    case 'f1'
        pRef.modes.f(1) = v.value;  pTwin.modes.f(1) = v.value;
    case 'f1cov'
        pRef.mount.f1cov = v.value;
    case 'Wsvc'
        pRef.brg.W_svc = v.value;
    case 'epsc'
        pRef.eps_c = v.value;
    case 'nbrush'
        pRef.nbrush = v.value;
    case 'hmodes'
        pRef.modes.f(5:6) = p.modes.f(5:6)*v.value;
    case 'Mhf'
        pRef.Mhf = v.value;
    case 'summit'
        pRef.brg.eta_h = v.value(1);  pRef.brg.eta_d = v.value(2);
    case 'stribeck_off'
        pBench.Ts = pBench.Tc;
    case 'ws'
        pBench.ws = v.value;
    otherwise
        error('sens_params:code', 'unknown variant code "%s"', v.code);
end
end
