function V = sens_variants()

all6 = 1:6;  m1 = 1:5;  m2 = 1:6;
V = struct('name', {}, 'group', {}, 'level', {}, 'base', {}, 'code', {}, 'value', {}, ...
           'factor', {}, 'bench', {}, 'refRuns', {}, 'twinRuns', {}, 'band', {}, 'why', {});
V = add(V, 'load_10',   'Load',                       '10% of rated',   '20%',     'TLfrac', 0.10, '', false, all6, {m1, m2}, 1, 'operating point of every model and the filters'' known load');
V = add(V, 'load_24',   'Load',                       '24% of rated',   '20%',     'TLfrac', 0.24, '', false, all6, {m1, m2}, 1, 'operating point of every model and the filters'' known load');
V = add(V, 'cool_5',    'Baseline temperature',       '5 C cooler',     'same as test', 'coolbase', 5,  '', false, 1, {[], []}, 1, 'the reference''s baseline run only: a mismatch the twins do not know');
V = add(V, 'cool_15',   'Baseline temperature',       '15 C cooler',    'same as test', 'coolbase', 15, '', false, 1, {[], []}, 1, 'the reference''s baseline run only: a mismatch the twins do not know');
V = add(V, 'kf_0',      'Bearing friction link k_f',  '0',              '1',       'kf', 0,    '', false, 5, {5, 5}, 1, 'bearing runs of every model');
V = add(V, 'kf_025',    'Bearing friction link k_f',  '0.25',           '1',       'kf', 0.25, '', false, 5, {5, 5}, 1, 'bearing runs of every model');
V = add(V, 'kf_2',      'Bearing friction link k_f',  '2',              '1',       'kf', 2,    '', false, 5, {5, 5}, 1, 'bearing runs of every model');
V = add(V, 'G_half',    'Shorted-bar harmonic growth G', '7.5',         '15',      'growth', 7.5, '', false, 4, {[], []}, 1, 'shorted-bar runs of the reference (commutation exists in Model 3 only)');
V = add(V, 'G_double',  'Shorted-bar harmonic growth G', '30',          '15',      'growth', 30,  '', false, 4, {[], []}, 1, 'shorted-bar runs of the reference (commutation exists in Model 3 only)');
V = add(V, 'dK_half',   'Shorted-bar turn loss dK',   '0.0194',         '0.0388',  'dK', 0.019375, '', false, 4, {4, 4}, 1, 'shorted-bar runs of every model');
V = add(V, 'dK_double', 'Shorted-bar turn loss dK',   '0.0775',         '0.0388',  'dK', 0.0775,   '', false, 4, {4, 4}, 1, 'shorted-bar runs of every model');
V = add(V, 'coul_21',   'Coulomb fraction',           '21%',            '41.6%',   'coulomb', 0.21, '', true, all6, {m1, m2}, 1, 'the true machine on the bench and in service, so both twins'' calibration');
V = add(V, 'coul_62',   'Coulomb fraction',           '62%',            '41.6%',   'coulomb', 0.62, '', true, all6, {m1, m2}, 1, 'the true machine on the bench and in service, so both twins'' calibration');
V = add(V, 'benchM_40', 'Bench modal mass M',         '4.0 kg',         '5.2 kg',  'M', 4.0, '', false, all6, {[], m2}, 1, 'mode 1 of Model 2 and, through the mass factor, of the service mounting');
V = add(V, 'benchM_65', 'Bench modal mass M',         '6.5 kg',         '5.2 kg',  'M', 6.5, '', false, all6, {[], m2}, 1, 'mode 1 of Model 2 and, through the mass factor, of the service mounting');
V = add(V, 'benchf1_58',  'Bench mounting frequency f_1', '58 Hz',      '85 Hz',   'f1', 58,  '', false, all6, {[], m2}, 1, 'mode 1 of Model 2 and the centre of the service mounting''s spread');
V = add(V, 'benchf1_125', 'Bench mounting frequency f_1', '125 Hz',     '85 Hz',   'f1', 125, '', false, all6, {[], m2}, 1, 'mode 1 of Model 2 and the centre of the service mounting''s spread');
V = add(V, 'f1cov_075', 'Service mounting spread',    '7.5%',           '15%',     'f1cov', 0.075, '', false, all6, {[], []}, 1, 'the reference''s installation draw only');
V = add(V, 'f1cov_30',  'Service mounting spread',    '30%',            '15%',     'f1cov', 0.30,  '', false, all6, {[], []}, 1, 'the reference''s installation draw only');
V = add(V, 'Wsvc_half',   'Service bearing load',     '4.83 N',         '9.65 N',  'Wsvc', 4.825, '', false, all6, {[], []}, 1, 'the reference''s bearing contact only');
V = add(V, 'Wsvc_double', 'Service bearing load',     '19.3 N',         '9.65 N',  'Wsvc', 19.3,  '', false, all6, {[], []}, 1, 'the reference''s bearing contact only');
V = add(V, 'epsc_043',  'Commutation ripple depth',   '0.43%',          '1.8%',    'epsc', 0.00429, '', false, all6, {[], []}, 1, 'the reference''s commutation only');
V = add(V, 'epsc_36',   'Commutation ripple depth',   '3.6%',           '1.8%',    'epsc', 0.036,   '', false, all6, {[], []}, 1, 'the reference''s commutation only');
V = add(V, 'brush_4',   'Brushes',                    '4',              '2',       'nbrush', 4, '', false, all6, {[], []}, 1, 'the reference''s commutation only: the asymmetry moves to the 4th order');
V = add(V, 'hmodes_08', 'Housing modes',              '-20%',           '6.1, 6.2 kHz', 'hmodes', 0.8, '', false, all6, {[], []}, 0.8, 'the reference''s housing modes, with the envelope band of every model moved with them');
V = add(V, 'hmodes_12', 'Housing modes',              '+20%',           '6.1, 6.2 kHz', 'hmodes', 1.2, '', false, all6, {[], []}, 1.2, 'the reference''s housing modes, with the envelope band of every model moved with them');
V = add(V, 'Mh_025',    'Housing modal mass M_h',     '0.25 kg',        '0.5 kg',  'Mhf', 0.25, '', false, all6, {[], []}, 1, 'the reference''s housing modes only');
V = add(V, 'Mh_10',     'Housing modal mass M_h',     '1.0 kg',         '0.5 kg',  'Mhf', 1.0,  '', false, all6, {[], []}, 1, 'the reference''s housing modes only');
V = add(V, 'summit_behzad', 'Summit densities',       '2e6, 8e4 per m (Behzad)', '1e8, 1e5 per m', 'summit', [2e6 8e4], '', false, all6, {[], []}, 1, 'the reference''s bearing contact only');
V = add(V, 'sprR_2',    'Resistance spread',          '10% (doubled)',  '5%',      'spread', 2, 'R',   true, all6, {m1, m2}, 1, 'every machine, on the bench and in service, so both twins'' calibration');
V = add(V, 'sprPhi_2',  'Flux spread',                '12% (doubled)',  '6%',      'spread', 2, 'phi', true, all6, {m1, m2}, 1, 'every machine, on the bench and in service, so both twins'' calibration');
V = add(V, 'sprFr_2',   'Friction spread',            '60% (doubled)',  '30%',     'spread', 2, 'fr',  true, all6, {m1, m2}, 1, 'every machine, on the bench and in service, so both twins'' calibration');
V = add(V, 'strib_off', 'Stribeck effect',            'removed (T_s = T_c)', 'T_s = 1.3 T_c', 'stribeck_off', 1, '', true, [], {m1, m2}, 1, 'the bench only (service speeds lie far above it), so both twins'' calibration');
V = add(V, 'strib_ws4', 'Stribeck velocity',          '4 rad/s',        '2 rad/s', 'ws', 4, '', true, [], {m1, m2}, 1, 'the bench only (service speeds lie far above it), so both twins'' calibration');
end

function V = add(V, name, group, level, base, code, value, factor, bench, refRuns, twinRuns, band, why)
V(end+1) = struct('name', name, 'group', group, 'level', level, 'base', base, 'code', code, ...
                  'value', value, 'factor', factor, 'bench', bench, 'refRuns', refRuns, ...
                  'twinRuns', {twinRuns}, 'band', band, 'why', why);
end
