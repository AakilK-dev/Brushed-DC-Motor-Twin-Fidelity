function U = sens_subset(outdir, nPer)

if nargin < 2 || isempty(nPer), nPer = 20; end
L = load(fullfile(outdir, 'datasets', 'sessions.mat'), 'S');  S = L.S;
rs = RandStream('mt19937ar', 'Seed', 20261103);
duties = [0.4 0.6 0.8];  pick = [];
for d = duties
    k = find(abs(S.duty - d) < 1e-9);
    if numel(k) < nPer, error('sens_subset:few', 'only %d sessions at duty %.1f', numel(k), d); end
    pick = [pick; k(randperm(rs, numel(k), nPer))];
end
pick = sort(pick);
U = struct('session', S.session(pick), 'machine', S.machine(pick), 'duty', S.duty(pick), ...
           'seed', 20261103, 'nPer', nPer);
d = fullfile(outdir, 'sensitivity');  if ~exist(d, 'dir'), mkdir(d); end
f = fullfile(d, 'subset.mat');
if exist(f, 'file') == 2
    L = load(f, 'U');
    if ~isequal(L.U.session, U.session) || ~isequal(L.U.machine, U.machine)
        error('sens_subset:changed', '%s was drawn from another session plan: delete the run folder and start again', f);
    end
else
    save(f, 'U');
end
end
