function S = sens_scores(Fv, sess, foldOf, seed0)

cells = {3, 3, 'B2', 1:5, true;  3, 3, 'B2', 1:5, false;  2, 3, 'B2', 1:5, true; ...
         2, 3, 'B2', 1:4, true;  1, 3, 'B1', 1:4, true};
nC = size(cells, 1);  nS = numel(sess);
S.n = zeros(nS, nC);  S.ok = zeros(nS, nC);  S.cells = cells;
S.y = cell(1, nC);  S.yhat = cell(1, nC);  S.session = cell(1, nC);  S.severity = cell(1, nC);
for c = 1:nC
    a = cells{c,1};  b = cells{c,2};  bs = cells{c,3};  cls = cells{c,4};  useB = cells{c,5};
    [Xtr, ytr, ftr] = rows(Fv{a}, bs, cls, useB, sess, foldOf);
    [Xte, yte, fte, ste, vte] = rows(Fv{b}, bs, cls, useB, sess, foldOf);
    yhat = nan(size(yte));
    for k = 1:5
        itr = ftr == k;  ite = fte == k;
        if ~any(ite), continue; end
        yhat(ite) = fit_predict('rf', Xtr(~itr,:), ytr(~itr), Xte(ite,:), seed0 + k);
    end
    S.y{c} = yte;  S.yhat{c} = yhat;  S.session{c} = ste;  S.severity{c} = vte;
    [~, si] = ismember(ste, sess);
    S.n(:,c)  = accumarray(si, 1, [nS 1]);
    S.ok(:,c) = accumarray(si, double(yhat == yte), [nS 1]);
end
k  = S.y{1} == 2;  v = S.severity{1}(k);
e  = quantile(v, [0 1/3 2/3 1]);
small = false(size(S.y{1}));  small(k) = v <= e(2);
[~, si] = ismember(S.session{1}, sess);
S.nSmall  = accumarray(si, double(small), [nS 1]);
S.okSmall = [accumarray(si, double(small & S.yhat{1} == 2), [nS 1]), ...
             accumarray(si, double(small & S.yhat{2} == 2), [nS 1])];
S.edgeSmall = e(2);
end

function [X, y, fold, s, v] = rows(G, bs, cls, useB, sess, foldOf)
k = ismember(G.code, cls) & ismember(G.session, sess);
X = G.A(k,:);
if useB, B = G.(bs);  X = [X, B(k, 1:7)]; end
X(~isfinite(X)) = 0;
y = G.code(k);  s = G.session(k);  v = G.severity(k);
[~, j] = ismember(s, sess);  fold = foldOf(j);  fold = fold(:);
end
