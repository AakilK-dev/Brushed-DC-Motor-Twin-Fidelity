function R = sens_verdict(vBase, bBase, vVar, bVar)

qb = quantile(bBase(:), [0.025 0.975]);
qv = quantile(bVar(:),  [0.025 0.975]);
qd = quantile(bVar(:) - bBase(:), [0.025 0.975]);
R.lo = qv(1);  R.hi = qv(2);
R.d  = vVar - vBase;  R.dlo = qd(1);  R.dhi = qd(2);
R.cBase = sign_of(qb);  R.cVar = sign_of(qv);
R.holds = R.cVar == R.cBase;
R.moved = qd(1) > 0 || qd(2) < 0;
end

function c = sign_of(q)
if q(1) > 0, c = 1; elseif q(2) < 0, c = -1; else, c = 0; end
end
