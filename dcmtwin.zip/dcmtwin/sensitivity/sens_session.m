function out = sens_session(outdir, row, Tr0, v, p, F, opt)

if nargin < 7, opt = struct(); end
if ~isfield(opt, 'forceRuns'),  opt.forceRuns = {[], [], []}; end
if ~isfield(opt, 'forceBench'), opt.forceBench = false; end
if ~isfield(opt, 'keep'),       opt.keep = false; end
if isempty(v), code = 'none'; else, code = v.code; end
[pRef, pTwin, pBench] = sens_params(p, v);
bench = opt.forceBench || (~isempty(v) && v.bench);

L  = load(fullfile(outdir, sprintf('machine_%04d.mat', row.machine)), 'R');  R0 = L.R;
Rf = sens_factors(R0, v);
Tr = Tr0;
if bench
    qb = true_machine(pBench, Rf);  qb.theta = R0.theta;  qb.machine = R0.machine;
    Rb = ensemble_tests(qb, cfg_model3(), 2026*1e5 + R0.machine*100, struct());
    Rb.factors = Rf.factors;  Rb.names = Rf.names;
    I  = identify_machine(Rb, p);
    Tr = struct('machine', R0.machine, 'M1_R', I.M1.R, 'M1_L', I.M1.L, 'M1_Ke', I.M1.Ke, ...
                'M1_J', I.M1.J, 'M1_b_lin', I.M1.b_lin, 'M2_R', I.M2.R, 'M2_L', I.M2.L, ...
                'M2_Ke', I.M2.Ke, 'M2_J', I.M2.J, 'M2_b', I.M2.b, 'M2_Tc', I.M2.Tc);
end

X = cell(1, 3);  changed = cell(1, 3);  out.flags = zeros(1, 3);  out.nSim = zeros(1, 3);
for d = 1:3
    Lx = load(fullfile(outdir, 'datasets', sprintf('M%d', d), sprintf('session_%04d.mat', row.session)), 'X');
    X{d} = Lx.X;  nR = numel(X{d}.runs);
    if isempty(v), runs = [];
    elseif d == 3, runs = v.refRuns;
    else, runs = v.twinRuns{d};
    end
    if bench && d < 3, runs = 1:nR; end
    runs = union(runs, opt.forceRuns{d});  runs = runs(runs <= nR);
    changed{d} = runs;
    if isempty(runs), continue; end
    if d == 3
        q0 = true_machine(pRef, Rf);  cfg = cfg_model3();
        q0 = service_mounting(q0, pRef, row.seed + 17);
        pd = pRef;
    else
        [q0, cfg] = calibrated_twin(pTwin, Tr, d);
        pd = pTwin;
    end
    for i = runs(:)'
        theta = row.theta_degC;
        if d == 3 && i == 1 && strcmp(code, 'coolbase'), theta = theta - v.value; end
        X{d}.runs(i) = sim_run(q0, cfg, row, i, pd, theta);
        f = X{d}.runs(i).flags;  out.flags(d) = out.flags(d) + (f.nan || f.clipCur || f.clipAcc);
    end
    out.nSim(d) = numel(runs);
end

pairs = [1 1; 2 2; 3 1; 3 2];
twinNew = bench || ~isequaln(pTwin, p);
Z = cell(3, 2);  out.nFail = zeros(1, 4);
for k = 1:4
    d = pairs(k,1);  t = pairs(k,2);
    Lz = load(fullfile(outdir, 'estimates', sprintf('D%d_T%d', d, t), sprintf('session_%04d.mat', row.session)), 'Z');
    Zk = Lz.Z;
    if twinNew, redo = 1:numel(X{d}.runs); else, redo = changed{d}; end
    if ~isempty(redo)
        [q, ~] = calibrated_twin(pTwin, Tr, t);
        q.J = q.J + pTwin.brake.J;  q.TL = pTwin.TLfrac*pTwin.Kt*pTwin.Irated;
        o = F.(sprintf('o%d', t));
        for i = redo(:)'
            E = ekf_twin(X{d}.runs(i).rec, q, t, o);
            Zk.runs(i).final = E.final;  Zk.runs(i).innov = E.innov;
            out.nFail(k) = out.nFail(k) + double(isfield(E, 'failed') && E.failed);
        end
    end
    Z{d, t} = Zk;
end

band = [5500 7000];  if ~isempty(v), band = band*v.band; end
names = {'healthy', 'resistive', 'shorted_bar', 'bearing_outer', 'imbalance'};
out.F = cell(1, 3);
for d = 1:3
    Zs = {[], []};
    if d ~= 2, Zs{1} = Z{d,1}; end
    if d ~= 1, Zs{2} = Z{d,2}; end
    Fd = features_core(X{d}, Zs, band);
    [~, cd] = ismember(Fd.state, names);
    out.F{d} = struct('A', Fd.A, 'B1', Fd.B{1}, 'B2', Fd.B{2}, 'code', cd(:), ...
                      'severity', Fd.severity(:), 'session', repmat(row.session, numel(cd), 1));
end
out.Tr = Tr;
if opt.keep
    out.X = X;  out.Z = Z;  out.changed = changed;
end
end

function r = sim_run(q0, cfg, row, i, p, theta)
Tp = 2.5;  V0 = row.duty*p.Vs;
plan = {'baseline',[]; 'healthy',[]; 'resistive',row.res_s; 'shorted_bar',row.sc_r; ...
        'bearing_outer',row.brg_D; 'imbalance',row.imb_mr};
sev  = [NaN, NaN, row.res_s, row.sc_f, row.brg_D, row.imb_mr];
base = row.seed + 10*i;
q = q0;  q.theta = theta;
if ~isempty(plan{i,2}), q = apply_fault(q, plan{i,1}, plan{i,2}); end
[q, dsv] = service_conditions(q, p, true, base + 1);
q.cur = p.cur_svc;
q.vsense = p.vsense_svc;
if cfg.bearing, q = make_bearing_noise(q, cfg, Tp, base + 2); end
qT = q;
dz  = excitation('dither','V0',V0,'amp',0.02,'thold',0.02,'tEnd',Tp,'seed',base + 3);
out = run_sim(q, cfg, dz, Tp, steady_start(q, cfg, V0));
s   = virtual_sensors(out, q, base + 4, {'cur','vsup','enc','acc'});
rec = compact(s);
fl.nan     = any(isnan(rec.cur.y)) || any(isnan(rec.enc.y)) || any(isnan(rec.acc.y)) || any(isnan(rec.vsup.y));
fl.clipCur = max(abs(double(rec.cur.y))) >= 0.999*cur_range(q.cur);
fl.clipAcc = max(abs(double(rec.acc.y))) >= 0.999*p.acc.range;
tr.R   = qT.R*(1 + qT.alpha*qT.theta*cfg.thermal);
tr.L   = qT.L;  tr.Ke = qT.Ke;  tr.Kt = qT.Kt;  tr.J = qT.J;
if strcmp(cfg.friction, 'viscous'), tr.b = qT.b_lin; tr.Tc = 0; else, tr.b = qT.b; tr.Tc = qT.Tc; end
tr.TL = qT.TL + qT.dTL;  tr.eVs = dsv.eVs;  tr.mr = qT.mr;
r = struct('state',plan{i,1},'severity',sev(i),'rec',rec,'truth',tr, ...
           'flags',fl,'seeds',base + (1:4));
end

function x0 = steady_start(q, cfg, V)
idx = state_index(cfg);  R = q.R;
if cfg.thermal, R = R*(1 + q.alpha*q.theta); end
V  = V*(1 + q.eVs);  TL = q.TL + q.dTL;
if strcmp(cfg.friction, 'viscous')
    w0 = (q.Kt*V/R - TL)/(q.Kt*q.Ke/R + q.b_lin);
else
    w0 = (q.Kt*V/R - q.Tc - TL)/(q.Kt*q.Ke/R + q.b);
end
x0 = zeros(idx.n,1);  x0(idx.i) = (V - q.Ke*w0)/R;  x0(idx.w) = w0;
end

function c = compact(s)
c = struct();
for f = {'cur','vsup','enc','acc'}
    ch = s.(f{1});  c.(f{1}).fs = 1/(ch.t(2) - ch.t(1));
    switch f{1}
        case 'cur',  c.cur.y  = single(ch.i);
        case 'vsup', c.vsup.y = single(ch.v);
        case 'enc',  c.enc.y  = single(ch.theta);
        case 'acc',  c.acc.y  = single(ch.a);
    end
end
end
