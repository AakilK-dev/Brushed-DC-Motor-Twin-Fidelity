function R = sens_factors(R, v)

if isempty(v) || ~strcmp(v.code, 'spread'), return; end
u = params_uncertainty();
j = find(strcmp(u.factors(:,1), v.factor));
r = find(strcmp(R.names, v.factor));
if isempty(j) || isempty(r), error('sens_factors:name', 'no factor "%s"', v.factor); end
f = R.factors(r);  cv = u.factors{j,3};  k = v.value;
switch u.factors{j,2}
    case 'normal'
        g = 1 + k*(f - 1);
    case 'lognormal'
        s  = sqrt(log(1 + cv^2));  s2 = sqrt(log(1 + (k*cv)^2));
        z  = (log(f) + s^2/2)/s;
        g  = exp(-s2^2/2 + s2*z);
    otherwise
        error('sens_factors:dist', 'unknown distribution "%s"', u.factors{j,2});
end
R.factors(r) = g;
end
