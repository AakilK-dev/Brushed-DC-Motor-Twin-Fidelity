function Z = run_sensitivity(outdir, opts)

if nargin < 2, opts = struct(); end
nPer  = getdef(opts, 'nPer', 20);
nBoot = getdef(opts, 'nBoot', 2000);
only  = getdef(opts, 'variants', {});
p = params_default();
V = sens_variants();
if ~isempty(only), V = V(ismember({V.name}, only)); end
U = sens_subset(outdir, nPer);
L = load(fullfile(outdir, 'datasets', 'sessions.mat'), 'S');  S = tab_cols(L.S);
L = load(fullfile(outdir, 'calibration.mat'), 'T');           Tc = tab_cols(L.T);
L = load(fullfile(outdir, 'ekf_settings.mat'), 'F');          F = L.F;
sess = U.session(:);  nS = numel(sess);
rows = cell(nS, 1);  trs = cell(nS, 1);
for j = 1:nS
    rows{j} = tab_row(S, find(S.session == sess(j)));
    trs{j}  = tab_row(Tc, find(Tc.machine == rows{j}.machine));
end
rs = RandStream('mt19937ar', 'Seed', 20261104);
foldOf = zeros(nS, 1);  foldOf(randperm(rs, nS)) = mod((1:nS)' - 1, 5) + 1;
seedFit = 20261106;
sd = fullfile(outdir, 'sensitivity');  if ~exist(sd, 'dir'), mkdir(sd); end
prov0 = struct('subset', sess, 'folds', foldOf, 'tuned', F.date, 'o1', F.o1, 'o2', F.o2, ...
               'p', physics_provenance(p), 'seedFit', seedFit);
fprintf('\nSensitivity analysis: %d variants on %d sessions (%d per duty), %d resamples\n', ...
        numel(V), nS, nPer, nBoot);

f = fullfile(sd, 'replay.mat');  prov = prov0;
[ok, Lr] = finished(f, prov);
if ok, chk = Lr.chk;
else
    t0 = tic;
    out = sens_session(outdir, rows{1}, trs{1}, [], p, F, ...
                       struct('forceRuns', {{1:6, 1:6, 1:6}}, 'forceBench', true, 'keep', true));
    chk = replay_compare(outdir, rows{1}, trs{1}, out);  chk.minutes = toc(t0)/60;
    save(f, 'chk', 'prov');
end
fprintf('Replay check, session %d (machine %d), at the base parameters:\n', rows{1}.session, rows{1}.machine);
fprintf('  calibration from new bench tests against stage 4      largest relative difference %.2g\n', chk.cal);
fprintf('  every run''s records, Models 1, 2, 3, against stage 7   largest difference %.2g of each channel''s range\n', chk.rec);
fprintf('  filter estimates against stage 8                       largest relative difference %.2g\n', chk.est);
if ~chk.ok
    error('run_sensitivity:replay', ['the sensitivity code does not reproduce the stage 4, 7 and 8 results at the base ' ...
          'parameters, so its variants would not be paired with the base']);
end
fprintf('  the sensitivity code reproduces the base: every variant differs from it by the variant alone\n');

f = fullfile(sd, 'base', 'result.mat');  prov = prov0;  prov.variant = 'base';
[ok, Lb] = finished(f, prov);
if ok
    Fb = Lb.Fv;  Sb = Lb.Sv;  c9 = Lb.c9;
else
    Fb = run_variant(outdir, rows, trs, [], p, F);
    c9 = compare_stage9(outdir, Fb, sess);
    if c9.diff > 1e-9
        error('run_sensitivity:features', ['the base features recomputed by features_core differ from stage 9''s ' ...
              'by up to %.3g: the variants would not be paired with the base'], c9.diff);
    end
    Sb = sens_scores(Fb, sess, foldOf, seedFit);
    save_result(f, Fb, Sb, prov, c9, [], 0);
end
if c9.diff == 0, fprintf('Base features recomputed by features_core: identical to stage 9''s to the last bit (%d runs).\n', c9.n);
else, fprintf('Base features recomputed by features_core: agree with stage 9''s to %.2g (%d runs).\n', c9.diff, c9.n); end

Sv = cell(1, numel(V));
info = repmat(struct('minutes', 0, 'nSim', [0 0 0], 'flags', [0 0 0], 'nFail', [0 0 0 0]), 1, numel(V));
for iv = 1:numel(V)
    v = V(iv);  f = fullfile(sd, v.name, 'result.mat');  prov = prov0;  prov.variant = v;
    [ok, Lv] = finished(f, prov);
    if ok
        li = Lv.info;  if ~isfield(li, 'nFail'), li.nFail = nan(1, 4); end
        Sv{iv} = Lv.Sv;  info(iv) = struct('minutes', li.minutes, 'nSim', li.nSim, 'flags', li.flags, 'nFail', li.nFail);
        fprintf('variant %2d of %d  %-14s already finished\n', iv, numel(V), v.name);
        continue
    end
    t0 = tic;
    [Fv, inf1] = run_variant(outdir, rows, trs, v, p, F);
    Sv{iv} = sens_scores(Fv, sess, foldOf, seedFit);
    info(iv) = struct('minutes', toc(t0)/60, 'nSim', inf1.nSim, 'flags', inf1.flags, 'nFail', inf1.nFail);
    save_result(f, Fv, Sv{iv}, prov, [], info(iv), 1);
    fprintf(['variant %2d of %d  %-14s %5.1f min   runs re-simulated: reference %d, Model 2 %d, ' ...
             'Model 1 %d;  flagged %d;  filters diverged %d\n'], iv, numel(V), v.name, info(iv).minutes, ...
             info(iv).nSim(3), info(iv).nSim(2), info(iv).nSim(1), sum(info(iv).flags), sum(info(iv).nFail));
end

rb = RandStream('mt19937ar', 'Seed', 20261105);  W = zeros(nS, nBoot);
for b = 1:nBoot, W(:,b) = accumarray(randi(rb, nS, nS, 1), 1, [nS 1]); end
Tb = sens_stats(Sb, ones(nS, 1));  Tbb = sens_stats(Sb, W);
nT = numel(Tb.names);
R = repmat(sens_verdict(0, zeros(1,2), 0, zeros(1,2)), numel(V), nT);
Tv = cell(1, numel(V));
for iv = 1:numel(V)
    Tv{iv} = sens_stats(Sv{iv}, ones(nS, 1));  Tvb = sens_stats(Sv{iv}, W);
    for r = 1:nT, R(iv, r) = sens_verdict(Tb.v(r), Tbb.v(r,:), Tv{iv}.v(r), Tvb.v(r,:)); end
end
base = struct('v', Tb.v, 'lo', quantile(Tbb.v, 0.025, 2), 'hi', quantile(Tbb.v, 0.975, 2), ...
              'fwd23', Tb.fwd23, 'fwd23lo', quantile(Tbb.fwd23, 0.025), 'fwd23hi', quantile(Tbb.fwd23, 0.975));
Z = struct('V', V, 'U', U, 'names', {Tb.names}, 'base', base, 'R', R, 'Tv', {Tv}, 'info', info, ...
           'nBoot', nBoot, 'folds', foldOf, 'replay', chk, 'stage9', c9);
report(Z);
dr = fullfile(outdir, 'results');  if ~exist(dr, 'dir'), mkdir(dr); end
save(fullfile(dr, 'sensitivity.mat'), 'Z');
write_csv(fullfile(outdir, 'sensitivity_summary.csv'), Z);
fprintf('Saved results/sensitivity.mat and sensitivity_summary.csv\n\n');
end

function [Fv, info] = run_variant(outdir, rows, trs, v, p, F)
nS = numel(rows);  parts = cell(nS, 1);  nSim = zeros(nS, 3);  flags = zeros(nS, 3);  nFail = zeros(nS, 4);
parfor j = 1:nS
    out = sens_session(outdir, rows{j}, trs{j}, v, p, F);
    parts{j} = out.F;  nSim(j,:) = out.nSim;  flags(j,:) = out.flags;  nFail(j,:) = out.nFail;
end
Fv = cell(1, 3);
for d = 1:3
    G = cellfun(@(c) c{d}, parts, 'UniformOutput', false);  G = [G{:}];
    Fv{d} = struct('A', vertcat(G.A), 'B1', vertcat(G.B1), 'B2', vertcat(G.B2), ...
                   'code', vertcat(G.code), 'severity', vertcat(G.severity), 'session', vertcat(G.session));
end
info = struct('nSim', sum(nSim, 1), 'flags', sum(flags, 1), 'nFail', sum(nFail, 1));
end

function c = replay_compare(outdir, row, tr0, out)
fl = {'M1_R','M1_L','M1_Ke','M1_J','M1_b_lin','M2_R','M2_L','M2_Ke','M2_J','M2_b','M2_Tc'};
c.cal = 0;
for k = 1:numel(fl), c.cal = max(c.cal, abs(out.Tr.(fl{k})/tr0.(fl{k}) - 1)); end
c.rec = 0;  c.est = 0;
for d = 1:3
    L = load(fullfile(outdir, 'datasets', sprintf('M%d', d), sprintf('session_%04d.mat', row.session)), 'X');
    for i = out.changed{d}(:)'
        for ch = {'cur', 'vsup', 'enc', 'acc'}
            a = double(L.X.runs(i).rec.(ch{1}).y);  b = double(out.X{d}.runs(i).rec.(ch{1}).y);
            if numel(a) ~= numel(b), c.rec = Inf; continue; end
            c.rec = max(c.rec, max(abs(a - b))/max(max(abs(a)), eps));
        end
    end
end
pairs = [1 1; 2 2; 3 1; 3 2];
for k = 1:4
    d = pairs(k,1);  t = pairs(k,2);
    L = load(fullfile(outdir, 'estimates', sprintf('D%d_T%d', d, t), sprintf('session_%04d.mat', row.session)), 'Z');
    for i = 1:numel(L.Z.runs)
        a = L.Z.runs(i).final;  b = out.Z{d,t}.runs(i).final;
        for g = {'R', 'Ke', 'L', 'b', 'h2'}
            c.est = max(c.est, abs(b.(g{1})/a.(g{1}) - 1));
        end
    end
end
c.ok = c.cal < 1e-6 && c.rec < 1e-6 && c.est < 1e-6;
end

function c = compare_stage9(outdir, Fb, sess)
nA = {'A_spv','A_cur','A_i1','A_i2','A_i24','A_vrms','A_kurt','A_crest','A_v1','A_env'};
nB = {'B_R','B_Ke','B_L','B_Tf','B_h2','B_nis','B_rmsi','X_w','X_bbase'};
c.diff = 0;  c.n = 0;
for d = 1:3
    L = load(fullfile(outdir, 'features', sprintf('F_D%d.mat', d)), 'FT');
    A = tab_cols(L.FT.A);  k = ismember(A.session, sess);
    a9 = cols(A, nA);  a9 = a9(k,:);
    c.diff = max([c.diff; abs(a9(:) - Fb{d}.A(:))]);  c.n = c.n + nnz(k);
    if ~isequal(A.session(k), Fb{d}.session), c.diff = Inf; end
    for t = 1:2
        if ~isfield(L.FT.B, sprintf('T%d', t)), continue; end
        B = tab_cols(L.FT.B.(sprintf('T%d', t)));  b9 = cols(B, nB);  b9 = b9(k,:);
        bb = Fb{d}.(sprintf('B%d', t));
        if ~isequal(size(b9), size(bb)), c.diff = Inf; continue; end
        c.diff = max([c.diff; abs(b9(:) - bb(:))]);
    end
end
end

function X = cols(S, names)
X = zeros(numel(S.(names{1})), numel(names));
for k = 1:numel(names), X(:,k) = S.(names{k}); end
end

function [ok, L] = finished(f, prov)
ok = false;  L = [];
if exist(f, 'file') ~= 2, return; end
try
    L = load(f);  ok = isfield(L, 'prov') && isequaln(L.prov, prov);
catch
    ok = false;
end
if ~ok, L = []; end
end

function save_result(f, Fv, Sv, prov, c9, info, isVariant)
d = fileparts(f);  if ~exist(d, 'dir'), mkdir(d); end
tmp = fullfile(d, 'tmp_result.mat');
if isVariant, save(tmp, 'Fv', 'Sv', 'prov', 'info', '-v7');
else,         save(tmp, 'Fv', 'Sv', 'prov', 'c9', '-v7'); end
movefile(tmp, f);
end

function report(Z)
fprintf('\nSENSITIVITY: the four tracked results under every variant (percentage points; 95%% intervals)\n');
for r = 1:numel(Z.names)
    b = Z.base;
    fprintf('\n%d  %s.  Base %.1f [%.1f, %.1f]', r, Z.names{r}, 100*b.v(r), 100*b.lo(r), 100*b.hi(r));
    if r == 1
        fprintf('\n   %-34s %-26s %-22s %-24s %s\n', 'assumption', 'variant', 'result', 'change (paired)', 'verdict');
    else
        cb = 0;  if b.lo(r) > 0, cb = 1; elseif b.hi(r) < 0, cb = -1; end
        fprintf(', so the base conclusion is %s\n', concl(cb));
        fprintf('   %-34s %-26s %-22s %-24s %s\n', 'assumption', 'variant', 'result', 'change (paired)', 'verdict');
    end
    for iv = 1:numel(Z.V)
        x = Z.R(iv, r);
        res = sprintf('%.1f [%.1f, %.1f]', 100*Z.Tv{iv}.v(r), 100*x.lo, 100*x.hi);
        chg = sprintf('%+.1f [%+.1f, %+.1f]', 100*x.d, 100*x.dlo, 100*x.dhi);
        if r == 1
            vd = 'no change detected';  if x.moved, vd = 'moves'; end
        else
            vd = 'holds';  if ~x.holds, vd = sprintf('CHANGES (%s)', concl(x.cVar)); end
        end
        fprintf('   %-34s %-26s %-22s %-24s %s\n', Z.V(iv).group, Z.V(iv).level, res, chg, vd);
    end
end
if numel(Z.V) > 0
    nh = arrayfun(@(x) x.holds, Z.R(:, 2:end));
    fprintf('\nConclusions 2 to 4 hold under %d of %d variant results; forward 2->3 accuracy, base %.1f [%.1f, %.1f].\n', ...
            nnz(nh), numel(nh), 100*Z.base.fwd23, 100*Z.base.fwd23lo, 100*Z.base.fwd23hi);
    nf = vertcat(Z.info.nFail);  bad = find(any(nf > 0, 2));
    if isempty(bad)
        fprintf('Filter divergences under the variants: none.\n');
    else
        fprintf(['Filter divergences under the variants (runs; Model 1 data with twin 1, Model 2 with twin 2, ' ...
                 'reference with twin 1, reference with twin 2):\n']);
        for iv = bad(:)'
            fprintf('   %-14s %3d  (%d, %d, %d, %d)\n', Z.V(iv).name, sum(nf(iv,:)), nf(iv,1), nf(iv,2), nf(iv,3), nf(iv,4));
        end
    end
end
end

function t = concl(c)
switch c
    case 1,  t = 'positive (interval above zero)';
    case -1, t = 'negative (interval below zero)';
    otherwise, t = 'a null (interval includes zero)';
end
end

function write_csv(f, Z)
fid = fopen(f, 'w');
fprintf(fid, 'variant,assumption,level,base_level');
for r = 1:numel(Z.names)
    fprintf(fid, ',r%d_value,r%d_lo,r%d_hi,r%d_change,r%d_change_lo,r%d_change_hi,r%d_%s', r, r, r, r, r, r, r, ...
            ifelse(r == 1, 'moved', 'holds'));
end
fprintf(fid, ',fwd23_value,filters_diverged\n');
fprintf(fid, 'base,,,');
for r = 1:numel(Z.names)
    fprintf(fid, ',%.4f,%.4f,%.4f,0,0,0,', Z.base.v(r), Z.base.lo(r), Z.base.hi(r));
end
fprintf(fid, ',%.4f,0\n', Z.base.fwd23);
for iv = 1:numel(Z.V)
    fprintf(fid, '%s,"%s","%s","%s"', Z.V(iv).name, Z.V(iv).group, Z.V(iv).level, Z.V(iv).base);
    for r = 1:numel(Z.names)
        x = Z.R(iv, r);  flag = x.holds;  if r == 1, flag = x.moved; end
        fprintf(fid, ',%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%d', Z.Tv{iv}.v(r), x.lo, x.hi, x.d, x.dlo, x.dhi, flag);
    end
    fprintf(fid, ',%.4f,%g\n', Z.Tv{iv}.fwd23, sum(Z.info(iv).nFail));
end
fclose(fid);
end

function v = ifelse(c, a, b)
if c, v = a; else, v = b; end
end

function v = getdef(s, f, d)
if isfield(s, f), v = s.(f); else, v = d; end
end
