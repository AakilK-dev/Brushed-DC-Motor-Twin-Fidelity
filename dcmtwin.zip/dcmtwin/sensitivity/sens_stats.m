function T = sens_stats(S, W)

acc = (S.ok'*W)./max(S.n'*W, eps);
rAB = (S.okSmall(:,1)'*W)./max(S.nSmall'*W, eps);
rA  = (S.okSmall(:,2)'*W)./max(S.nSmall'*W, eps);
T.v = [acc(1,:); acc(1,:) - acc(3,:); acc(4,:) - acc(5,:); rAB - rA];
T.fwd23 = acc(3,:);  T.acc = acc;  T.recallAB = rAB;  T.recallA = rA;
T.names = {'Within-reference accuracy', 'Transfer gap from Model 2', ...
           'Model 2 minus Model 1, shared four', 'Set B gain, smallest resistive third'};
end
