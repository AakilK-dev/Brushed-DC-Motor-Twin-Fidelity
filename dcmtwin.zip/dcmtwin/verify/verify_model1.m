function verify_model1()

p   = params_default();
cfg = cfg_model1();
V   = p.Vs;

w_ss  = p.Kt*V/(p.R*p.b_lin + p.Kt*p.Ke);
i_ss  = (V - p.Ke*w_ss)/p.R;
tau_e = p.L/p.R;
tau_m = p.J*p.R/(p.Kt*p.Ke);

fprintf('\nModel 1 verification\n');
fprintf('closed form: w_ss = %.4f rad/s (%.1f rpm), i_ss = %.4f A\n', ...
        w_ss, w_ss*60/(2*pi), i_ss);
fprintf('closed form: tau_e = %.4e s, tau_m = %.4e s, tau_m/tau_e = %.1f\n\n', ...
        tau_e, tau_m, tau_m/tau_e);

out = run_sim(p, cfg, @(t) V, 20*tau_m);
w   = out.x(:,out.idx.w);
i   = out.x(:,out.idx.i);

report('steady state speed',   w(end), w_ss, 1e-3);
report('steady state current', i(end), i_ss, 1e-3);

[~,jm] = min(abs(w - 0.632*w_ss));
report('mechanical time constant', out.t(jm), tau_m, 5e-2);

cfgLR = cfg;  cfgLR.locked_rotor = true;
Vlr   = 0.1*p.Irated*p.R;
outLR = run_sim(p, cfgLR, @(t) Vlr, 15*tau_e);
iLR   = outLR.x(:,outLR.idx.i);

[~,je] = min(abs(iLR - 0.632*Vlr/p.R));
report('locked rotor steady current', iLR(end), Vlr/p.R, 1e-4);
report('electrical time constant',    outLR.t(je), tau_e, 2e-2);

cfg2 = cfg; cfg2.dt = cfg.dt/2;
out2 = run_sim(p, cfg2, @(t) V, 20*tau_m);
report('step halving, final speed', out2.x(end,out2.idx.w), w(end), 1e-6);

fprintf('\n');
end

function report(name, got, want, tol)
err    = abs(got-want)/max(abs(want),eps);
status = 'FAIL';
if err <= tol, status = 'pass'; end
fprintf('%-30s got %12.6g   expected %12.6g   rel err %8.2e   [%s]\n', ...
        name, got, want, err, status);
end
