function verify_sampler()

p = params_default();
u = params_uncertainty();
n = 500;
S = sample_machines(p, n, 11);
k = size(u.factors,1);

fprintf('\nMachine sampler verification, %d machines\n\n', n);

ok = true;
for j = 1:k+1
    strata = sort(floor(S.U(:,j)*n));
    ok = ok && isequal(strata', 0:n-1);
end
pass_or_fail('one sample per stratum, every factor', ok);

for j = 1:k
    cv = u.factors{j,3};
    report(sprintf('factor %-4s mean', u.factors{j,1}), mean(S.F(:,j)), 1,  0.01);
    report(sprintf('factor %-4s cov',  u.factors{j,1}), std(S.F(:,j)),  cv, 0.05);
end

rKe = arrayfun(@(q) q.Ke/q.Kt, S.P);
rTc = arrayfun(@(q) q.Tc/q.b_lin, S.P);
rb  = arrayfun(@(q) q.b/q.b_lin, S.P);
report('Ke/Kt constant across machines', max(rKe)-min(rKe), 0, 1e-12, true);
report('Tc/b_lin constant across machines', max(rTc)-min(rTc), 0, 1e-9, true);
report('b/b_lin constant across machines',  max(rb)-min(rb),   0, 1e-12, true);

pass_or_fail('temperature within [0, 70]', all(S.theta >= 0 & S.theta <= 70));
report('temperature mean', mean(S.theta), 35, 0.02);

C = corrcoef([S.F S.theta]);
off = max(abs(C(~eye(size(C)))));
lim = 4/sqrt(n);
fprintf('%-34s %.4f   (limit %.4f)\n', 'largest correlation between factors', off, lim);
pass_or_fail('factors effectively uncorrelated', off < lim);

S2 = sample_machines(p, n, 11);
report('same seed, same ensemble', max(abs(S.F(:) - S2.F(:))), 0, 0, true);
fprintf('\n');
end

function report(name, got, want, tol, absolute)
if nargin > 4 && absolute
    ok = abs(got - want) <= tol;
else
    ok = abs(got - want)/max(abs(want),eps) <= tol;
end
status = 'FAIL';  if ok, status = 'pass'; end
fprintf('%-34s got %12.6g   expected %12.6g   [%s]\n', name, got, want, status);
end

function pass_or_fail(name, ok)
status = 'FAIL';  if ok, status = 'pass'; end
fprintf('%-34s %41s[%s]\n', name, '', status);
end
