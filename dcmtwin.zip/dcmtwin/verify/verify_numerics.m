function verify_numerics()

p = params_default();
fprintf('\nNumerical parameter verification\n\n');

c2 = cfg_model2();  c2.gearbox = false;  c2.thermal = false;  c2.imbalance = false;  c2.modes = [];
w0 = (p.Kt*p.Vs/p.R - p.Tc)/(p.Kt*p.Ke/p.R + p.b);
idx = state_index(c2);  x0 = zeros(idx.n,1);  x0(idx.w) = w0;
c2c = c2;  c2c.dt = 1e-4;
cd = excitation('coastdown','V0',p.Vs,'toff',0);
tA = stop_time(run_sim(p, c2c, cd, 5.0, x0), w0);
pB = p;  pB.beta = 2*p.beta;  pB.wt = 1/pB.beta;
tB = stop_time(run_sim(pB, c2c, cd, 5.0, x0), w0);
report('coast stop time, beta doubled', tB, tA, 1e-3);
oS1 = run_sim(p,  c2, @(t) 0.6*p.Vs, 0.3);
oS2 = run_sim(pB, c2, @(t) 0.6*p.Vs, 0.3);
report('steady speed, beta doubled', oS2.x(end,oS2.idx.w), oS1.x(end,oS1.idx.w), 1e-6);

c3 = cfg_model3();
[I1, h1, v1] = m3_run(p, c3, 1e-5);
[I2, h2, v2] = m3_run(p, c3, 5e-6);
report('Model 3 mean current, dt halved', I2, I1, 1e-4);
report('Model 3 2nd harmonic, dt halved', h2, h1, 1e-2);
report('Model 3 vibration RMS, dt halved', v2, v1, 0.10);

for m = 1:2
    if m == 1, c = cfg_model1(); else, c = cfg_model2(); c.thermal = false; end
    pI = p;  pI.mr = 2e-5;
    cf = c;  cc = c;  cc.dt = 1e-4;
    oF = run_sim(pI, cf, @(t) 0.6*p.Vs, 0.6);
    oC = run_sim(pI, cc, @(t) 0.6*p.Vs, 0.6);
    report(sprintf('Model %d speed, 100 us step', m), oC.x(end,oC.idx.w), oF.x(end,oF.idx.w), 1e-4);
    report(sprintf('Model %d current, 100 us step', m), oC.x(end,oC.idx.i), oF.x(end,oF.idx.i), 1e-3);
    if m == 2
        kF = oF.t > 0.4;  kC = oC.t > 0.4;
        aF = (max(oF.x(kF,oF.idx.y(1))) - min(oF.x(kF,oF.idx.y(1))))/2;
        aC = (max(oC.x(kC,oC.idx.y(1))) - min(oC.x(kC,oC.idx.y(1))))/2;
        report('Model 2 mode amplitude, 100 us step', aC, aF, 1e-2);
    end
end
pE = params_default();  pE.eVs = 0.004;  pE.TL = 0.1;  pE.dTL = 0.003;
cE = cfg_model3();  TE = 0.03;
pE = make_bearing_noise(pE, cE, TE, 4242);
prE = excitation('prbs','Vlo',14,'Vhi',14.8,'thold',0.005,'tEnd',TE,'seed',9);
xE = steady_x0(pE, cE, 14.4);
oN = run_sim(pE, cE, prE, TE, xE);
oR = run_sim_reference(pE, cE, prE, TE, xE);
pass_or_fail('optimised loop identical to original, Model 3 in service', ...
    isequal(oN.x, oR.x) && isequal(oN.V, oR.V) && isequal(oN.dx, oR.dx));
c2 = cfg_model2();  c2.dt = 1e-4;  c2.modes = [];  c2.gearbox = false;
cd = excitation('coastdown','V0',14.4,'toff',0.2);
oN = run_sim(params_default(), c2, cd, 0.5, steady_x0(params_default(), c2, 14.4));
oR = run_sim_reference(params_default(), c2, cd, 0.5, steady_x0(params_default(), c2, 14.4));
pass_or_fail('optimised loop identical to original, across a disconnection', ...
    isequal(oN.x, oR.x) && isequal(oN.open, oR.open));
pr2 = excitation('dither','V0',14.4,'amp',0.02,'thold',0.02,'tEnd',1,'seed',5);
tt = linspace(0, 1, 20001);  lev = prbs_levels_reference(0.02, 1, 5);
vOld = arrayfun(@(t) 14.4*(1 + 0.02*(2*lookup_reference(t, lev.tsw, lev.lev) - 1)), tt);
vNew = arrayfun(pr2.V, tt);
pass_or_fail('excitation levels built once give identical values', isequal(vOld, vNew));

fprintf('\n');
end

function ts = stop_time(o, w0)
k  = find(o.x(:,o.idx.w) < 0.01*w0, 1, 'first');
ts = o.t(k);
end

function [Im, h2, vr] = m3_run(p, c, dt)
c.dt = dt;  T = 0.4;  tA = 0.15;
q = make_bearing_noise(p, c, T, 5);
o = run_sim(q, c, @(t) 0.6*p.Vs, T);
k = o.t >= tA;
[a, dc] = order_amplitude(o.x(k,o.idx.i), o.x(k,o.idx.th), 2);
Im = dc;  h2 = a/dc;
acc = measured_accel(o, q, 9, tA);
vr  = sqrt(mean(acc.^2));
end

function report(name, got, want, tol)
err = abs(got - want)/max(abs(want), eps);
status = 'FAIL';  if err <= tol, status = 'pass'; end
fprintf('%-38s got %12.6g   expected %12.6g   rel err %8.2e   [%s]\n', ...
        name, got, want, err, status);
end

function out = run_sim_reference(p, cfg, prof, tEnd, x0)
Vfun = prof.V;  Ofun = prof.open;
if isfield(p,'eVs') && p.eVs ~= 0
    Vset = Vfun;  Vfun = @(tt) Vset(tt)*(1 + p.eVs);
end
idx = state_index(cfg);  dt = cfg.dt;
n = floor(tEnd/dt) + 1;  t = (0:n-1)'*dt;
X = zeros(n, idx.n);  DX = X;  V = zeros(n,1);  OC = false(n,1);
X(1,:) = x0(:)';  xk = x0(:);
for k = 1:n-1
    tk = t(k);  V(k) = Vfun(tk);  OC(k) = Ofun(tk);
    f  = @(tt,xx) dcm_derivatives(tt, xx, Vfun(tt), p, cfg, idx, Ofun(tt));
    k1 = f(tk, xk);  k2 = f(tk+dt/2, xk + dt/2*k1);
    k3 = f(tk+dt/2, xk + dt/2*k2);  k4 = f(tk+dt, xk + dt*k3);
    DX(k,:) = k1';  xk = xk + dt/6*(k1 + 2*k2 + 2*k3 + k4);
    if Ofun(tk+dt), xk(idx.i) = 0; end
    X(k+1,:) = xk';
end
V(n) = Vfun(t(n));  OC(n) = Ofun(t(n));
DX(n,:) = dcm_derivatives(t(n), xk, V(n), p, cfg, idx, OC(n))';
out = struct('t',t,'x',X,'dx',DX,'V',V,'open',OC);
end

function x0 = steady_x0(p, cfg, V)
idx = state_index(cfg);
w0 = (p.Kt*V/p.R - p.Tc)/(p.Kt*p.Ke/p.R + p.b);
x0 = zeros(idx.n,1);  x0(idx.i) = (V - p.Ke*w0)/p.R;  x0(idx.w) = w0;
end

function L = prbs_levels_reference(thold, tEnd, seed)
s = RandStream('twister','Seed',seed);
L.tsw = 0;  L.lev = double(rand(s) > 0.5);
while L.tsw(end) < tEnd
    L.tsw(end+1) = L.tsw(end) + thold*(1 + floor(3*rand(s)));
    L.lev(end+1) = 1 - L.lev(end);
end
end

function v = lookup_reference(t, tsw, val)
k = find(tsw <= t, 1, 'last');  if isempty(k), k = 1; end
v = val(k);
end

function pass_or_fail(name, ok)
status = 'FAIL';  if ok, status = 'pass'; end
fprintf('%-58s [%s]\n', name, status);
end
