function verify_ekf()

fprintf('\nKalman filter verification\n\n');
p = params_default();
TL = p.TLfrac*p.Kt*p.Irated;
[rec, q] = matched_run(p, 2, 0.6, TL, 11, []);
qt = start_wrong(q, 2);
E  = ekf_twin(rec, qt, 2);
report('Model 2: resistance, started 10 percent high',        E.final.R,  q.R,  0.005);
report('Model 2: back EMF constant, started 2 percent low',   E.final.Ke, q.Ke, 0.0005);
report('Model 2: friction, started 30 percent high',          E.final.b,  q.b,  0.02);
report('Model 2: inductance, started 8 percent high',         E.final.L,  q.L,  0.05);
pass_or_fail(sprintf('Model 2: innovations consistent (mean NIS %.2f, 0.3 to 4)', E.innov.meanNIS), ...
    E.innov.meanNIS > 0.3 && E.innov.meanNIS < 4);
E2 = ekf_twin(rec, qt, 2);
pass_or_fail('Model 2: estimates reproducible', isequal(E.x, E2.x));
f  = 0.5;  k = 1 - p.sc.dK*f;
[recF, ~] = matched_run(p, 2, 0.6, TL, 11, k);
EF = ekf_twin(recF, qt, 2);
dKe = EF.final.Ke/E.final.Ke - 1;  dL = EF.final.L/E.final.L - 1;
report('shorted bar: change in Ke from normal',               dKe, k - 1,    0.03);
report('shorted bar: change in L from normal',                dL,  k^2 - 1,  0.05);
[rec1, q1] = matched_run(p, 1, 0.8, TL, 21, []);
E1 = ekf_twin(rec1, start_wrong(q1, 1), 1);
report('Model 1: resistance, started 10 percent high',        E1.final.R,  q1.R,  0.005);
report('Model 1: back EMF constant, started 2 percent low',   E1.final.Ke, q1.Ke, 0.0005);
f  = 0.59;  k = 1 - p.sc.dK*f;
recN = reference_run(p, 0, 0.8, TL, 31);  recF = reference_run(p, f, 0.8, TL, 31);
qn = p;  qn.theta = 0;  qn.mr = 0;  qn.J = p.J + p.brake.J;  qn.TL = TL;
EN = ekf_twin(recN, qn, 2);  EF = ekf_twin(recF, qn, 2);
pass_or_fail('reference shorted bar: filter stays finite', ~EF.failed && ~EN.failed);
report('reference shorted bar: change in Ke from normal', EF.final.Ke/EN.final.Ke - 1, k - 1, 0.05);
pass_or_fail(sprintf('reference shorted bar: harmonic grows (%.0f to %.0f mA)', 1e3*EN.final.h2, 1e3*EF.final.h2), ...
    EF.final.h2 > 5*EN.final.h2);
pass_or_fail(sprintf('reference shorted bar: innovations consistent (mean NIS %.2f, below 4)', EF.innov.meanNIS), ...
    EF.innov.meanNIS < 4);
fprintf('\n');
end

function rec = reference_run(p, f, duty, TL, seed)
cfg = cfg_model3();  cfg.bearing = false;  cfg.gearbox = false;
q = p;  q.theta = 0;  q.mr = 0;  q.TL = TL;  q.dTL = 0;  q.eVs = 0;
q.J = p.J + p.brake.J;  q.cur = p.cur_svc;  q.vsense = p.vsense_svc;
if f > 0
    smin = 1/(1 + p.sc.range(2));  smax = 1/(1 + p.sc.range(1));
    q = apply_fault(q, 'shorted_bar', 1/(smin + f*(smax - smin)) - 1);
end
V0 = duty*p.Vs;  Tp = 2.5;
dz = excitation('dither','V0',V0,'amp',0.02,'thold',0.02,'tEnd',Tp,'seed',seed);
idx = state_index(cfg);
w0 = (q.Kt*V0/q.R - q.Tc - TL)/(q.Kt*q.Ke/q.R + q.b);
x0 = zeros(idx.n,1);  x0(idx.i) = (V0 - q.Ke*w0)/q.R;  x0(idx.w) = w0;
out = run_sim(q, cfg, dz, Tp, x0);
s = virtual_sensors(out, q, seed + 1, {'cur','vsup','enc'});
rec.cur.y  = s.cur.i;      rec.cur.fs  = 1/(s.cur.t(2) - s.cur.t(1));
rec.vsup.y = s.vsup.v;     rec.vsup.fs = 1/(s.vsup.t(2) - s.vsup.t(1));
rec.enc.y  = s.enc.theta;  rec.enc.fs  = 1/(s.enc.t(2) - s.enc.t(1));
end

function [rec, q] = matched_run(p, model, duty, TL, seed, kTurns)
switch model
    case 1, cfg = cfg_model1();
    case 2, cfg = cfg_model2();  cfg.gearbox = false;
end
q = p;  q.theta = 0;  q.mr = 0;  q.TL = TL;  q.dTL = 0;  q.eVs = 0;
q.J = p.J + p.brake.J;  q.cur = p.cur_svc;  q.vsense = p.vsense_svc;
if ~isempty(kTurns)
    q.Ke = kTurns*q.Ke;  q.Kt = kTurns*q.Kt;  q.L = kTurns^2*q.L;  q.R = kTurns*q.R;
end
V0 = duty*p.Vs;  Tp = 2.5;
dz = excitation('dither','V0',V0,'amp',0.02,'thold',0.02,'tEnd',Tp,'seed',seed);
idx = state_index(cfg);
if strcmp(cfg.friction, 'viscous')
    w0 = (q.Kt*V0/q.R - TL)/(q.Kt*q.Ke/q.R + q.b_lin);
else
    w0 = (q.Kt*V0/q.R - q.Tc - TL)/(q.Kt*q.Ke/q.R + q.b);
end
x0 = zeros(idx.n,1);  x0(idx.i) = (V0 - q.Ke*w0)/q.R;  x0(idx.w) = w0;
out = run_sim(q, cfg, dz, Tp, x0);
s = virtual_sensors(out, q, seed + 1, {'cur','vsup','enc'});
rec.cur.y  = s.cur.i;      rec.cur.fs  = 1/(s.cur.t(2) - s.cur.t(1));
rec.vsup.y = s.vsup.v;     rec.vsup.fs = 1/(s.vsup.t(2) - s.vsup.t(1));
rec.enc.y  = s.enc.theta;  rec.enc.fs  = 1/(s.enc.t(2) - s.enc.t(1));
if model == 1, q.b = q.b_lin; end
end

function qt = start_wrong(q, model)
qt = q;  qt.R = 1.10*q.R;  qt.Ke = 0.98*q.Ke;  qt.L = 1.08*q.L;
if model == 2, qt.b = 1.3*q.b; else, qt.b_lin = 1.3*q.b_lin; end
end

function report(name, got, want, tol)
if abs(want) < 1e-12, err = abs(got - want); else, err = abs(got - want)/abs(want); end
status = 'FAIL';  if err <= tol, status = 'pass'; end
fprintf('%-58s got %11.5g   want %11.5g   [%s]\n', name, got, want, status);
end

function pass_or_fail(name, ok)
status = 'FAIL';  if ok, status = 'pass'; end
fprintf('%-58s [%s]\n', name, status);
end
