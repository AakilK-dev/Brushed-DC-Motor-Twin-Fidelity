function verify_mounting()

fprintf('\nMounting verification\n\n');
p = params_default();
Jd = [1800 3200];  md = [2.8 4.0];   % Dunkermotoren GR 80x40 and GR 80x80 data sheets
report('bench rigid-body modal mass (Dunkermotoren line at 4600 g.cm^2)', p.M, md(2) + diff(md)/diff(Jd)*(4600 - Jd(2)), 1e-9);
report('bench mode 1 damping (rubber or neoprene isolators)', p.modes.zeta(1), 0.05, 1e-9);
k = p.M*(2*pi*p.modes.f(1))^2;
pass_or_fail(sprintf('implied bench mount stiffness plausible (%.2g N/m)', k), k > 1e5 && k < 1e7);
cfg = cfg_model3();  cfg.bearing = false;  idx = state_index(cfg);
q = p;  q.mr = 1e-5;  q.theta = 0;  q.TL = 0;  q.dTL = 0;  q.eVs = 0;
x = zeros(idx.n, 1);  x(idx.w) = 300;
dx = dcm_derivatives(0, x, 0, q, cfg, idx);
a1 = dx(idx.dy(1));  aL = dx(idx.dy(end));
report('local-mode to rigid-body response ratio, M/Mhf', aL/a1, p.M/p.Mhf, 1e-9);
[qa, da] = service_mounting(p, p, 11);  [~, db] = service_mounting(p, p, 11);
pass_or_fail('service mounting reproducible from its seed', isequal(da, db));
pass_or_fail('service mounting changes only mode 1 and the modal mass', ...
    isequal(qa.modes.f(2:end), p.modes.f(2:end)) && isequal(qa.modes.zeta(2:end), p.modes.zeta(2:end)) && qa.Mhf == p.Mhf);
n = 2000;  f1 = zeros(n,1);  z1 = f1;  M = f1;
for i = 1:n, [~, d] = service_mounting(p, p, 1000 + i); f1(i) = d.f1; z1(i) = d.zeta1; M(i) = d.M; end
pass_or_fail('service damping within the rubber-to-butyl range', all(z1 >= p.mount.zeta(1) & z1 <= p.mount.zeta(2)));
pass_or_fail('service modal mass within its range', all(M >= p.M*p.mount.Mfac(1) - 1e-12 & M <= p.M*p.mount.Mfac(2) + 1e-12));
report('service frequency spread, coefficient of variation', std(f1)/mean(f1), p.mount.f1cov, 0.1);
Tr = table(p.R, p.L, p.Ke, p.J, p.b_lin, p.R, p.L, p.Ke, p.J, p.b, p.Tc, 'VariableNames', ...
    {'M1_R','M1_L','M1_Ke','M1_J','M1_b_lin','M2_R','M2_L','M2_Ke','M2_J','M2_b','M2_Tc'});
qt = calibrated_twin(p, Tr, 2);
pass_or_fail('a calibrated twin keeps the bench mounting', ...
    isequal(qt.modes, p.modes) && qt.M == p.M && qt.Mhf == p.Mhf);
mr = 2*p.J/0.025^2;
report('bench bearing load per row, rotor weight', p.brg.W, mr*p.g/4, 1e-2);
[qs, ds] = service_mounting(p, p, 5);
pass_or_fail('service installation applies the gearmotor bearing load', qs.brg.W == p.brg.W_svc && ds.W == p.brg.W_svc);
pass_or_fail('a calibrated twin keeps the bench bearing load', qt.brg.W == p.brg.W);
report('current range, ACS712-20A on 5 V', cur_range(p.cur), 20.0, 1e-9);
pass_or_fail('bench and service current channels identical', isequal(p.cur, p.cur_svc));
pass_or_fail('bench and service voltage channels identical', isequal(p.vsense, p.vsense_svc));
report('current sensor noise, ACS712-20A (11 mV p-p in 2 kHz)', p.cur.nd_sensor, (11e-3/6)/sqrt(pi/2*2000)/0.100, 0.01);   % Allegro ACS712 datasheet
report('converter noise, MCP3208 (SINAD 72 dB)', p.adc.rms, sqrt((2.4/sqrt(2)/10^(72/20))^2 - (5/4096)^2/12), 0.01);   % Microchip MCP3208 datasheet
report('accelerometer floor, sensor plus NI 9234', p.acc.nd, hypot(1.5e-6, 310e-9/0.100), 1e-9);   % PCB 352C33 specification sheet; NI-9234 specifications
fprintf('\n');
end

function report(name, got, want, tol)
err = abs(got - want)/max(abs(want), eps);
status = 'FAIL';  if err <= tol, status = 'pass'; end
fprintf('%-58s got %11.5g   want %11.5g   [%s]\n', name, got, want, status);
end

function pass_or_fail(name, ok)
status = 'FAIL';  if ok, status = 'pass'; end
fprintf('%-58s [%s]\n', name, status);
end
