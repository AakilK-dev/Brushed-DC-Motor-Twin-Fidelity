function verify_ensemble()

p   = params_default();
cfg = cfg_model3();
idx = state_index(cfg);
fprintf('\nEnsemble verification (about three minutes)\n\n');

q  = apply_fault(p, 'bearing_outer', 0.5);
q  = make_bearing_noise(q, cfg, 0.01, 1);
x  = zeros(idx.n,1);
F1 = bearing_force(0.0,   x, q, cfg, idx);
F2 = bearing_force(0.005, x, q, cfg, idx);
report('standstill force, two instants', abs(F1 - F2), 0, 1e-12, true);

ro   = 0.5*p.brg.Dp*(1 + p.brg.dDp);
wlow = 0.4*p.Vs/p.Ke;
fade = 1 - exp(-p.brg.FTF*wlow*ro/p.brg.vroll);
report('fade at 40% duty', fade, 1, 0, true);

T   = 4.5;  toff = 0.3;
prof = excitation('coastdown','V0',p.Vs,'toff',toff);
qf  = make_bearing_noise(p, cfg, T, 2);
oF  = run_sim(qf, cfg, prof, T);
cR  = cfg;  cR.commutation = false;  cR.bearing = false;  cR.modes = [];  cR.dt = 1e-4;
oR  = run_sim(p, cR, prof, T);
kF  = oF.t >= toff;  kR = oR.t >= toff;
angF = oF.x(end,oF.idx.th) - interp1(oF.t, oF.x(:,oF.idx.th), toff);
angR = oR.x(end,oR.idx.th) - interp1(oR.t, oR.x(:,oR.idx.th), toff);
report('coast angle, reduced vs full', angR, angF, 1e-3);
wF = interp1(oF.t(kF), oF.x(kF,oF.idx.w), 1.5);
wR = interp1(oR.t(kR), oR.x(kR,oR.idx.w), 1.5);
report('speed at 1.5 s, reduced vs full', wR, wF, 1e-3);

tmp  = fullfile(tempdir, 'dcm_ensemble_check');
if exist(tmp,'dir'), rmdir(tmp,'s'); end
opts = struct('Tprbs',0.5,'Tsteady',0.8,'tA',0.3);
E1 = run_ensemble(tmp, 'nBatch',2, 'maxBatch',1, 'seed',7, 'opts',opts, 'parallel',false);
nfiles = numel(dir(fullfile(tmp,'machine_*.mat')));
report('machine files written', nfiles, 2, 0, true);
pass_or_fail('summaries are finite', all(isfinite(E1.summaries(:))));
E2 = run_ensemble(tmp, 'nBatch',2, 'maxBatch',1, 'seed',7, 'opts',opts, 'parallel',false);
report('resume gives identical summaries', max(abs(E1.summaries(:) - E2.summaries(:))), 0, 0, true);
S  = sample_machines(p, 2, 8);
q1 = S.P(1);  q1.machine = 1;
R  = ensemble_tests(q1, cfg, 7*1e5 + 100, opts);
report('recompute from seed, identical', max(abs(R.summary - E1.summaries(1,:))), 0, 0, true);

lim = cur_range(p.cur);
pk  = max([max(abs(R.step.cur.y)) max(abs(R.prbs.cur.y)) ...
           arrayfun(@(z) max(abs(z.cur.y)), R.steady)]);
fprintf('%-36s %.3f A of %.3f A range\n', 'largest recorded current', pk, lim);
pass_or_fail('no test saturates the current sensor', pk < 0.99*lim);
pass_or_fail('every coast-down reaches rest', all([R.coast.stopped]));

if license('test','Distrib_Computing_Toolbox')
    tmp2 = fullfile(tempdir, 'dcm_ensemble_check_par');
    if exist(tmp2,'dir'), rmdir(tmp2,'s'); end
    E3 = run_ensemble(tmp2, 'nBatch',2, 'maxBatch',1, 'seed',7, 'opts',opts, ...
                      'parallel',true, 'workers',2);
    report('parallel equals serial', max(abs(E3.summaries(:) - E1.summaries(:))), 0, 0, true);
else
    fprintf('%-36s %s\n', 'parallel equals serial', 'skipped, toolbox not available');
end

fprintf('\nmini ensemble summaries (%s)\n', strjoin(E1.labels, ', '));
disp(E1.summaries);
end

function report(name, got, want, tol, absolute)
if nargin > 4 && absolute
    ok = abs(got - want) <= tol;
else
    ok = abs(got - want)/max(abs(want),eps) <= tol;
end
status = 'FAIL';  if ok, status = 'pass'; end
fprintf('%-36s got %12.6g   expected %12.6g   [%s]\n', name, got, want, status);
end

function pass_or_fail(name, ok)
status = 'FAIL';  if ok, status = 'pass'; end
fprintf('%-36s %41s[%s]\n', name, '', status);
end
