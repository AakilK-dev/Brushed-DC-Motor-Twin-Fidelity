function verify_bearing()

p   = params_default();
cfg = cfg_model3();
T   = 0.3;
tA  = 0.05;

fprintf('\nBearing model verification\n');
fprintf('(each run is %.1f s of simulated time; this takes a little while)\n\n', T);

w0  = (p.Kt*p.Vs/p.R - p.Tc)/(p.Kt*p.Ke/p.R + p.b);
idx = state_index(cfg);
x0  = zeros(idx.n,1);  x0(idx.i) = (p.Vs - p.Ke*w0)/p.R;  x0(idx.w) = w0;

cOff = cfg;  cOff.bearing = false;
qa = make_bearing_noise(p, cfg, T, 1);
oA = run_sim(qa, cOff, @(t) p.Vs, T, x0);
oB = run_sim(p,  cOff, @(t) p.Vs, T, x0);
report('switch-off, speed', oA.x(end,oA.idx.w), oB.x(end,oB.idx.w), 1e-12);

thg = linspace(0, 2*pi/p.brg.FTF, 4001)';
Fm  = zeros(size(thg));
for k = 1:numel(thg)
    xx = x0;  xx(idx.th) = thg(k);
    Fm(k) = -bearing_force(0, xx, p, cfg, idx);
end
report('mean vertical load', mean(Fm), p.brg.W, 1e-2);

for loc = {'outer','inner'}
    q = apply_fault(p, ['bearing_' loc{1}], 0.3);
    nrev = 1000;  thk = linspace(0, nrev*2*pi, 400001)';
    Sk = defect_contact(thk, q);
    entries = sum(diff(Sk) > 0);
    if strcmp(loc{1},'outer'), pub = p.brg.BPFO; else, pub = p.brg.BPFI; end
    report(sprintf('%s race passes per rev', loc{1}), entries/nrev, pub, 2e-3);
end
q  = apply_fault(p, 'bearing_outer', 0.4);
Sk = defect_contact(linspace(0, 1000*2*pi, 400001)', q);
report('defect occupancy at D = 0.4', mean(Sk), 0.4, 1e-2);

Ds = [0 0.05 0.1 0.25 0.5 0.75 1.0];
rms2 = zeros(size(Ds));  kurt = rms2;
fprintf('\n%8s %12s %12s %12s\n', 'D', 'RMS m/s^2', 'RMS g', 'kurtosis');
for k = 1:numel(Ds)
    q = apply_fault(p, 'bearing_outer', Ds(k));
    q = make_bearing_noise(q, cfg, T, 100 + k);
    o = run_sim(q, cfg, @(t) p.Vs, T, x0);
    qa = q;  qa.acc.nd = 0;
    a = measured_accel(o, qa, 300 + k, tA);
    rms2(k) = mean(a.^2);
    kurt(k) = mean(a.^4)/mean(a.^2)^2;
    fprintf('%8.2f %12.4f %12.5f %12.2f\n', Ds(k), 9.81*sqrt(rms2(k)), sqrt(rms2(k)), kurt(k));
end
cf  = polyfit(Ds, rms2, 1);
R2  = 1 - sum((rms2 - polyval(cf,Ds)).^2)/sum((rms2 - mean(rms2)).^2);
fprintf('\n');
pass_or_fail(sprintf('VALIDATION: RMS^2 linear in D, R^2 = %.4f', R2), R2 > 0.99);
pass_or_fail(sprintf('VALIDATION: healthy kurtosis %.2f near 3', kurt(1)), abs(kurt(1)-3) < 0.5);
pass_or_fail(sprintf('VALIDATION: kurtosis jumps to %.1f at D = 0.05', kurt(2)), kurt(2) > 3*kurt(1));
pass_or_fail(sprintf('VALIDATION: kurtosis falls back to %.2f at D = 1', kurt(end)), kurt(end) < 0.3*kurt(2));
fprintf('\n');
end

function S = defect_contact(th, q)
nb   = q.brg.Nb;
phik = q.brg.FTF*th + 2*pi*(0:nb-1)/nb;
if strcmpi(q.brg.loc,'outer'), phid = 0; else, phid = th; end
rel  = angle(exp(1i*(phik - phid)));
S    = any(abs(rel) < 0.5*q.brg.D*2*pi/nb, 2);
end

function report(name, got, want, tol)
err = abs(got-want)/max(abs(want),eps);
status = 'FAIL';  if err <= tol, status = 'pass'; end
fprintf('%-34s got %12.6g   expected %12.6g   rel err %8.2e   [%s]\n', ...
        name, got, want, err, status);
end

function pass_or_fail(name, ok)
status = 'FAIL';  if ok, status = 'pass'; end
fprintf('%-60s [%s]\n', name, status);
end
