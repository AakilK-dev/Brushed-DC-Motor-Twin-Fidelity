function verify_sensors()

p   = params_default();
cfg = cfg_model2();
V   = p.Vs;

fprintf('\nVirtual sensor verification\n\n');

pI = p;  pI.mr = 2e-5;
o  = run_sim(pI, cfg, @(t) V, 0.5);
s  = virtual_sensors(o, pI, 1);

fprintf('%-32s %.4e A\n',     'current LSB',        s.cur.lsb);
fprintf('%-32s %.4e g\n',     'accelerometer LSB',  s.acc.lsb);
fprintf('%-32s %.3f rad/s\n', 'encoder speed resolution', s.enc.wres);

resid = s.cur.i/s.cur.lsb - round(s.cur.i/s.cur.lsb);
report('current is quantised', max(abs(resid)), 0, 1e-9, true);
resid = s.acc.a/s.acc.lsb - round(s.acc.a/s.acc.lsb);
report('acceleration is quantised', max(abs(resid)), 0, 1e-9, true);

pQ = pI;  pQ.cur.nd = 0;  pQ.cur.bits = 24;
sQ = virtual_sensors(o, pQ, 1);
pN = pI;  pN.cur.bits = 24;
sN = virtual_sensors(o, pN, 2);
k  = sN.cur.t > 0.2;
sd = std(sN.cur.i(k) - sQ.cur.i(k));
fc_aa = p.aa.frac*p.cur.fs;
nord  = p.aa.order;
enbw  = fc_aa*(pi/(2*nord))/sin(pi/(2*nord));
fs_fine = 1/(o.t(2)-o.t(1));
report('current noise, filtered', sd, p.cur.nd*sqrt(enbw), 0.10);

oZ = run_sim(p, cfg_model1(), @(t) 0, 0.5);
sZ = virtual_sensors(oZ, p, 3, {'acc'});
[pxx, f] = pwelch(double(sZ.acc.a) - mean(sZ.acc.a), [], [], [], p.acc.fs);
band = f >= 1 & f <= 10000;
report('accelerometer and converter noise, 1 to 10 kHz', sqrt(trapz(f(band), pxx(band))), p.acc.nd*sqrt(9999), 0.10);
report('sensor share against the PCB sheet, 1 to 10 kHz', p.acc.nd_sensor*sqrt(9999), 1.5e-4, 0.01);   % PCB 352C33 specification sheet

for Vt = [p.Vs 0.6*p.Vs]
    oV = run_sim(p, cfg_model1(), @(t) Vt, 0.05);
    sV = virtual_sensors(oV, p, 4, {'vsup'});
    kV = sV.vsup.t > 0.01;
    report(sprintf('supply channel at %.1f V', Vt), mean(sV.vsup.v(kV)), Vt, 1e-3);
end
fprintf('%-32s 0 to %.1f V\n', 'supply channel range', p.vsense.vfs/p.vsense.div);

fs   = p.cur.fs;
tt   = (0:1e-5:0.2)';
fin  = 1.5*fs/2;
sig  = sin(2*pi*fin*tt);
[~, sigD] = aa_decimate(tt, sig, fs, p);
kk   = numel(sigD);
rej  = 20*log10(std(sigD(round(kk/2):end))/std(sig));
rej_th = 20*log10(1/sqrt(1 + (fin/(p.aa.frac*fs))^(2*p.aa.order)));
fprintf('%-32s %.1f dB (theory %.1f dB)\n', 'rejection at 1.5x Nyquist', rej, rej_th);
report('anti-alias rejection', rej, rej_th, 2.0, true);

sA = virtual_sensors(o, pI, 7);
sB = virtual_sensors(o, pI, 7);
report('same seed, same record', max(abs(sA.cur.i - sB.cur.i)), 0, 1e-12, true);

ripple = pI.mr*p.g/(p.J*mean(o.x(:,o.idx.w)));
fprintf('%-32s %.3e rad/s\n', 'imbalance speed ripple', ripple);
fprintf('%-32s %.0f times\n', 'encoder resolution is coarser by', s.enc.wres/ripple);

fprintf('\n');
end

function report(name, got, want, tol, absolute, testfun)
if nargin >= 6 && ~isempty(testfun)
    ok = testfun(got);
elseif nargin >= 5 && absolute
    ok = abs(got-want) <= tol;
else
    ok = abs(got-want)/max(abs(want),eps) <= tol;
end
status = 'FAIL';  if ok, status = 'pass'; end
fprintf('%-32s got %12.6g   expected %12.6g   [%s]\n', name, got, want, status);
end
