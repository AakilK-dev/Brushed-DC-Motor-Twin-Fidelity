function verify_model2()

p    = params_default();
cfg1 = cfg_model1();
cfg2 = cfg_model2();
V    = p.Vs;
tau_m = p.J*p.R/(p.Kt*p.Ke);

fprintf('\nModel 2 verification\n\n');

cfgOff = cfg2;  cfgOff.friction = 'viscous';  cfgOff.gearbox = false;
o1 = run_sim(p, cfg1,   @(t) V, 20*tau_m);
o2 = run_sim(p, cfgOff, @(t) V, 20*tau_m);
report('switch-off, speed',   o2.x(end,o2.idx.w), o1.x(end,o1.idx.w), 1e-12);
report('switch-off, current', o2.x(end,o2.idx.i), o1.x(end,o1.idx.i), 1e-12);

cfgC = cfg2;  cfgC.gearbox = false;
w_c  = (p.Kt*V/p.R - p.Tc)/(p.Kt*p.Ke/p.R + p.b);
i_c  = (V - p.Ke*w_c)/p.R;
oC   = run_sim(p, cfgC, @(t) V, 20*tau_m);
report('Coulomb, steady speed',   oC.x(end,oC.idx.w), w_c, 1e-3);
report('Coulomb, steady current', oC.x(end,oC.idx.i), i_c, 1e-3);

Vbk = p.Tc*p.R/p.Kt;
fprintf('%-30s %.4f V\n', 'breakaway voltage Tc*R/Kt', Vbk);
oBelow = run_sim(p, cfgC, @(t) 0.9*Vbk, 2.0);
oAbove = run_sim(p, cfgC, @(t) 1.4*Vbk, 2.0);
wBelow = oBelow.x(end,oBelow.idx.w);
wAbove = oAbove.x(end,oAbove.idx.w);
pass_or_fail('below breakaway, shaft still', wBelow < 0.05, wBelow);
pass_or_fail('above breakaway, shaft turns', wAbove > 0.50, wAbove);

pg = p;  pg.N = 5;  pg.eta = 0.80;
cfgG = cfg2;  cfgG.friction = 'viscous';  cfgG.gearbox = true;
KeR = pg.N*pg.Ke;  KtR = pg.eta*pg.N*pg.Kt;
w_g = KtR*V/(pg.R*pg.b_lin + KtR*KeR);
oG  = run_sim(pg, cfgG, @(t) V, 20*tau_m);
report('gearbox, steady speed', oG.x(end,oG.idx.w), w_g, 1e-3);
report('gearbox, speed ratio',  oG.x(end,oG.idx.w)/o1.x(end,o1.idx.w), 1/pg.N, 2e-2);

cfgA = cfg2;  cfgA.gearbox = false;  cfgA.thermal = false;  cfgA.angle = true;
oA   = run_sim(p, cfgA, @(t) V, 0.5);
th_int = trapz(oA.t, oA.x(:,oA.idx.w));
report('shaft angle equals integral', oA.x(end,oA.idx.th), th_int, 1e-6);

pT = p;  pT.theta = 70;
cfgT = cfg2;  cfgT.gearbox = false;  cfgT.thermal = true;
RT   = p.R*(1 + p.alpha*pT.theta);
w_T  = (p.Kt*V/RT - p.Tc)/(p.Kt*p.Ke/RT + p.b);
i_T  = (V - p.Ke*w_T)/RT;
oT   = run_sim(pT, cfgT, @(t) V, 20*tau_m);
report('hot resistance', RT, 1.28*p.R, 1e-12);
report('hot steady speed',   oT.x(end,oT.idx.w), w_T, 1e-3);
report('hot steady current', oT.x(end,oT.idx.i), i_T, 1e-3);

ot     = thermal_response(p, @(t) p.Irated, @(t) p.w_ref, 6000, 1.0);
rate   = p.k0*(1 + p.kT*p.w_ref) - p.R*p.Irated^2*p.alpha;
tau_th = p.H/rate;
report('thermal steady rise', ot.theta(end), 70, 2e-2);
[~,jt] = min(abs(ot.theta - 0.632*ot.theta(end)));
report('thermal time constant', ot.t(jt), tau_th, 5e-2);

pF = p;  pF.mr = 0;
cfgF = cfg2;  cfgF.gearbox = false;  cfgF.thermal = false;  cfgF.modes = 1;
idxF = state_index(cfgF);
x0 = zeros(idxF.n,1);  x0(idxF.y(1)) = 1e-4;
oF = run_sim(pF, cfgF, @(t) 0, 0.20, x0);
yF = oF.x(:,oF.idx.y(1));
zc = find(yF(1:end-1) > 0 & yF(2:end) <= 0);
fd = 1/mean(diff(oF.t(zc)));
report('damped natural frequency', fd, p.modes.f(1)*sqrt(1-p.modes.zeta(1)^2), 2e-2);

pI = p;  pI.mr = 2e-5;
cfgI = cfg2;  cfgI.gearbox = false;  cfgI.thermal = false;
oI = run_sim(pI, cfgI, @(t) V, 1.0);
kk = oI.t > 0.6;
yamp = (max(oI.x(kk,oI.idx.y(1))) - min(oI.x(kk,oI.idx.y(1))))/2;
wss  = mean(oI.x(kk,oI.idx.w));
wn   = 2*pi*p.modes.f(1);  zt = p.modes.zeta(1);
kmod = p.M*wn^2;  r = wss/wn;
mag  = 1/sqrt((1-r^2)^2 + (2*zt*r)^2);
report('mode displacement amplitude', yamp, pI.mr*wss^2/kmod*mag, 5e-2);

wamp = (max(oI.x(kk,oI.idx.w)) - min(oI.x(kk,oI.idx.w)))/2;
report('imbalance speed ripple', wamp, pI.mr*p.g/(p.J*wss), 1e-1);
fprintf('%-30s %.6f %% of mean speed\n', 'ripple relative size', 100*wamp/wss);

pL = p;  pL.TL = p.TLfrac*p.Kt*p.Irated;
cL = cfg2;  cL.gearbox = false;  cL.thermal = false;  cL.imbalance = false;  cL.modes = [];
w_L = (p.Kt*V/p.R - p.Tc - pL.TL)/(p.Kt*p.Ke/p.R + p.b);
oL  = run_sim(pL, cL, @(t) V, 20*tau_m);
report('loaded steady speed', oL.x(end,oL.idx.w), w_L, 1e-3);

fprintf('\n');
end

function report(name, got, want, tol)
err    = abs(got-want)/max(abs(want),eps);
status = 'FAIL';
if err <= tol, status = 'pass'; end
fprintf('%-30s got %12.6g   expected %12.6g   rel err %8.2e   [%s]\n', ...
        name, got, want, err, status);
end

function pass_or_fail(name, condition, value)
status = 'FAIL';
if condition, status = 'pass'; end
fprintf('%-30s got %12.6g   %41s[%s]\n', name, value, '', status);
end
