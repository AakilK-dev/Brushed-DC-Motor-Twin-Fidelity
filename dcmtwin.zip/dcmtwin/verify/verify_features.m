function verify_features()

fprintf('\nFeature verification\n\n');
w = 150;  V = 14.4;  I0 = 3;  a2 = 0.05;  fs = 10000;  fa = 50000;  T = 2.5;
rec0 = synth(w, V, I0, a2, 1.0, fs, fa, T, 1);
X.runs = struct('state', {'baseline', 'healthy', 'resistive'}, 'severity', {NaN, NaN, 0.1}, ...
                'rec', {rec0, rec0, synth(w, V, I0, a2, 2.0, fs, fa, T, 1)});
F  = features_core(X, {[], []});
Fb = features_core(X, {[], []}, [5500 7000]);
pass_or_fail('speed from the encoder angle (single precision), to 1e-6', abs(F.w(1)/w - 1) < 1e-6);
pass_or_fail('a run identical to the baseline: every Set A change is zero', all(F.A(1,:) == 0));
pass_or_fail('vibration doubled: A_vrms = log 2 and A_kurt = 0', ...
             abs(F.A(2,6) - log(2)) < 1e-12 && abs(F.A(2,7)) < 1e-9);
pass_or_fail('the default envelope band is [5500 7000] Hz, bit for bit', isequal(F.A, Fb.A));
X2 = X;  X2.runs(3).rec = synth(w, V, I0, 2*a2, 1.0, fs, fa, T, 1);
F2 = features_core(X2, {[], []});
pass_or_fail('order-2 current component recovered: A_i2 = a2 to 0.1%', abs(F2.A(2,4)/a2 - 1) < 1e-3);
fin = @(R, Ke, L, b, h2) struct('R', R, 'Ke', Ke, 'L', L, 'b', b, 'h2', h2);
inn = @(nis, rms) struct('rms_i', rms, 'rms_th', 1e-4, 'meanNIS', nis, 'frac99', 0.01);
Z.runs = struct('final', {fin(1, 0.05, 1e-3, 1e-4, 0.02), fin(1, 0.05, 1e-3, 1e-4, 0.02), fin(1.1, 0.049, 0.99e-3, 1.2e-4, 0.04)}, ...
                'innov', {inn(2, 0.01), inn(2, 0.01), inn(2.5, 0.012)});
F3 = features_core(X, {Z, Z});
wr = F3.w(2);  ex = [0.1, -0.02, -0.01, 2e-5*wr, log(2), 0.5, 0.2, wr, 1e-4];
pass_or_fail('Set B from known filter changes, both twins, to 1e-12', ...
             max(abs(F3.B{1}(2,:) - ex)) < 1e-12 && isequal(F3.B{1}, F3.B{2}) && all(F3.B{1}(1,1:7) == 0));
e = @(R, Ke, L, Tf, h2, u, r) struct('R', R, 'Ke', Ke, 'L', L, 'Tf', Tf, 'h2', h2, 'unexplained', u, 'rms', r);
runs = struct('final', {e(1, 0.05, 1e-3, 0.03, 0.02, 0.01, 1e-4), e(1.2, 0.05, 1e-3, 0.035, 0.02, 0.02, 1.5e-4)});
B = lsq_rows(runs);
pass_or_fail('B_LS from known estimates: ratios, torque difference, log harmonic', ...
             max(abs(B - [0.2, 0, 0, 0.005, 0, 0.01, 0.5])) < 1e-12);
fprintf('\n');
end

function rec = synth(w, V, I0, a2, va, fs, fa, T, seed)
t  = (0:round(T*fs)-1)'/fs;  th = w*t;
rec.cur  = struct('fs', fs, 'y', single(I0 + a2*cos(2*th + 0.3)));
rec.vsup = struct('fs', fs, 'y', single(V*ones(size(t))));
rec.enc  = struct('fs', fs, 'y', single(th));
rs = RandStream('mt19937ar', 'Seed', seed);
ta = (0:round(T*fa)-1)'/fa;
rec.acc  = struct('fs', fa, 'y', single(va*(0.02*sin(w*ta) + 0.01*randn(rs, numel(ta), 1))));
end

function pass_or_fail(name, ok)
status = 'FAIL';  if ok, status = 'pass'; end
fprintf('%-62s [%s]\n', name, status);
end
