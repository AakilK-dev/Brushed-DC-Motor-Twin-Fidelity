function verify_model3()

p    = params_default();
cfg2 = cfg_model2();
cfg3 = cfg_model3();
V    = p.Vs;
T    = 0.5;
tA   = 0.2;

fprintf('\nModel 3 verification: commutation and shorted bar surrogate\n');
fprintf('(each run is %.1f s of simulated time; this takes a little while)\n\n', T);

cOff = cfg3;  cOff.commutation = false;  cOff.friction = 'coulomb';  cOff.modes = 1;
o2 = run_sim(p, cfg2, @(t) V, T);
o3 = run_sim(p, cOff, @(t) V, T);
report('switch-off, speed',   o3.x(end,o3.idx.w), o2.x(end,o2.idx.w), 1e-12);
report('switch-off, current', o3.x(end,o3.idx.i), o2.x(end,o2.idx.i), 1e-12);

[dcH, a2H, aH, wH] = analyse(run_sim(p, cfg3, @(t) V, T), tA, [2 23 24 25]);

fprintf('%-34s %.3f %% of DC  (orders 23 and 25: %.4f, %.4f %%)\n', ...
        'healthy ripple at order 24', 100*aH(3)/dcH, 100*aH(2)/dcH, 100*aH(4)/dcH);
pass_or_fail('ripple sits at the bar count', aH(3) > 20*max(aH(2),aH(4)));

report('healthy 2nd harmonic, % of DC', 100*a2H/dcH, 1.734, 2e-2);

rsc  = [20 10 5 2 1 0.5];
h2   = zeros(size(rsc));  dc = h2;  ws = h2;
fprintf('\n%12s %12s %12s %12s %12s\n','Rsc/Rcoil','2nd % DC','x healthy','speed chg','DC chg');
for k = 1:numel(rsc)
    q = apply_fault(p, 'shorted_bar', rsc(k));
    [dc(k), h2(k), ~, ws(k)] = analyse(run_sim(q, cfg3, @(t) V, T), tA, 2);
    fprintf('%12.1f %12.3f %12.2f %11.2f%% %11.2f%%\n', rsc(k), 100*h2(k)/dc(k), ...
            (h2(k)/dc(k))/(a2H/dcH), 100*(ws(k)/wH - 1), 100*(dc(k)/dcH - 1));
end
fprintf('\n');

report('severe 2nd harmonic growth', (h2(end)/dc(end))/(a2H/dcH), 15, 5e-2);   % Retana et al., IEEE Trans. Energy Convers., vol. 23, no. 2, pp. 484-491, 2008
report('severe speed rise, %',       100*(ws(end)/wH - 1), 4.00, 3e-2);   % Retana et al., IEEE Trans. Energy Convers., vol. 23, no. 2, pp. 484-491, 2008
pass_or_fail('2nd harmonic grows monotonically', all(diff(h2./dc) > 0));

fprintf('\n%-34s %+.2f %%\n', 'VALIDATION: DC change, severe end', 100*(dc(end)/dcH - 1));
fprintf('%-34s %s\n', '  Retana report', 'DC current remains almost constant');
fprintf('%-34s %s\n', '  harmonic change, same range', ...
        sprintf('%.1f times', (h2(end)/dc(end))/(a2H/dcH)));
fprintf('\n');
end

function [dc, a1, amp, wm] = analyse(o, tA, orders)
k   = o.t >= tA;
th  = o.x(k, o.idx.th);
i   = o.x(k, o.idx.i);
[amp, dc] = order_amplitude(i, th, orders);
a1  = amp(1);
wm  = mean(o.x(k, o.idx.w));
end

function report(name, got, want, tol)
err = abs(got-want)/max(abs(want),eps);
status = 'FAIL';  if err <= tol, status = 'pass'; end
fprintf('%-34s got %12.6g   expected %12.6g   rel err %8.2e   [%s]\n', ...
        name, got, want, err, status);
end

function pass_or_fail(name, ok)
status = 'FAIL';  if ok, status = 'pass'; end
fprintf('%-34s %48s[%s]\n', name, '', status);
end
