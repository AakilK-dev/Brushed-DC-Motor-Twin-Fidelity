function verify_identify()

p = params_default();
q = p;  q.machine = 1;  q.theta = 0;
opts = struct('Tprbs',0.5, 'Tsteady',1.0, 'tA',0.3);
fprintf('\nIdentification verification (about a minute)\n\n');

R1 = ensemble_tests(q, cfg_model1(), 71000, opts);
I1 = identify_machine(R1, p);
report('Model 1 on Model 1 data, R',     I1.M1.R,     p.R,     1e-2);
report('Model 1 on Model 1 data, L',     I1.M1.L,     p.L,     5e-2);
report('Model 1 on Model 1 data, Ke',    I1.M1.Ke,    p.Ke,    5e-3);
report('Model 1 on Model 1 data, J',     I1.M1.J,     p.J,     3e-2);
report('Model 1 on Model 1 data, b_lin', I1.M1.b_lin, p.b_lin, 2e-2);

c2 = cfg_model2();
R2 = ensemble_tests(q, c2, 72000, opts);
I2 = identify_machine(R2, p);
report('Model 2 on Model 2 data, R',  I2.M2.R,  p.R,  1e-2);
report('Model 2 on Model 2 data, L',  I2.M2.L,  p.L,  5e-2);
report('Model 2 on Model 2 data, Ke', I2.M2.Ke, p.Ke, 5e-3);
report('Model 2 on Model 2 data, J',  I2.M2.J,  p.J,  3e-2);
report('Model 2 on Model 2 data, b',  I2.M2.b,  p.b,  5e-2);
report('Model 2 on Model 2 data, Tc', I2.M2.Tc, p.Tc, 3e-2);
report('Model 2 inertia, step against coast', I2.diag.J2_step, I2.diag.J2_coast, 3e-2);
fprintf('\n');
end

function report(name, got, want, tol)
err = abs(got - want)/max(abs(want), eps);
status = 'FAIL';  if err <= tol, status = 'pass'; end
fprintf('%-40s got %11.5g   true %11.5g   err %6.2f %%   [%s]\n', ...
        name, got, want, 100*(got - want)/want, status);
end
