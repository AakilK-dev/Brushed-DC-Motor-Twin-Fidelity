function verify_onset()

fprintf('\nOnset switch verification\n\n');
p = params_default();  cfg = cfg_model3();  T = 0.06;  x0 = [];
q = make_bearing_noise(p, cfg, T, 11);
qF = apply_fault(q, 'bearing_outer', 0.5);
V = @(t) 0.6*p.Vs;
oN = run_sim(q, cfg, V, T, x0);  oF = run_sim(qF, cfg, V, T, x0);
qa = q;  qa.onset = struct('t', 10, 'p', qF);
qb = q;  qb.onset = struct('t', 0, 'p', qF);
tOn = 0.03;  qc = q;  qc.onset = struct('t', tOn, 'p', qF);
oa = run_sim(qa, cfg, V, T, x0);  ob = run_sim(qb, cfg, V, T, x0);  oc = run_sim(qc, cfg, V, T, x0);
pass_or_fail('no onset field: unchanged path', isequal(run_sim(q, cfg, V, T, x0).x, oN.x));
pass_or_fail('onset after the record: equals the normal run, bit for bit', isequal(oa.x, oN.x) && isequal(oa.dx, oN.dx));
pass_or_fail('onset at zero: equals the faulted run, bit for bit', isequal(ob.x, oF.x) && isequal(ob.dx, oF.dx));
k = find(oN.t >= tOn - 1e-12, 1);
pass_or_fail('mid-record: identical to the normal run up to the onset', isequal(oc.x(1:k,:), oN.x(1:k,:)));
pass_or_fail('mid-record: departs from the normal run after the onset', any(any(oc.x(k+1:end,:) ~= oN.x(k+1:end,:))));
ka = oc.idx.dy(end);
pass_or_fail('mid-record: the vibration changes after the onset', ...
             std(oc.dx(k+1:end, ka)) > 1.5*std(oN.dx(k+1:end, ka)));
fprintf('\n');
end

function pass_or_fail(name, ok)
status = 'FAIL';  if ok, status = 'pass'; end
fprintf('%-62s [%s]\n', name, status);
end
