function verify_energy()

p = params_default();
fprintf('\nEnergy conservation\n\n');

cfgs = {cfg_model1(), cfg_model2(), cfg_model3()};
for m = 1:3
    c = cfgs{m};  c.imbalance = false;  c.modes = [];  c.bearing = false;
    report(sprintf('Model %d energy balance', m), balance(p, c), 0, 1e-4, true);
end

fprintf('\n%-34s %s\n', 'with the source''s original Kt', '(must FAIL)');
pOld = p;  pOld.Kt = 0.05292;
err  = balance(pOld, cfg_model1());
fprintf('%-34s %+.3f %% of input energy\n', 'Model 1 energy imbalance', 100*err);
pass_or_fail('check detects the original error', abs(err) > 1e-2);
fprintf('\n');
end

function err = balance(p, cfg)
T   = 0.3;
o   = run_sim(p, cfg, @(t) 0.6*p.Vs, T);
q   = referred_params(p, cfg);
t   = o.t;  i = o.x(:,o.idx.i);  w = o.x(:,o.idx.w);  V = o.V;
R   = q.R;  if cfg.thermal, R = R*(1 + q.alpha*q.theta); end
Ein  = trapz(t, V.*i);
Ecu  = trapz(t, R*i.^2);
Emag = 0.5*q.L*i(end)^2;
Ekin = 0.5*q.J*w(end)^2;
Efr  = trapz(t, friction_model(w, q, cfg).*w);
if cfg.commutation
end
err = (Ein - (Ecu + Emag + Ekin + Efr))/Ein;
end

function report(name, got, want, tol, absolute)
if nargin > 4 && absolute, ok = abs(got - want) <= tol;
else, ok = abs(got - want)/max(abs(want),eps) <= tol; end
status = 'FAIL';  if ok, status = 'pass'; end
fprintf('%-34s got %12.4e   expected %12.6g   [%s]\n', name, got, want, status);
end

function pass_or_fail(name, ok)
status = 'FAIL';  if ok, status = 'pass'; end
fprintf('%-34s %41s[%s]\n', name, '', status);
end
