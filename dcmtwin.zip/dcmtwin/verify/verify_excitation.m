function verify_excitation()

p    = params_default();
cfg1 = cfg_model1();
cfg2 = cfg_model2();  cfg2.gearbox = false;  cfg2.thermal = false;
w0   = p.Kt*p.Vs/(p.R*p.b_lin + p.Kt*p.Ke);

fprintf('\nExcitation and acceleration verification\n\n');

x0 = [ (p.Vs - p.Ke*w0)/p.R ; w0 ];
cd = excitation('coastdown','V0',p.Vs,'toff',0);
o  = run_sim(p, cfg1, cd, 3.0, x0);
w  = o.x(:,o.idx.w);
tau_c = p.J/p.b_lin;
[~,j] = min(abs(w - w0*exp(-1)));
report('Model 1 coast-down tau', o.t(j), tau_c, 1e-2);

oS = run_sim(p, cfg1, @(t) 0, 0.3, x0);
wS = oS.x(:,oS.idx.w);
tau_b = p.J/(p.b_lin + p.Kt*p.Ke/p.R);
[~,jb] = min(abs(wS - w0*exp(-1)));
report('short circuit braking tau', oS.t(jb), tau_b, 2e-2);
fprintf('%-32s %.0f times faster\n', 'braking against coasting', tau_c/tau_b);

x0b = zeros(state_index(cfg2).n,1);  x0b(1) = 0;  x0b(2) = w0;
o2  = run_sim(p, cfg2, cd, 5.0, x0b);
w2  = o2.x(:,o2.idx.w);
t_stop = (p.J/p.b)*log(1 + p.b*w0/p.Tc);
js = find(w2 < 0.01*w0, 1, 'first');
report('Model 2 stopping time', o2.t(js), t_stop, 2e-2);
fprintf('%-32s %.3f rad/s at 5 s (never reaches zero)\n', ...
        'Model 1 speed', w(end)*0 + w0*exp(-5/tau_c));

pr  = excitation('prbs','Vlo',12,'Vhi',24,'thold',0.05,'tEnd',2.5,'seed',3);
tt  = (0:1e-4:2.5)';
v   = arrayfun(pr.V, tt);
report('PRBS has two levels', numel(unique(v)), 2, 0, true);
edges = find(diff(v) ~= 0);
report('PRBS minimum hold', min(diff(tt(edges))), 0.05, 1e-3, false, @(x) x >= 0.05 - 1e-3);
pr2 = excitation('prbs','Vlo',12,'Vhi',24,'thold',0.05,'tEnd',2.5,'seed',3);
report('PRBS reproducible', max(abs(v - arrayfun(pr2.V, tt))), 0, 0, true);

dz  = excitation('dither','V0',24,'amp',0.02,'thold',0.02,'tEnd',2.5,'seed',4);
vd  = arrayfun(dz.V, tt);
report('dither peak deviation', max(abs(vd - 24))/24, 0.02, 1e-9);
report('dither mean', mean(vd), 24, 5e-3);

pI = p;  pI.mr = 2e-5;
cI = cfg_model2();  cI.gearbox = false;  cI.thermal = false;
oI = run_sim(pI, cI, @(t) p.Vs, 1.0);
kk = oI.t > 0.6;
a  = zeros(size(oI.t));
for m = 1:numel(oI.idx.dy), a = a + oI.dx(:,oI.idx.dy(m)); end
aamp = (max(a(kk)) - min(a(kk)))/2/9.81;
wss  = mean(oI.x(kk,oI.idx.w));
wn   = 2*pi*p.modes.f(1);  zt = p.modes.zeta(1);  r = wss/wn;
mag  = 1/sqrt((1-r^2)^2 + (2*zt*r)^2);
yamp = pI.mr*wss^2/(p.M*wn^2)*mag;
report('acceleration amplitude, true', aamp, wss^2*yamp/9.81, 1e-2);
s  = virtual_sensors(oI, pI, 1);
km = s.acc.t > 0.6;
amM = (max(s.acc.a(km)) - min(s.acc.a(km)))/2;
report('acceleration amplitude, measured', amM, wss^2*yamp/9.81, 5e-2);

fprintf('\n');
end

function report(name, got, want, tol, absolute, testfun)
if nargin >= 6 && ~isempty(testfun)
    ok = testfun(got);
elseif nargin >= 5 && absolute
    ok = abs(got-want) <= tol;
else
    ok = abs(got-want)/max(abs(want),eps) <= tol;
end
status = 'FAIL';  if ok, status = 'pass'; end
fprintf('%-32s got %12.6g   expected %12.6g   [%s]\n', name, got, want, status);
end
