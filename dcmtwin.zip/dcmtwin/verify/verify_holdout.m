function verify_holdout()

fprintf('\nHold-out verification\n\n');
td = tempname;  mkdir(fullfile(td, 'datasets'));  c = onCleanup(@() rmdir(td, 's'));
rs = RandStream('mt19937ar', 'Seed', 3);  m = randperm(rs, 500)';
A = struct('diagnosis', sort(m(1:150)), 'tuning', sort(m(151:165)), 'holdout', sort(m(166:265)), ...
           'onset', sort(m(266:325)), 'spare', sort(m(326:end)));
save(fullfile(td, 'datasets', 'reserve_allocation.mat'), 'A');
S1 = tab_cols(make_holdout_sessions(td));  S2 = tab_cols(make_holdout_sessions(td));
pass_or_fail('100 sessions, one on each hold-out machine, no other machine', ...
             numel(S1.session) == 100 && isequal(sort(S1.machine(:)), A.holdout) && numel(unique(S1.machine)) == 100);
pass_or_fail('duties balanced: 34, 33, 33 at 40, 60, 80%', isequal(histc(S1.duty(:)', [0.4 0.6 0.8]), [34 33 33]));
pass_or_fail('severities and temperatures in the diagnosis plan''s ranges', ...
             all(S1.res_s >= 0.02 & S1.res_s <= 0.30) && all(S1.sc_f >= 0.1 & S1.sc_f <= 1) && ...
             all(S1.brg_D >= 0.05 & S1.brg_D <= 1) && all(S1.imb_mr >= 5e-6 & S1.imb_mr <= 2.5e-5) && ...
             all(S1.theta_degC >= 0 & S1.theta_degC <= 70));
pass_or_fail('run seeds 6000000 + 100 s: disjoint from the other plans''', ...
             isequal(S1.seed(:), 6000000 + 100*S1.session(:)) && min(S1.seed) > 5e6 + 1e5 && max(S1.seed) + 100 < 7e6);
pass_or_fail('the same plan on every call (its own seed)', isequal(S1, S2));
A.onset(1) = A.holdout(1);  save(fullfile(td, 'datasets', 'reserve_allocation.mat'), 'A');
pass_or_fail('an allocation whose groups overlap stops the plan', throws(@() make_holdout_sessions(td), 'make_holdout_sessions:overlap'));
pass_or_fail('hold-out records and filters for the reference only', ...
             throws(@() generate_dataset(td, 2, [], 'holdout'), 'generate_dataset:holdout') && ...
             throws(@() run_ekf_dataset(td, 1, 1, 'holdout'), 'run_ekf_dataset:holdout') && ...
             throws(@() run_lsq_dataset(td, 2, 'holdout'), 'run_lsq_dataset:holdout'));
fprintf('\n');
end

function t = throws(f, id)
t = false;
try, f(); catch err, t = strcmp(err.identifier, id); end
end

function pass_or_fail(name, ok)
status = 'FAIL';  if ok, status = 'pass'; end
fprintf('%-62s [%s]\n', name, status);
end
