function verify_lsq()

fprintf('\nLeast-squares estimator verification\n\n');
c = struct('R', 0.95, 'L', 1.4e-3, 'Ke', 0.0529, 'J', 6e-4, 'b', 7.3e-5, 'Tc', 0.017, ...
           'TL', 0.175, 'dTL', 0.002, 'V0', 14.4, 'd', 0.004);
[rec, tr] = simulate(c, 0, 7);
E = lsq_estimate(rec, c.TL);  f = E.final;
pass_or_fail('noise-free: R within 0.02%',  abs(f.R/c.R - 1) < 2e-4);
pass_or_fail('noise-free: Ke within 0.01%', abs(f.Ke/c.Ke - 1) < 1e-4);
pass_or_fail('noise-free: L within 0.5%',   abs(f.L/c.L - 1) < 5e-3);
pass_or_fail('noise-free: friction torque (with brake offset) within 0.5%', abs(f.Tf/tr.Tf - 1) < 5e-3);
pass_or_fail('noise-free: twice-per-revolution EMF depth within 2%', abs(f.k2/c.d - 1) < 0.02);
[recn, ~] = simulate(c, 0.02, 7);
En = lsq_estimate(recn, c.TL);  g = En.final;
pass_or_fail('current noise 20 mA: R within 0.3%',  abs(g.R/c.R - 1) < 3e-3);
pass_or_fail('current noise 20 mA: Ke within 0.1%', abs(g.Ke/c.Ke - 1) < 1e-3);
pass_or_fail('current noise 20 mA: L within 2%',    abs(g.L/c.L - 1) < 0.02);
c2 = c;  c2.R = 1.1*c.R;  [rec2, ~] = simulate(c2, 0.02, 7);
E2 = lsq_estimate(rec2, c.TL);
pass_or_fail('a 10% resistance rise is read as 10% (to 0.5 points)', abs(E2.final.R/g.R - 1.1) < 5e-3);
pass_or_fail('the residual is larger with noise than without', g.rms > f.rms);
fprintf('\n');
end

function [rec, tr] = simulate(c, sigI, seed)
fs = 20000;  dt = 1/fs;  T = 2.5;  n = round(T*fs);
rs = RandStream('mt19937ar', 'Seed', seed);
th0 = 0.02;  lev = 2*(rand(rs, ceil(T/th0) + 2, 1) > 0.5) - 1;  tr0 = 1e-3;
th = (0:2*n)'*dt/2;  j = floor(th/th0) + 1;  u = th - (j - 1)*th0;
lv = lev(j);  r = u < tr0 & j > 1;
lv(r) = lev(j(r) - 1) + (lev(j(r)) - lev(j(r) - 1)).*(1 - cos(pi*u(r)/tr0))/2;
Vh = c.V0*(1 + 0.02*lv);
Tf = @(w) c.Tc*tanh(214*w) + c.b*w;
w0 = (c.Ke*Vh(1)/c.R - c.Tc - c.TL - c.dTL)/(c.Ke^2/c.R + c.b);
x  = [(Vh(1) - c.Ke*w0)/c.R; w0; 0];  X = zeros(n, 3);
fx = @(x, v) [(v - c.R*x(1) - c.Ke*(1 + c.d*cos(2*x(3)))*x(2))/c.L; ...
              (c.Ke*(1 + c.d*cos(2*x(3)))*x(1) - Tf(x(2)) - c.TL - c.dTL)/c.J; x(2)];
for k = 1:n
    X(k,:) = x';  v0 = Vh(2*k - 1);  vm = Vh(2*k);  v1 = Vh(2*k + 1);
    k1 = fx(x, v0);  k2 = fx(x + dt/2*k1, vm);  k3 = fx(x + dt/2*k2, vm);  k4 = fx(x + dt*k3, v1);
    x = x + dt/6*(k1 + 2*k2 + 2*k3 + k4);
end
m = 2;  idx = 1:m:n;
cur = X(idx,1) + sigI*randn(rs, numel(idx), 1);
rec.cur  = struct('fs', fs/m, 'y', single(cur));
rec.vsup = struct('fs', fs/m, 'y', single(Vh(2*idx - 1)));
rec.enc  = struct('fs', fs/m, 'y', single(X(idx,3)));
k = idx((idx - 1)*dt >= 0.5);  wm = mean(X(k,2));
tr.Tf = Tf(wm) + c.dTL;
end

function pass_or_fail(name, ok)
status = 'FAIL';  if ok, status = 'pass'; end
fprintf('%-62s [%s]\n', name, status);
end
