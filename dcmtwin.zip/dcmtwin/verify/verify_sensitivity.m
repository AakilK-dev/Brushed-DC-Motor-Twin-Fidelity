function verify_sensitivity()

fprintf('\nSensitivity analysis verification\n\n');
p = params_default();  V = sens_variants();
pass_or_fail('34 variants of 20 parameters (the 15 agreed items), names unique', ...
             numel(V) == 34 && numel(unique({V.name})) == 34 && numel(unique({V.group})) == 20);
lv = @(n) V(strcmp({V.name}, n)).value;
pass_or_fail('levels as agreed: load 10/24%, k_f 0/0.25/2, G 7.5/30, dK halved/doubled', ...
             lv('load_10') == 0.10 && lv('load_24') == 0.24 && lv('kf_0') == 0 && lv('kf_025') == 0.25 && ...
             lv('kf_2') == 2 && lv('G_half') == p.sc.growth/2 && lv('G_double') == 2*p.sc.growth && ...
             abs(lv('dK_half') - p.sc.dK/2) < 1e-12 && abs(lv('dK_double') - 2*p.sc.dK) < 1e-12);
pass_or_fail('levels as agreed: W_svc and M_h halved/doubled, eps_c 3.6%, four brushes', ...
             abs(lv('Wsvc_half') - p.brg.W_svc/2) < 1e-12 && abs(lv('Wsvc_double') - 2*p.brg.W_svc) < 1e-12 && ...
             lv('Mh_025') == p.Mhf/2 && lv('Mh_10') == 2*p.Mhf && lv('epsc_36') == 2*p.eps_c && lv('brush_4') == 4);
ok = true;  okSets = true;
for k = 1:numel(V)
    [pr, pt, pb] = sens_params(p, V(k));
    nd = ~isequaln(pr, p) + ~isequaln(pt, p) + ~isequaln(pb, p);
    switch V(k).code
        case {'coolbase', 'spread'}, ok = ok && nd == 0;
        otherwise,                   ok = ok && nd >= 1;
    end
    switch V(k).code
        case {'growth','f1cov','Wsvc','epsc','nbrush','hmodes','Mhf','summit'}
            okSets = okSets && isequaln(pt, p) && isequaln(pb, p) && ~V(k).bench && isempty(V(k).twinRuns{1}) && isempty(V(k).twinRuns{2});
        case {'stribeck_off','ws'}
            okSets = okSets && isequaln(pr, p) && isequaln(pt, p) && V(k).bench && isempty(V(k).refRuns);
        case 'coulomb'
            okSets = okSets && isequaln(pt, p) && V(k).bench;
    end
end
pass_or_fail('every variant moves a parameter (or its machine factors / run)', ok);
pass_or_fail('reference-only and bench-only variants leave the other sets alone', okSets);
[pr, ~, pb] = sens_params(p, V(strcmp({V.name}, 'coul_21')));
Ttot = p.b_lin*p.w_ref;
pass_or_fail('Coulomb split: fraction 21%, total torque at w_ref kept, Ts/Tc kept', ...
             abs(pr.Tc/(pr.Tc + pr.b*p.w_ref) - 0.21) < 1e-12 && abs(pr.Tc + pr.b*p.w_ref - Ttot) < 1e-15 && ...
             abs(pr.Ts/pr.Tc - p.Ts/p.Tc) < 1e-12 && isequaln(pr, pb));
[pr, ~, ~] = sens_params(p, V(strcmp({V.name}, 'hmodes_12')));
pass_or_fail('housing modes +20%: only modes 5 and 6 move; envelope band moves with them', ...
             isequal(pr.modes.f(1:4), p.modes.f(1:4)) && max(abs(pr.modes.f(5:6) - 1.2*p.modes.f(5:6))) < 1e-9 && ...
             V(strcmp({V.name}, 'hmodes_12')).band == 1.2);
u = params_uncertainty();  names = [u.factors(:,1)' {'theta'}];
rs = RandStream('mt19937ar', 'Seed', 5);  n = 20000;
s = sqrt(log(1 + 0.3^2));  ffr = exp(-s^2/2 + s*randn(rs, n, 1));  fR = 1 + 0.05*randn(rs, n, 1);
gfr = zeros(n,1);  gR = zeros(n,1);  vfr = V(strcmp({V.name}, 'sprFr_2'));  vR = V(strcmp({V.name}, 'sprR_2'));
for i = 1:n
    R = struct('factors', [fR(i) 1 1 1 ffr(i)], 'names', {names});
    a = sens_factors(R, vfr);  gfr(i) = a.factors(5);
    b = sens_factors(R, vR);   gR(i) = b.factors(1);
end
pass_or_fail('friction spread doubled: CoV 0.30 to 0.60 (2%), mean 1, ranks kept', ...
             abs(std(gfr)/mean(gfr) - 0.6) < 0.012 && abs(mean(gfr) - 1) < 0.02 && isequal(sortidx(gfr), sortidx(ffr)));
pass_or_fail('resistance spread doubled: f'' - 1 = 2(f - 1) exactly', max(abs(gR - 1 - 2*(fR - 1))) < 1e-14);
td = tempname;  mkdir(fullfile(td, 'datasets'));  c = onCleanup(@() rmdir(td, 's'));
S = struct('session', (1:150)', 'machine', (201:350)', 'duty', kron([0.4; 0.6; 0.8], ones(50,1)));
save(fullfile(td, 'datasets', 'sessions.mat'), 'S');
U1 = sens_subset(td);  U2 = sens_subset(td);
pass_or_fail('subset: 20 sessions per duty, sorted, the same on every call', ...
             numel(U1.session) == 60 && all(histc(U1.duty, [0.4 0.6 0.8]) == 20) && issorted(U1.session) && isequal(U1, U2));
S.machine(1:150) = S.machine(end:-1:1);  save(fullfile(td, 'datasets', 'sessions.mat'), 'S');
pass_or_fail('subset: a saved subset from another plan stops the run', throws(@() sens_subset(td), 'sens_subset:changed'));
nS = 60;  sess = (1:nS)';  fold = mod((0:nS-1)', 5) + 1;
Fv = cell(1, 3);
for d = 1:3
    code = repmat((1:5)', nS, 1);  ss = kron(sess, ones(5,1));  sv = rand(rs, 5*nS, 1);
    A = repmat(code, 1, 10) + 0.01*randn(rs, 5*nS, 10);
    Fv{d} = struct('A', A, 'B1', [code, zeros(5*nS, 8)], 'B2', [code, zeros(5*nS, 8)], ...
                   'code', code, 'severity', sv, 'session', ss);
    if d == 1, k = code <= 4; Fv{1} = sub(Fv{1}, k); end
end
Sc = sens_scores(Fv, sess, fold, 100);
T = sens_stats(Sc, ones(nS, 1));
pass_or_fail('scores: separable classes give 100% in every cell, gaps of zero', ...
             all(abs(T.acc - 1) < 1e-12) && all(abs(T.v(2:4)) < 1e-12) && sum(Sc.nSmall) == 20);
Sx = struct('n', [2 2 2 2 2; 2 2 2 2 2], 'ok', [2 1 1 2 1; 0 1 2 1 1], 'nSmall', [1; 1], 'okSmall', [1 0; 1 1]);
Tx = sens_stats(Sx, [1 2; 1 0]);
pass_or_fail('statistics: hand-counted accuracies, gaps and recall, two weightings', ...
             max(abs(Tx.v(:,1) - [0.5; -0.25; 0.25; 0.5])) < 1e-12 && max(abs(Tx.v(:,2) - [1; 0.5; 0.5; 1])) < 1e-12);
r1 = sens_verdict(0.10, 0.10 + 0.02*randn(rs, 1, 2000), 0.12, 0.12 + 0.02*randn(rs, 1, 2000));
r2 = sens_verdict(0.10, 0.10 + 0.02*randn(rs, 1, 2000), 0.01, 0.01 + 0.02*randn(rs, 1, 2000));
r3 = sens_verdict(0.00, 0.03*randn(rs, 1, 2000), 0.01, 0.01 + 0.03*randn(rs, 1, 2000));
r4 = sens_verdict(0.00, 0.03*randn(rs, 1, 2000), -0.20, -0.20 + 0.03*randn(rs, 1, 2000));
pass_or_fail('rule: kept sign holds; lost sign changes; null stays null; null to sign changes', ...
             r1.holds && ~r2.holds && r3.holds && ~r4.holds && r1.cBase == 1 && r4.cVar == -1);
b = 0.5 + 0.05*randn(rs, 1, 2000);  r5 = sens_verdict(0.5, b, 0.5, b);
pass_or_fail('rule: a variant identical to the base has a zero paired change', r5.d == 0 && r5.dlo == 0 && r5.dhi == 0 && ~r5.moved);
fprintf('\n');
end

function i = sortidx(x)
[~, i] = sort(x);
end

function Y = sub(X, k)
Y = X;
for f = fieldnames(X)'
    v = X.(f{1});  if size(v, 1) == numel(k), Y.(f{1}) = v(k,:); end
end
end

function t = throws(f, id)
t = false;
try, f(); catch err, t = strcmp(err.identifier, id); end
end

function pass_or_fail(name, ok)
status = 'FAIL';  if ok, status = 'pass'; end
fprintf('%-62s [%s]\n', name, status);
end
