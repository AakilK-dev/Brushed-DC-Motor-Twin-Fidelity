function verify_integrated()

fprintf('\nIntegrated tool verification\n\n');
p = params_default();  rs = RandStream('mt19937ar', 'Seed', 11);
n = 400;  code = repmat((1:5)', n/5, 1);  sev = zeros(n, 1);
sev(code == 2) = 0.02 + 0.28*rand(rs, nnz(code == 2), 1);
sev(code == 3) = 0.1 + 0.9*rand(rs, nnz(code == 3), 1);
sev(code == 4) = 0.05 + 0.95*rand(rs, nnz(code == 4), 1);
sev(code == 5) = 5e-6 + 2e-5*rand(rs, nnz(code == 5), 1);
w = 150 + 20*rand(rs, n, 1);  bb = 1e-4*ones(n, 1);
B = 1e-4*randn(rs, n, 7);  A = 1e-3*randn(rs, n, 10);
B(code == 2, 1) = sev(code == 2);
B(code == 3, 2) = -p.sc.dK*sev(code == 3);
B(code == 4, 4) = p.brg.kf*bb(code == 4).*w(code == 4).*sev(code == 4);
wn = 2*pi*p.modes.f(1);  z = p.modes.zeta(1);
A(code == 5, 9) = sev(code == 5).*w(code == 5).^4./(p.M*sqrt((wn^2 - w(code == 5).^2).^2 + (2*z*wn*w(code == 5)).^2))/9.81;
Tr = struct('A', A, 'B', B, 'aux', [w bb], 'code', code, 'severity', sev, 'fold', mod(floor((0:n-1)'/5), 5) + 1);
Te = struct('A', zeros(6, 10), 'B', zeros(6, 7), 'aux', [150*ones(6,1), 1e-4*ones(6,1)], ...
            'code', [3; 2; 4; 4; 4; 2], 'severity', [0.5; 0.1; 0.3; 0.3; 0.9; 0.15]);
Te.B(1,[1 2]) = [0.01, -0.02];  Te.B(2,1) = 0.1;  Te.B(3,4) = 0.010;  Te.B(4,4) = 0.010;  Te.A(4,10) = 1;
Te.B(5,4) = 0.020;  Te.B(6,1) = 0.15;
D = integrated_core(Tr, Te, [2; 3; 4; 4; 4; 2], p, 500);
pass_or_fail('evidence thresholds at the 99th percentile of the normal runs', ...
             max(abs(D.thr.B - prctile(abs(B(code == 1,:)), 99, 1))) < 1e-15);
pass_or_fail('rule: typed resistive with Ke fallen is retyped shorted bar', D.type2(1) == 3);
pass_or_fail('rule: typed shorted bar, Ke steady, R up, is retyped resistive', D.type2(2) == 2);
pass_or_fail('brake drift bound 3 sqrt(2) reg Tfs/3 = 14.1 mN.m', abs(D.thr.drift - 0.0141421) < 1e-6);
pass_or_fail('bearing within the drift: unconfirmed without vibration, kept with it', ...
             D.unconfirmed(3) && ~D.unconfirmed(4) && ~D.unconfirmed(5) && all(D.type2(3:5) == 4));
pass_or_fail('evidence supports the clean resistive and the bearing calls', D.supports(6) && D.supports(5) && D.supports(4));
pass_or_fail('severity: the exact physics is chosen for every fault and is exact', ...
             all(strcmp(D.method, 'Physics')) && abs(D.sev(6) - 0.15) < 1e-12 && abs(D.sev(5) - 0.020/(p.brg.kf*1e-4*150)) < 1e-9);
fprintf('\n');
end

function pass_or_fail(name, ok)
status = 'FAIL';  if ok, status = 'pass'; end
fprintf('%-62s [%s]\n', name, status);
end
