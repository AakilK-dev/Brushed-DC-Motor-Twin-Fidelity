function verify_service()

p  = params_default();
fprintf('\nService conditions verification\n\n');

c2 = cfg_model2();  c2.gearbox = false;  c2.modes = [];
V  = 14.4;
pA = p;  pB = rmfield(p, {'dTL','eVs'});
oA = run_sim(pA, c2, @(t) V, 0.05);
oB = run_sim(pB, c2, @(t) V, 0.05);
pass_or_fail('defaults leave the model bit-for-bit unchanged', ...
    isequal(oA.x, oB.x) && isequal(oA.V, oB.V));

c1 = cfg_model1();
pS = p;  pS.eVs = 0.01;
tauM = p.J*p.R/(p.R*p.b_lin + p.Kt*p.Ke);
oS = run_sim(pS, c1, @(t) V, 20*tauM);
pass_or_fail('applied voltage is the setting times (1 + eVs)', ...
    max(abs(oS.V - V*1.01)) < 1e-12);
wS = p.Kt*V*1.01/(p.R*p.b_lin + p.Kt*p.Ke);
report('steady speed with a +1% supply offset', oS.x(end,oS.idx.w), wS, 1e-4);

pL = p;  pL.TL = p.TLfrac*p.Kt*p.Irated;  pL.dTL = 0.004;
cL = c2;  cL.thermal = false;  cL.imbalance = false;
wL = (p.Kt*V/p.R - p.Tc - pL.TL - pL.dTL)/(p.Kt*p.Ke/p.R + p.b);
oL = run_sim(pL, cL, @(t) V, 20*tauM);
report('steady speed with set load plus offset', oL.x(end,oL.idx.w), wL, 1e-3);

pJ = p;  pJ.J = p.J + p.brake.J;
Vs = 1.0;  tq = [0.01 0.03 0.06];
oJ = run_sim(pJ, c1, @(t) Vs, 0.1);
wJ = interp1(oJ.t, oJ.x(:,oJ.idx.w), tq);
wC = m1_step(tq, p.R, p.L, p.Kt, p.Ke, pJ.J, p.b_lin, Vs);
report('step response with brake inertia, worst of three times', ...
    max(abs(wJ - wC)./abs(wC)) + 1, 1, 1e-4);

n = 4000;  e = zeros(n,1);  dT = zeros(n,1);
for k = 1:n
    [~, d] = service_conditions(p, p, true, 5000 + k);
    e(k) = d.eVs;  dT(k) = d.dTL;
end
report('spread of supply offsets', std(e),  p.supply.tol/3, 0.05);
report('spread of load offsets',   std(dT), p.brake.reg*p.brake.Tfs/3, 0.05);
[q1, d1] = service_conditions(p, p, true, 77);
[~,  d2] = service_conditions(p, p, true, 77);
pass_or_fail('offsets reproducible from their seed', isequal(d1, d2));
pass_or_fail('loaded run adds exactly the brake inertia', q1.J == p.J + p.brake.J);
[q0, d0] = service_conditions(p, p, false, 77);
pass_or_fail('no-load run carries no load, offset or brake inertia', ...
    q0.TL == 0 && q0.dTL == 0 && q0.J == p.J && d0.dTL == 0);

ff = 2.5;  D = 1;  V0 = 0.8*p.Vs*(1 + p.supply.tol);  Rc = p.R;
TL = p.TLfrac*p.Kt*p.Irated + p.brake.reg*p.brake.Tfs;
b  = ff*p.b*(1 + p.brg.kf*D);  Tc = ff*p.Tc;
w  = (p.Kt*V0/Rc - Tc - TL)/(p.Kt*p.Ke/Rc + b);
ipk = (V0 - p.Ke*w)/Rc + 0.02*V0/Rc;
rSvc = cur_range(p.cur_svc);
pass_or_fail(sprintf('current channel covers worst loaded case (%.1f A of %.1f A)', ipk, rSvc), ipk < 0.9*rSvc);
fprintf('\n');
end

function w = m1_step(t, R, L, Kt, Ke, J, b, V)
A   = [-R/L, -Ke/L;  Kt/J, -b/J];
xss = -A\[V/L; 0];
[Vc, D] = eig(A);  lam = diag(D);
c   = Vc\(-xss);
w   = real(xss(2) + (Vc(2,:).*c.')*exp(lam*t(:).'));
end

function report(name, got, want, tol)
err = abs(got - want)/max(abs(want), eps);
status = 'FAIL';  if err <= tol, status = 'pass'; end
fprintf('%-58s got %11.5g   want %11.5g   [%s]\n', name, got, want, status);
end

function pass_or_fail(name, ok)
status = 'FAIL';  if ok, status = 'pass'; end
fprintf('%-58s [%s]\n', name, status);
end
