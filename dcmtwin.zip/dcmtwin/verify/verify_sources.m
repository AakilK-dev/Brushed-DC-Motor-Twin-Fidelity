function verify_sources()

p = params_default();
fprintf('\nSource verification\n\n');

report('Kt equals Ke', p.Kt, p.Ke, 0);
nNL = p.Vs/p.Ke*60/(2*pi);
report('no-load speed against nameplate, rpm', nNL, p.nNL, 0.02);
I  = p.Irated;
w  = (p.Vs - p.R*I)/p.Ke;
Pm = (p.Kt*I - p.b_lin*w)*w;
report('output at rated current, W', Pm, p.Prated, 0.02);
eff = Pm/(p.Vs*I);  stall = p.Vs/p.R/I;  nl = p.b_lin*(p.Vs/p.Ke)/p.Kt/I;
fprintf('%-40s %.0f %%   stall/rated %.1f   no-load/rated %.0f %%\n', ...
        'efficiency at rated current', 100*eff, stall, 100*nl);
pass_or_fail('rated point typical of brushed PMDC', ...
             eff > 0.6 && eff < 0.9 && stall > 5 && stall < 15 && nl > 0.05 && nl < 0.15);

Jr = sqrt(pi)*gamma(1.75)/gamma(2.25)/(2*pi);
report('load zone constant against 1/Jr', p.brg.Qfac, 1/Jr, 1e-3);
N   = p.brg.Nb;  psi = 2*pi*(0:N-1)/N;  ph = linspace(0, 2*pi/N, 2001);
car = arrayfun(@(a) sum(p.brg.Qfac/N*max(0,cos(psi+a)).^1.5.*cos(psi+a)), ph);
report('discrete balls carry the applied load', mean(car), 1, 1e-3);

rng(7, 'twister');  cv = p.brg.cv;  dt = 1e-5;  Q = 5;  n = 2e5;
for lam = [5e5 5e6]
    k  = poissrnd(lam*dt, n, 1);
    c  = zeros(n,1);  m = k > 0;
    c(m) = gamrnd(k(m)/cv^2, cv^2);
    F  = Q/(lam*dt)*c;
    report(sprintf('shot noise std, rate %.0e /s', lam), std(F), ...
           Q*sqrt((1 + cv^2)/(lam*dt)), 0.02);
end
fprintf('\n');
end

function report(name, got, want, tol)
err = abs(got - want)/max(abs(want), eps);
status = 'FAIL';  if err <= tol, status = 'pass'; end
fprintf('%-40s got %11.5g   expected %11.5g   rel err %8.2e   [%s]\n', ...
        name, got, want, err, status);
end

function pass_or_fail(name, ok)
status = 'FAIL';  if ok, status = 'pass'; end
fprintf('%-40s %50s[%s]\n', name, '', status);
end
