function [td, yd] = aa_decimate(t, y, fs_target, p)

fs_fine = 1/(t(2)-t(1));
if fs_target > fs_fine
    error('aa_decimate:rate','Target rate %g Hz exceeds the simulation rate %g Hz.', ...
          fs_target, fs_fine);
end
Wn = p.aa.frac*fs_target/(fs_fine/2);
[z, pl, k] = butter(p.aa.order, Wn);
sos = zp2sos(z, pl, k);
yf = sosfilt(sos, y);

step = round(fs_fine/fs_target);
td = t(1:step:end);
yd = yf(1:step:end);
end
