function r = cur_range(c)
span = 0.5*c.vfs;
if isfield(c, 'lin'), span = min(span, c.lin); end
r = span/c.sens;
end
