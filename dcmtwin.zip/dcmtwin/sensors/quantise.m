function yq = quantise(y, lsb, range)
yq = round(y/lsb)*lsb;
if nargin > 2 && ~isempty(range)
    if isscalar(range), lo = -range; hi = range; else, lo = range(1); hi = range(2); end
    yq = max(min(yq, hi), lo);
end
end
