function s = virtual_sensors(out, p, seed, channels)

if nargin < 3 || isempty(seed), seed = 0; end
if nargin < 4 || isempty(channels), channels = {'cur','vsup','enc','acc'}; end
want = @(c) any(strcmp(channels, c));
rsCur = RandStream('twister', 'Seed', seed);
rsAcc = RandStream('twister', 'Seed', seed + 7919);

t  = out.t;
fsFine = 1/(t(2) - t(1));
sdCur = p.cur.nd*sqrt(fsFine/2);
sdAcc = p.acc.nd*sqrt(fsFine/2);
i  = out.x(:,out.idx.i);
w  = out.x(:,out.idx.w);

if want('cur')
iN          = i + sdCur*randn(rsCur, size(i));
[s.cur.t, iD] = aa_decimate(t, iN, p.cur.fs, p);
lsbA        = (p.cur.vfs/2^p.cur.bits)/p.cur.sens;
rA          = cur_range(p.cur);
iD          = max(min(iD, rA), -rA);
s.cur.i     = quantise(iD, lsbA, 0.5*p.cur.vfs/p.cur.sens);
s.cur.lsb   = lsbA;
end

if want('vsup')
vIn = out.V;
if isfield(p.vsense,'nd') && p.vsense.nd > 0
    rsV = RandStream('twister', 'Seed', seed + 104729);
    vIn = vIn + p.vsense.nd*sqrt(fsFine/2)*randn(rsV, size(vIn));
end
[s.vsup.t, vD] = aa_decimate(t, vIn, p.vsense.fs, p);
lsbV        = (p.vsense.vfs/2^p.vsense.bits)/p.vsense.div;
s.vsup.v    = quantise(vD, lsbV, [0, p.vsense.vfs/p.vsense.div]);
s.vsup.lsb  = lsbV;
end

if want('enc')
if isfield(out.idx,'th')
    th = out.x(:,out.idx.th);
else
    th = cumtrapz(t, w);
end
cpr          = p.enc.ppr*p.enc.quad;
radPerCount  = 2*pi/cpr;
[s.enc.t, thD] = aa_decimate(t, th, p.cur.fs, p);
s.enc.counts = round(thD/radPerCount);
s.enc.theta  = s.enc.counts*radPerCount;
dt           = 1/p.cur.fs;
s.enc.w      = [0; diff(s.enc.theta)/dt];
s.enc.wres   = radPerCount/dt;
end

if want('acc')
a = zeros(size(t));
for m = 1:numel(out.idx.dy)
    a = a + out.dx(:,out.idx.dy(m));
end
aG            = a/9.81;
aN            = aG + sdAcc*randn(rsAcc, size(aG));
[s.acc.t, aD] = aa_decimate(t, aN, p.acc.fs, p);
lsbG          = (2*p.acc.vfs/2^p.acc.bits)/p.acc.sens;
s.acc.a       = quantise(aD, lsbG, p.acc.range);
s.acc.lsb     = lsbG;
end

s.meta = struct('seed',seed,'params',p);
end
