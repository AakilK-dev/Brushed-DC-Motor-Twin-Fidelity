function q = referred_params(p, cfg)
q = p;
if ~isfield(cfg,'gearbox') || ~cfg.gearbox
    return
end
q.Ke = p.N * p.Ke;
q.Kt = p.eta * p.N * p.Kt;
q.J  = p.N^2 * p.J;
end
