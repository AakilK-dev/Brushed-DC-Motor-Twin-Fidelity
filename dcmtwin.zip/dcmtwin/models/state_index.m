function idx = state_index(cfg)
n = 0;
n = n + 1; idx.i  = n;
n = n + 1; idx.w  = n;

needAngle = (isfield(cfg,'angle') && cfg.angle) || cfg.imbalance ...
            || cfg.commutation || cfg.coil_resolved;
if needAngle
    n = n + 1; idx.th = n;
end

idx.y = []; idx.dy = [];
if isfield(cfg,'modes') && ~isempty(cfg.modes)
    for m = 1:numel(cfg.modes)
        n = n + 1; idx.y(m)  = n;
        n = n + 1; idx.dy(m) = n;
    end
end

if cfg.antialias
    n = n + 1; idx.iflt = n;
end
idx.n = n;
end
