function F = bearing_force(t, x, p, cfg, idx)

nb   = p.brg.Nb;
th   = x(idx.th);
w    = x(idx.w);

phic = p.brg.FTF*th;
phik = phic + 2*pi*(0:nb-1)'/nb;
psi  = angle(exp(1i*phik));

Qmax = p.brg.Qfac*p.brg.W/nb;
Q    = Qmax*max(0, cos(psi)).^1.5;

if p.brg.D > 0
    if strcmpi(p.brg.loc, 'outer')
        phid = 0;
    else
        phid = th;
    end
    rel = angle(exp(1i*(phik - phid)));
    S   = abs(rel) < 0.5*p.brg.D*2*pi/nb;
else
    S   = false(nb,1);
end
eta = p.brg.eta_h*ones(nb,1);
eta(S) = p.brg.eta_d;

ro = 0.5*p.brg.Dp*(1 + p.brg.dDp);
v  = p.brg.FTF*abs(w)*ro;

fade = 1 - exp(-v/p.brg.vroll);
v    = max(v, eps);

dt = cfg.dt;
if isempty(p.brg.xi)
    xi = zeros(nb,1);
else
    k  = min(max(floor(t/dt + 1e-9) + 1, 1), size(p.brg.xi,1));
    xi = p.brg.xi(k,:)';
end
sig = fade*Q.*sqrt((1 + p.brg.cv^2)./(eta*v*dt));
Fk  = Q + sig.*xi;

F = -sum(Fk.*cos(psi));
end
