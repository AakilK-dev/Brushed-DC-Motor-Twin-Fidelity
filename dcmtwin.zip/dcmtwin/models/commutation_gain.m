function g = commutation_gain(th, p)
g = 1 + p.eps_c*cos(p.nbars*th) + p.delta_s*cos(p.nbrush*th);
end
