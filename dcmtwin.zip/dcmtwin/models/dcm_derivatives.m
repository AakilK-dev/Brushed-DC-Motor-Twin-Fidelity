function dx = dcm_derivatives(t, x, V, p, cfg, idx, oc)

dx = zeros(idx.n,1);
if nargin < 7 || isempty(oc), oc = false; end

i = x(idx.i);
w = x(idx.w);

q  = referred_params(p, cfg);
R  = q.R;
Ke = q.Ke;
Kt = q.Kt;

if cfg.thermal
    R = R*(1 + p.alpha*p.theta);
end
if cfg.commutation
    g  = commutation_gain(x(idx.th), q);
    Ke = Ke*g;
    Kt = Kt*g;
end

if oc
    i = 0;
    dx(idx.i) = 0;
else
    dx(idx.i) = (V - R*i - Ke*w)/p.L;
end

Tem = Kt*i;
Tf  = friction_model(w, q, cfg);
Tld = 0;
TLtot = 0;
if isfield(q,'TL'),  TLtot = TLtot + q.TL;  end
if isfield(q,'dTL'), TLtot = TLtot + q.dTL; end
if TLtot ~= 0
    Tld = Tld + TLtot*tanh(w/q.wt);
end

if cfg.imbalance
    Tld = Tld + p.mr*p.g*sin(x(idx.th));
end

if isfield(cfg,'locked_rotor') && cfg.locked_rotor
    dx(idx.w) = 0;
else
    dx(idx.w) = (Tem - Tf - Tld)/q.J;
end

if isfield(idx,'th')
    dx(idx.th) = w;
end

if ~isempty(idx.y)
    F = 0;
    if cfg.imbalance
        F = F - p.mr*w^2*cos(x(idx.th));
    end
    if cfg.bearing
        F = F + bearing_force(t, x, q, cfg, idx);
    end
    for m = 1:numel(cfg.modes)
        wn = 2*pi*p.modes.f(cfg.modes(m));
        zt = p.modes.zeta(cfg.modes(m));
        y  = x(idx.y(m));
        dy = x(idx.dy(m));
        dx(idx.y(m))  = dy;
        if cfg.modes(m) <= 2 || ~isfield(p, 'Mhf'), Mm = p.M; else, Mm = p.Mhf; end
        dx(idx.dy(m)) = F/Mm - 2*zt*wn*dy - wn^2*y;
    end
end

end
