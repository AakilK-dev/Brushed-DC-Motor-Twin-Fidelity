function Tf = friction_model(w, p, cfg)
switch cfg.friction
    case 'viscous'
        Tf = p.b_lin*w;
    case 'coulomb'
        Tf = p.b*w + p.Tc*tanh(w/p.wt);
    case 'stribeck'
        Tstr = p.Tc + (p.Ts - p.Tc)*exp(-abs(w/p.ws).^p.delta);
        Tf   = p.b*w + Tstr.*tanh(w/p.wt);
    otherwise
        error('friction_model:cfg','Unknown friction model "%s".', cfg.friction);
end
end
