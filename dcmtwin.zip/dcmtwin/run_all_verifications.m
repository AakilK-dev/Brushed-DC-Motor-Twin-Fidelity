function nFail = run_all_verifications(mode)

if nargin < 1, mode = 'quick'; end
scripts = {'verify_model1','verify_model2','verify_energy','verify_sensors', ...
           'verify_excitation','verify_sampler','verify_model3','verify_bearing', ...
           'verify_numerics','verify_sources','verify_service','verify_identify','verify_ekf','verify_mounting','verify_onset', ...
           'verify_features','verify_lsq','verify_sensitivity','verify_holdout','verify_integrated'};
if strcmpi(mode,'full'), scripts{end+1} = 'verify_ensemble'; end

fprintf('\n%-22s %6s %6s %8s  %s\n','script','pass','FAIL','time s','status');
tot = [0 0];  bad = {};
for k = 1:numel(scripts)
    t0 = tic;
    try
        txt = evalc(scripts{k});
        np  = numel(strfind(txt, '[pass]'));
        nf  = numel(strfind(txt, '[FAIL]'));
        if nf == 0, st = 'ok'; else, st = 'CHECK OUTPUT'; bad{end+1} = scripts{k}; end
    catch err
        np = 0;  nf = 1;  st = ['ERROR: ' err.message];  bad{end+1} = scripts{k};
    end
    tot = tot + [np nf];
    fprintf('%-22s %6d %6d %8.1f  %s\n', scripts{k}, np, nf, toc(t0), st);
end
fprintf('%-22s %6d %6d\n\n', 'TOTAL', tot(1), tot(2));
nFail = tot(2);
if isempty(bad)
    fprintf('All checks pass.\n\n');
else
    fprintf('Run these individually to see the failing lines: %s\n\n', strjoin(bad, ', '));
end
end
