function C = check_dataset(outdir, model)

dd = fullfile(outdir, 'datasets', sprintf('M%d', model));
F  = dir(fullfile(dd, 'session_*.mat'));
fprintf('\nModel %d dataset: %d sessions in %s\n', model, numel(F), dd);
states = {'healthy','resistive','shorted_bar','bearing_outer','imbalance'};
D = struct();  for k = 1:numel(states), D.(states{k}) = []; end
nRuns = 0;  bad = {};
for f = 1:numel(F)
    L = load(fullfile(dd, F(f).name), 'X');  X = L.X;
    nRuns = nRuns + numel(X.runs);
    for i = 1:numel(X.runs)
        fl = X.runs(i).flags;
        if fl.nan || fl.clipCur || fl.clipAcc
            bad{end+1} = sprintf('%s run %d (%s): nan %d, current clipped %d, vibration clipped %d', ...
                F(f).name, i, X.runs(i).state, fl.nan, fl.clipCur, fl.clipAcc);
        end
    end
    b = summ(X.runs(1).rec);
    for i = 2:numel(X.runs)
        r = summ(X.runs(i).rec);
        v = [100*(r.w/b.w - 1), 100*(r.i/b.i - 1), 100*(r.a/b.a - 1), abs(r.a1 - b.a1), abs(r.i2 - b.i2)];
        D.(X.runs(i).state)(end+1,:) = v;
    end
end
fprintf('%d runs; flagged: %d\n', nRuns, numel(bad));
for k = 1:numel(bad), fprintf('  %s\n', bad{k}); end
fprintf('\nMedian change from the session baseline\n');
fprintf('%-14s %10s %10s %12s %14s %14s\n', 'run', 'speed %', 'current %', 'vib level %', 'vib 1x (g)', 'current 2x (A)');
for k = 1:numel(states)
    v = D.(states{k});  if isempty(v), continue; end
    m = median(v, 1);
    fprintf('%-14s %10.3f %10.3f %12.2f %14.5f %14.5f\n', states{k}, m);
end
fprintf('\n');
C = D;
end

function r = summ(rec)
fs = rec.cur.fs;  k0 = round(0.5*fs) + 1;
th = double(rec.enc.y);  i = double(rec.cur.y);
r.w = (th(end) - th(k0))/((numel(th) - k0)/fs);
r.i = mean(i(k0:end));
r.i2 = ordern(i(k0:end) - mean(i(k0:end)), th(k0:end), 2);
fa = rec.acc.fs;  a0 = round(0.5*fa) + 1;
a = double(rec.acc.y(a0:end));  a = a - mean(a);
r.a  = sqrt(mean(a.^2));
ta = (0:numel(rec.acc.y)-1)'/fa;  tc = (0:numel(th)-1)'/fs;
r.a1 = ordern(a, interp1(tc, th, ta(a0:end), 'linear', 'extrap'), 1);
end

function c = ordern(a, th, n)
t0 = th(1);  nrev = floor((th(end) - t0)/(2*pi));
k = th <= t0 + nrev*2*pi;  tt = th(k);  aa = a(k);  dth = gradient(tt);
c = 2*sum(aa.*exp(-1i*n*tt).*dth)/sum(dth);
end
