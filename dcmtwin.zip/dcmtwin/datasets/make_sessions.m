function S = make_sessions(outdir, nS)

if nargin < 2 || isempty(nS), nS = 150; end
p  = params_default();
L  = load(fullfile(outdir, 'calibration.mat'), 'T');  T = L.T;
rs = RandStream('mt19937ar', 'Seed', 20261001);
perm   = T.machine(randperm(rs, height(T)));
duties = [0.4 0.6 0.8];
nPer   = ceil(nS/3);
smin = 1/(1 + p.sc.range(2));  smax = 1/(1 + p.sc.range(1));
rows = zeros(nS, 9);
for j = 1:nS
    dk    = min(3, ceil(j/nPer));
    theta = 70*rand(rs);
    s     = 0.02 + 0.28*rand(rs);
    f     = 0.1  + 0.9*rand(rs);
    r     = 1/(smin + f*(smax - smin)) - 1;
    D     = 0.05 + 0.95*rand(rs);
    mr    = 5e-6 + 2.0e-5*rand(rs);
    rows(j,:) = [j, perm(j), duties(dk), theta, s, f, r, D, mr];
end
S = array2table(rows, 'VariableNames', {'session','machine','duty','theta_degC', ...
    'res_s','sc_f','sc_r','brg_D','imb_mr'});
S.seed = 3000000 + 100*S.session;
d = fullfile(outdir, 'datasets');  if ~exist(d, 'dir'), mkdir(d); end
save(fullfile(d, 'sessions.mat'), 'S');  writetable(S, fullfile(d, 'sessions.csv'));
fprintf('%d sessions written to %s\n', nS, d);
end
