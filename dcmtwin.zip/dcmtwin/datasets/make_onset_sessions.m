function S = make_onset_sessions(outdir)
p = params_default();  A = allocate_reserve(outdir);  m = A.onset(:);  n = numel(m);
rs = RandStream('mt19937ar', 'Seed', 20261011);
m = m(randperm(rs, n));
duties = repelem([0.4; 0.6; 0.8], ceil(n/3));  duties = duties(1:n);
smin = 1/(1 + p.sc.range(2));  smax = 1/(1 + p.sc.range(1));
theta = 70*rand(rs, n, 1);
s  = 0.02 + 0.28*rand(rs, n, 1);   f = 0.1 + 0.9*rand(rs, n, 1);   r = 1./(smin + f*(smax - smin)) - 1;
D  = 0.05 + 0.95*rand(rs, n, 1);   mr = 5e-6 + 2.0e-5*rand(rs, n, 1);
on = 1.5 + 2.0*rand(rs, n, 4);
S = table((1:n)', m, duties, theta, s, f, r, D, mr, on(:,1), on(:,2), on(:,3), on(:,4), ...
          'VariableNames', {'session','machine','duty','theta_degC','res_s','sc_f','sc_r','brg_D','imb_mr', ...
                            'on_res','on_sc','on_brg','on_imb'});
S.calib = mod(S.session, 3) == 1;
S.seed  = 5000000 + 100*S.session;
save(fullfile(outdir, 'datasets', 'onset_sessions.mat'), 'S');
writetable(S, fullfile(outdir, 'datasets', 'onset_sessions.csv'));
fprintf('%d onset sessions written: %d for thresholds, %d scored\n', n, nnz(S.calib), nnz(~S.calib));
end
