function generate_dataset(outdir, model, nS, planName)

p  = params_default();
if nargin < 4 || isempty(planName), planName = 'sessions'; end
tuning = strcmpi(planName, 'tuning');  onsetPlan = strcmpi(planName, 'onset');
if onsetPlan && model ~= 3, error('generate_dataset:onset', 'onset runs are generated for the reference (model 3) only'); end
holdPlan = strcmpi(planName, 'holdout');
if holdPlan && model ~= 3, error('generate_dataset:holdout', 'hold-out runs are generated for the reference (model 3) only'); end
if tuning, planFile = 'tuning_sessions.mat'; elseif onsetPlan, planFile = 'onset_sessions.mat'; else, planFile = 'sessions.mat'; end
if holdPlan, planFile = 'holdout_sessions.mat'; end
mode = 'normal';  if tuning, mode = 'tuning'; elseif onsetPlan, mode = 'onset'; end
L  = load(fullfile(outdir, 'datasets', planFile), 'S');   S = L.S;
L  = load(fullfile(outdir, 'calibration.mat'), 'T');             Tcal = L.T;
if nargin < 3 || isempty(nS), nS = height(S); end
S  = S(1:nS, :);
if tuning,        dd = fullfile(outdir, 'datasets', sprintf('tuning_M%d', model));
elseif onsetPlan, dd = fullfile(outdir, 'datasets', 'onset_M3');
else,             dd = fullfile(outdir, 'datasets', sprintf('M%d', model)); end
if holdPlan,      dd = fullfile(outdir, 'datasets', 'holdout_M3'); end
if ~exist(dd, 'dir'), mkdir(dd); end
stale = dir(fullfile(dd, 'tmp_*.mat'));
for k = 1:numel(stale), delete(fullfile(dd, stale(k).name)); end
prov = physics_provenance(p);
done = false(nS, 1);  nStale = 0;
for j = 1:nS
    fj = fullfile(dd, sprintf('session_%04d.mat', S.session(j)));
    if exist(fj, 'file') ~= 2, continue; end
    Lj = load(fj, 'X');
    if isfield(Lj.X, 'provenance') && isequal(Lj.X.provenance, prov), done(j) = true;
    else, delete(fj);  nStale = nStale + 1;
    end
end
fprintf('\nModel %d dataset: %d sessions, %d already finished, %d stale files rebuilt.\n', model, nS, sum(done), nStale);

dq = parallel.pool.DataQueue;  t0 = tic;
tick('reset', sum(done));
afterEach(dq, @(~) tick('tick', nS, t0));
parfor j = 1:nS
    if done(j), continue; end
    row = S(j,:);
    Tr  = Tcal(Tcal.machine == row.machine, :);
    X   = one_session(outdir, row, Tr, model, p, mode);
    X.provenance = prov;
    save_atomic(fullfile(dd, sprintf('session_%04d.mat', row.session)), X);
    send(dq, j);
end
fprintf('Model %d dataset complete: %s\n\n', model, dd);
end

function X = one_session(outdir, row, Tr, model, p, mode)
onset = strcmp(mode, 'onset');  normalOnly = strcmp(mode, 'tuning');
Tp = 2.5;  if onset, Tp = 6; end
V0 = row.duty*p.Vs;
switch model
    case 3
        L  = load(fullfile(outdir, sprintf('machine_%04d.mat', row.machine)), 'R');
        q0 = true_machine(p, L.R);  cfg = cfg_model3();
        [q0, mnt] = service_mounting(q0, p, row.seed + 17);
    otherwise
        [q0, cfg] = calibrated_twin(p, Tr, model);
        mnt = 'bench';
end
q0.theta = row.theta_degC;
plan = {'baseline',[]; 'healthy',[]; 'resistive',row.res_s; 'shorted_bar',row.sc_r; ...
        'bearing_outer',row.brg_D; 'imbalance',row.imb_mr};
sev  = [NaN, NaN, row.res_s, row.sc_f, row.brg_D, row.imb_mr];
if model == 1, plan = plan(1:5,:); sev = sev(1:5); end
if normalOnly, plan = plan(1:2,:); sev = sev(1:2); end
X.session = row;  X.model = model;  X.mounting = mnt;
if onset
    tOn = [NaN, NaN, row.on_res, row.on_sc, row.on_brg, row.on_imb];
    X.runs = struct('state',{},'severity',{},'rec',{},'truth',{},'flags',{},'seeds',{},'onset',{});
else
    X.runs = struct('state',{},'severity',{},'rec',{},'truth',{},'flags',{},'seeds',{});
end
for i = 1:size(plan,1)
    base = row.seed + 10*i;
    q = q0;
    if ~onset && ~isempty(plan{i,2}), q = apply_fault(q, plan{i,1}, plan{i,2}); end
    [q, dsv] = service_conditions(q, p, true, base + 1);
    q.cur = p.cur_svc;
    q.vsense = p.vsense_svc;
    if cfg.bearing, q = make_bearing_noise(q, cfg, Tp, base + 2); end
    qT = q;
    if onset && ~isempty(plan{i,2})
        qT = apply_fault(q, plan{i,1}, plan{i,2});
        q.onset = struct('t', tOn(i), 'p', qT);
    end
    dz  = excitation('dither','V0',V0,'amp',0.02,'thold',0.02,'tEnd',Tp,'seed',base + 3);
    out = run_sim(q, cfg, dz, Tp, steady_start(q, cfg, V0));
    s   = virtual_sensors(out, q, base + 4, {'cur','vsup','enc','acc'});
    rec = compact(s);
    fl.nan     = any(isnan(rec.cur.y)) || any(isnan(rec.enc.y)) || any(isnan(rec.acc.y)) || any(isnan(rec.vsup.y));
    fl.clipCur = max(abs(double(rec.cur.y))) >= 0.999*cur_range(q.cur);
    fl.clipAcc = max(abs(double(rec.acc.y))) >= 0.999*p.acc.range;
    tr.R   = qT.R*(1 + qT.alpha*qT.theta*cfg.thermal);
    tr.L   = qT.L;  tr.Ke = qT.Ke;  tr.Kt = qT.Kt;  tr.J = qT.J;
    if strcmp(cfg.friction, 'viscous'), tr.b = qT.b_lin; tr.Tc = 0; else, tr.b = qT.b; tr.Tc = qT.Tc; end
    tr.TL = qT.TL + qT.dTL;  tr.eVs = dsv.eVs;  tr.mr = qT.mr;
    if onset
        X.runs(i) = struct('state',plan{i,1},'severity',sev(i),'rec',rec,'truth',tr, ...
                           'flags',fl,'seeds',base + (1:4),'onset',tOn(i));
    else
        X.runs(i) = struct('state',plan{i,1},'severity',sev(i),'rec',rec,'truth',tr, ...
                           'flags',fl,'seeds',base + (1:4));
    end
end
end

function x0 = steady_start(q, cfg, V)
idx = state_index(cfg);  R = q.R;
if cfg.thermal, R = R*(1 + q.alpha*q.theta); end
V  = V*(1 + q.eVs);  TL = q.TL + q.dTL;
if strcmp(cfg.friction, 'viscous')
    w0 = (q.Kt*V/R - TL)/(q.Kt*q.Ke/R + q.b_lin);
else
    w0 = (q.Kt*V/R - q.Tc - TL)/(q.Kt*q.Ke/R + q.b);
end
x0 = zeros(idx.n,1);  x0(idx.i) = (V - q.Ke*w0)/R;  x0(idx.w) = w0;
end

function c = compact(s)
c = struct();
for f = {'cur','vsup','enc','acc'}
    ch = s.(f{1});  c.(f{1}).fs = 1/(ch.t(2) - ch.t(1));
    switch f{1}
        case 'cur',  c.cur.y  = single(ch.i);
        case 'vsup', c.vsup.y = single(ch.v);
        case 'enc',  c.enc.y  = single(ch.theta);
        case 'acc',  c.acc.y  = single(ch.a);
    end
end
end

function save_atomic(f, X)
[d, n] = fileparts(f);  tmp = fullfile(d, ['tmp_' n '.mat']);
save(tmp, 'X', '-v7');  movefile(tmp, f);
end

function tick(mode, a, b)
persistent n
switch mode
    case 'reset', n = a;
    case 'tick'
        n = n + 1;
        fprintf('session %4d of %d done   elapsed %6.1f min\n', n, a, toc(b)/60);
end
end
