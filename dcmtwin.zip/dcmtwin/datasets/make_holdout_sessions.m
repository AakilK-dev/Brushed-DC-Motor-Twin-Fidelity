function S = make_holdout_sessions(outdir)

p  = params_default();
L  = load(fullfile(outdir, 'datasets', 'reserve_allocation.mat'), 'A');  A = L.A;
m  = A.holdout(:);  nS = numel(m);
other = [A.diagnosis(:); A.tuning(:); A.onset(:); A.spare(:)];
if any(ismember(m, other)), error('make_holdout_sessions:overlap', 'hold-out machines appear in another group'); end
rs = RandStream('mt19937ar', 'Seed', 20261013);
perm = m(randperm(rs, nS));
nd = floor(nS/3)*[1 1 1];  nd(1:mod(nS, 3)) = nd(1:mod(nS, 3)) + 1;
duty = [0.4*ones(nd(1),1); 0.6*ones(nd(2),1); 0.8*ones(nd(3),1)];
smin = 1/(1 + p.sc.range(2));  smax = 1/(1 + p.sc.range(1));
rows = zeros(nS, 9);
for j = 1:nS
    theta = 70*rand(rs);
    s     = 0.02 + 0.28*rand(rs);
    f     = 0.1  + 0.9*rand(rs);
    r     = 1/(smin + f*(smax - smin)) - 1;
    D     = 0.05 + 0.95*rand(rs);
    mr    = 5e-6 + 2.0e-5*rand(rs);
    rows(j,:) = [j, perm(j), duty(j), theta, s, f, r, D, mr];
end
S = array2table(rows, 'VariableNames', {'session','machine','duty','theta_degC', ...
    'res_s','sc_f','sc_r','brg_D','imb_mr'});
S.seed = 6000000 + 100*S.session;
save(fullfile(outdir, 'datasets', 'holdout_sessions.mat'), 'S');
writetable(S, fullfile(outdir, 'datasets', 'holdout_sessions.csv'));
fprintf('%d hold-out sessions written (duties %d, %d, %d), on the hold-out machines only\n', nS, nd);
end
