function S = make_tuning_sessions(outdir)

L  = load(fullfile(outdir, 'datasets', 'sessions.mat'), 'S');   Sd = L.S;
L  = load(fullfile(outdir, 'calibration.mat'), 'T');             T  = L.T;
reserve = setdiff(T.machine, Sd.machine);
rs = RandStream('mt19937ar', 'Seed', 20261003);
pick = reserve(randperm(rs, numel(reserve), 15));
duties = repelem([0.4; 0.6; 0.8], 5);
n = numel(pick);
S = table((1:n)', pick(:), duties, 70*rand(rs, n, 1), nan(n,1), nan(n,1), nan(n,1), nan(n,1), nan(n,1), ...
          'VariableNames', {'session','machine','duty','theta_degC','res_s','sc_f','sc_r','brg_D','imb_mr'});
S.seed = 4000000 + 100*S.session;
save(fullfile(outdir, 'datasets', 'tuning_sessions.mat'), 'S');
writetable(S, fullfile(outdir, 'datasets', 'tuning_sessions.csv'));
fprintf('%d tuning sessions on reserve machines written; none appears in the datasets: %d\n', ...
        n, isempty(intersect(S.machine, Sd.machine)));
end
