function A = allocate_reserve(outdir)
f = fullfile(outdir, 'datasets', 'reserve_allocation.mat');
Lc = load(fullfile(outdir, 'calibration.mat'), 'T');  allM = Lc.T.machine;
Ls = load(fullfile(outdir, 'datasets', 'sessions.mat'), 'S');  diag = Ls.S.machine;
Lt = load(fullfile(outdir, 'datasets', 'tuning_sessions.mat'), 'S');  tune = Lt.S.machine;
if exist(f, 'file') == 2
    L = load(f, 'A');  A = L.A;  fprintf('Reserve allocation loaded from %s\n', f);
    if ~isequal(A.diagnosis(:), sort(diag(:))) || ~isequal(A.tuning(:), sort(tune(:)))
        error('allocate_reserve:changed', ['the diagnosis or tuning machines of this run differ from ' ...
              'those the allocation in %s was made with'], f);
    end
    fprintf('  made with the same diagnosis and tuning machines as this run\n');
else
    reserve = setdiff(allM, union(diag, tune));
    rs = RandStream('mt19937ar', 'Seed', 20261010);
    r = reserve(randperm(rs, numel(reserve)));
    A = struct('holdout', sort(r(1:100)), 'onset', sort(r(101:160)), 'spare', sort(r(161:end)), ...
               'diagnosis', sort(diag), 'tuning', sort(tune), 'created', datestr(now, 31));
    save(f, 'A');  fprintf('Reserve allocation written to %s\n', f);
end
g = {A.diagnosis, A.tuning, A.holdout, A.onset, A.spare};  nm = {'diagnosis','tuning','holdout','onset','spare'};
for i = 1:5, for j = i+1:5
    if ~isempty(intersect(g{i}, g{j}))
        error('allocate_reserve:overlap', '%s and %s share %d machines', nm{i}, nm{j}, numel(intersect(g{i}, g{j})));
    end
end, end
if ~isequal(sort(vertcat(g{:})), sort(allM)), error('allocate_reserve:cover', 'the groups do not cover the ensemble exactly'); end
fprintf('  diagnosis %d, tuning %d, hold-out %d, onset %d, spare %d: all disjoint, together the whole ensemble\n', ...
        numel(A.diagnosis), numel(A.tuning), numel(A.holdout), numel(A.onset), numel(A.spare));
end
