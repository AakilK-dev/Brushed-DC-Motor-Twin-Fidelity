function test_new_stages(olddir, testdir)

VS = {'load_24','cool_15','kf_0','G_double','dK_double','coul_62','benchM_40','benchf1_125', ...
      'f1cov_30','Wsvc_double','epsc_36','brush_4','hmodes_12','Mh_025','summit_behzad', ...
      'sprR_2','sprFr_2','strib_off','strib_ws4'};
V = sens_variants();  missing = setdiff(VS, {V.name});
if ~isempty(missing), error('test_new_stages:variants', 'no variant named %s', strjoin(missing, ', ')); end

olddir = abspath(olddir);  testdir = abspath(testdir);
marker = fullfile(testdir, 'TEST_ONLY.txt');
if exist(marker, 'file') ~= 2
    f = fullfile(olddir, 'BUILD_COMPLETE.txt');
    if exist(f, 'file') ~= 2
        error('test_new_stages:old', '%s holds no complete run (no BUILD_COMPLETE.txt).', olddir);
    end
    txt = fileread(f);
    if isempty(strfind(txt, 'version 1.0.54'))
        error('test_new_stages:oldVersion', '%s was not made by dcmtwin 1.0.54:\n%s', olddir, txt);
    end
    if strcmpi(olddir, testdir) || strncmpi([testdir filesep], [olddir filesep], numel(olddir) + 1)
        error('test_new_stages:inside', 'the test folder must not be the v1.0.54 folder or inside it.');
    end
    if exist(testdir, 'dir')
        d = dir(testdir);  d = d(~ismember({d.name}, {'.', '..'}));
        if ~isempty(d), error('test_new_stages:notEmpty', '%s is not empty: give a new folder.', testdir); end
    else
        mkdir(testdir);
    end
    fprintf('Copying the v1.0.54 run\n  from %s\n  to   %s\n', olddir, testdir);  t0 = tic;
    d = dir(olddir);  d = d(~ismember({d.name}, {'.', '..'}));
    for k = 1:numel(d)
        [ok, msg] = copyfile(fullfile(olddir, d(k).name), fullfile(testdir, d(k).name));
        if ~ok, error('test_new_stages:copy', 'could not copy %s: %s', d(k).name, msg); end
    end
    if exist(fullfile(testdir, 'BUILD_COMPLETE.txt'), 'file') ~= 2
        error('test_new_stages:copy', 'the copy is incomplete: no BUILD_COMPLETE.txt in %s', testdir);
    end
    delete(fullfile(testdir, 'BUILD_COMPLETE.txt'));
    fid = fopen(marker, 'w');
    fprintf(fid, ['TEST ONLY. A copy of the v1.0.54 run in %s, made %s by test_new_stages to try\n' ...
                  'stages 12 to 15 of dcmtwin %s.  Nothing in this folder is used in the report.\n' ...
                  'Delete this folder once the test is over.\n'], olddir, datestr(now), code_version());
    fclose(fid);
    fprintf('Copied in %.1f min.\n', toc(t0)/60);
end

diary(fullfile(testdir, sprintf('test_log_%s.txt', datestr(now, 'yyyymmdd_HHMM'))));
c = onCleanup(@() diary('off'));
fprintf('\nTEST ONLY: stages 12 to 15 of dcmtwin %s on a copy of the v1.0.54 run, in %s.\n', code_version(), testdir);
fprintf('Nothing from this folder is used in the report.  MATLAB %s.\n', version);
try
    if license('test', 'Distrib_Computing_Toolbox') && isempty(gcp('nocreate')), parpool(feature('numcores')); end
catch err
    fprintf('No parallel pool (%s): the test runs serially, and more slowly.\n', err.message);
end
t0 = tic;
R = struct('name', {}, 'ok', {}, 'minutes', {}, 'report', {});
R = attempt(R, ' 1 the five new checks of stage 1', @() new_checks());
R = attempt(R, '12 least squares',                @() stage12(testdir));
R = attempt(R, '13 integrated diagnosis tool',    @() run_integrated(testdir));
R = attempt(R, '13 figures',                      @() plot_integrated(testdir));
R = attempt(R, '14 hold-out test, 6 spare machines', @() stage14(testdir));
R = attempt(R, '14 figure',                       @() plot_holdout(testdir));
R = attempt(R, '15 sensitivity, 19 variants on 6 sessions', ...
            @() run_sensitivity(testdir, struct('nPer', 2, 'nBoot', 200, 'variants', {VS})));
R = attempt(R, '15 figures',                      @() plot_sensitivity(testdir));

fprintf('\n==== TEST SUMMARY   (%.1f h)\n', toc(t0)/3600);
for k = 1:numel(R)
    if R(k).ok, s = 'passed'; else, s = 'FAILED'; end
    fprintf('  %-46s %s   %6.1f min\n', R(k).name, s, R(k).minutes);
end
nF = sum(~[R.ok]);
if nF == 0
    fprintf(['\nEvery step of stages 12 to 15 ran in MATLAB.  Send the log (test_log_*.txt in %s),\n' ...
             'then delete that folder and start the final run in a new, empty folder.\n'], testdir);
else
    fprintf('\n%d step(s) FAILED: each error is printed above, after the word FAILED.\n', nF);
    fprintf('Send the log (test_log_*.txt in %s).  Do not start the final run yet.\n', testdir);
end
end

function new_checks()
s = {'verify_features','verify_lsq','verify_sensitivity','verify_holdout','verify_integrated'};
fprintf('%-22s %6s %6s %8s\n', 'script', 'pass', 'FAIL', 'time s');
tot = [0 0];
for k = 1:numel(s)
    t0 = tic;  txt = evalc(s{k});
    np = numel(strfind(txt, '[pass]'));  nf = numel(strfind(txt, '[FAIL]'));
    fprintf('%-22s %6d %6d %8.1f\n', s{k}, np, nf, toc(t0));
    if nf > 0, fprintf('%s\n', txt); end
    tot = tot + [np nf];
end
fprintf('%-22s %6d %6d   (expected 46 pass, 0 FAIL)\n', 'TOTAL', tot(1), tot(2));
if tot(2) > 0 || tot(1) ~= 46
    error('test_new_stages:checks', '%d of the new checks failed and %d passed (expected 46 pass)', tot(2), tot(1));
end
end

function stage12(od)
for m = 1:3, run_lsq_dataset(od, m);  extract_features_lsq(od, m); end
run_grid_lsq(od);
end

function stage14(od)
f  = fullfile(od, 'datasets', 'reserve_allocation.mat');
f0 = fullfile(od, 'datasets', 'reserve_allocation_v1054.mat');
if exist(f0, 'file') ~= 2, copyfile(f, f0); end
L = load(f0, 'A');  A = L.A;
A.holdout = A.spare(1:6);  A.spare = A.spare(7:end);
save(f, 'A');
fprintf('Test hold-out machines (spare machines of the v1.0.54 allocation): %s\n', mat2str(A.holdout(:)'));
make_holdout_sessions(od);
generate_dataset(od, 3, [], 'holdout');
for tw = 1:2, run_ekf_dataset(od, 3, tw, 'holdout'); end
run_lsq_dataset(od, 3, 'holdout');
extract_holdout_features(od);
extract_features_lsq(od, 3, 'holdout');
run_holdout(od);
end

function R = attempt(R, name, fn)
fprintf('\n==== TEST %s\n', name);  t0 = tic;
try
    fn();  ok = true;  rep = '';
catch err
    ok = false;  rep = report_of(err);
    fprintf('\nFAILED: %s\n%s\n', name, rep);
end
R(end+1) = struct('name', name, 'ok', ok, 'minutes', toc(t0)/60, 'report', rep);
end

function s = report_of(err)
try
    s = getReport(err, 'extended', 'hyperlinks', 'off');
catch
    s = err.message;
    for k = 1:numel(err.stack)
        s = sprintf('%s\n  in %s at line %d', s, err.stack(k).name, err.stack(k).line);
    end
end
end

function f = abspath(f)
f = char(f);
if ~((numel(f) >= 2 && f(2) == ':') || (~isempty(f) && any(f(1) == '/\')))
    f = fullfile(pwd, f);
end
while numel(f) > 3 && any(f(end) == '/\'), f(end) = []; end
end

function v = code_version()
txt = fileread(fullfile(fileparts(mfilename('fullpath')), 'README.md'));
t = regexp(txt, 'Version (\d+\.\d+\.\d+)', 'tokens', 'once');
if isempty(t), v = 'unknown'; else, v = t{1}; end
end
