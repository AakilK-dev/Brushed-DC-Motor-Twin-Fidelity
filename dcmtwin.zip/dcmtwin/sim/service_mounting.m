function [q, d] = service_mounting(q, p, seed)
rs = RandStream('mt19937ar', 'Seed', seed);
s  = sqrt(log(1 + p.mount.f1cov^2));
ff = exp(-s^2/2 + s*randn(rs));
q.modes.f(1)    = p.modes.f(1)*ff;
q.modes.zeta(1) = p.mount.zeta(1) + diff(p.mount.zeta)*rand(rs);
q.M             = p.M*(p.mount.Mfac(1) + diff(p.mount.Mfac)*rand(rs));
q.brg.W         = p.brg.W_svc;
d = struct('f1', q.modes.f(1), 'zeta1', q.modes.zeta(1), 'M', q.M, 'W', q.brg.W, 'seed', seed);
end
