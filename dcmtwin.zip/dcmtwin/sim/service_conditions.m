function [q, d] = service_conditions(q, p, loaded, seed)

rs = RandStream('mt19937ar', 'Seed', seed);
z  = randn(rs, 1, 2);
d.eVs = (p.supply.tol/3)*z(1);
q.eVs = d.eVs;
if loaded
    d.TL  = p.TLfrac*p.Kt*p.Irated;
    d.dTL = (p.brake.reg*p.brake.Tfs/3)*z(2);
    q.TL  = d.TL;
    q.dTL = d.dTL;
    q.J   = q.J + p.brake.J;
else
    d.TL = 0;  d.dTL = 0;
    q.TL = 0;  q.dTL = 0;
end
end
