function out = run_sim(p, cfg, prof, tEnd, x0)

if isa(prof,'function_handle')
    Vfun = prof;           Ofun = @(t) false;   pname = 'handle';
else
    Vfun = prof.V;         Ofun = prof.open;    pname = prof.name;
end

if isfield(p,'eVs') && p.eVs ~= 0
    Vset = Vfun;  Vfun = @(tt) Vset(tt)*(1 + p.eVs);
end

idx = state_index(cfg);
if nargin < 5 || isempty(x0), x0 = zeros(idx.n,1); end

dt = cfg.dt;
n  = floor(tEnd/dt) + 1;
t  = (0:n-1)'*dt;

X  = zeros(n, idx.n);
DX = zeros(n, idx.n);
V  = zeros(n, 1);
OC = false(n, 1);
X(1,:) = x0(:)';

V1 = zeros(n-1,1);  V2 = V1;  V4 = V1;
O1 = false(n-1,1);  O2 = O1;  O4 = O1;
for k = 1:n-1
    tk = t(k);
    V1(k) = Vfun(tk);   V2(k) = Vfun(tk+dt/2);   V4(k) = Vfun(tk+dt);
    O1(k) = Ofun(tk);   O2(k) = Ofun(tk+dt/2);   O4(k) = Ofun(tk+dt);
end

xk = x0(:);
hasOnset = isfield(p, 'onset') && ~isempty(p.onset);
if hasOnset, tOn = p.onset.t;  pF = p.onset.p;  pN = rmfield(p, 'onset');  else, pN = p; end
pk = pN;
for k = 1:n-1
    tk    = t(k);
    V(k)  = V1(k);
    OC(k) = O1(k);
    if hasOnset && tk >= tOn - 1e-12, pk = pF; end
    k1 = dcm_derivatives(tk,      xk,           V1(k), pk, cfg, idx, O1(k));
    k2 = dcm_derivatives(tk+dt/2, xk + dt/2*k1, V2(k), pk, cfg, idx, O2(k));
    k3 = dcm_derivatives(tk+dt/2, xk + dt/2*k2, V2(k), pk, cfg, idx, O2(k));
    k4 = dcm_derivatives(tk+dt,   xk + dt  *k3, V4(k), pk, cfg, idx, O4(k));
    DX(k,:) = k1';
    xk = xk + dt/6*(k1 + 2*k2 + 2*k3 + k4);
    if O4(k)
        xk(idx.i) = 0;
    end
    X(k+1,:) = xk';
end
V(n)    = Vfun(t(n));
OC(n)   = Ofun(t(n));
DX(n,:) = dcm_derivatives(t(n), xk, V(n), pk, cfg, idx, OC(n))';

out.t    = t;
out.x    = X;
out.dx   = DX;
out.V    = V;
out.open = OC;
out.idx  = idx;
out.cfg  = cfg;
out.meta = struct('params',pN,'cfg',cfg,'profile',pname,'tEnd',tEnd, ...
                  'created',datestr(now,31));
if hasOnset, out.meta.onset = tOn; end
end
