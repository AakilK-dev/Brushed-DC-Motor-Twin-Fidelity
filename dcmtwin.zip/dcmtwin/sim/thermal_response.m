function out = thermal_response(p, ifun, wfun, tEnd, dt)

if nargin < 5 || isempty(dt), dt = 1.0; end
n = floor(tEnd/dt) + 1;
t = (0:n-1)'*dt;
th = zeros(n,1);

for k = 1:n-1
    f = @(tt,thth) ( p.R*(1 + p.alpha*thth)*ifun(tt)^2 ...
                   + p.kir*wfun(tt)^2 ...
                   - p.k0*(1 + p.kT*abs(wfun(tt)))*thth ) / p.H;
    k1 = f(t(k),      th(k));
    k2 = f(t(k)+dt/2, th(k) + dt/2*k1);
    k3 = f(t(k)+dt/2, th(k) + dt/2*k2);
    k4 = f(t(k)+dt,   th(k) + dt  *k3);
    th(k+1) = th(k) + dt/6*(k1 + 2*k2 + 2*k3 + k4);
end

out.t     = t;
out.theta = th;
out.meta  = struct('params',p,'dt',dt,'tEnd',tEnd);
end
