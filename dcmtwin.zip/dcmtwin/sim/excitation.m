function prof = excitation(kind, varargin)

o = struct(varargin{:});
never = @(t) false;

switch lower(kind)
    case 'step'
        o = defaults(o, 'V0', 24, 't0', 0);
        prof.V = @(t) o.V0*(t >= o.t0);
        prof.open = never;
    case 'lockedrotor'
        o = defaults(o, 'V0', 0.0486);
        prof.V = @(t) o.V0;
        prof.open = never;
    case 'coastdown'
        o = defaults(o, 'V0', 24, 'toff', 1.0);
        prof.V = @(t) o.V0*(t < o.toff);
        prof.open = @(t) t >= o.toff;
    case 'prbs'
        o = defaults(o, 'Vlo', 12, 'Vhi', 24, 'thold', 0.05, 'tEnd', 2.5, 'seed', 0);
        [tsw, lev] = binary_sequence(o.thold, o.tEnd, o.seed);
        vals = o.Vlo + (o.Vhi - o.Vlo)*lev;
        prof.V = @(t) lookup(t, tsw, vals);
        prof.open = never;
    case 'dither'
        o = defaults(o, 'V0', 24, 'amp', 0.02, 'thold', 0.02, 'tEnd', 2.5, 'seed', 0);
        [tsw, lev] = binary_sequence(o.thold, o.tEnd, o.seed);
        vals = o.V0*(1 + o.amp*(2*lev - 1));
        prof.V = @(t) lookup(t, tsw, vals);
        prof.open = never;
    case 'sine'
        o = defaults(o, 'V0', 12, 'A', 3, 'f', 1);
        prof.V = @(t) o.V0 + o.A*sin(2*pi*o.f*t);
        prof.open = never;
    otherwise
        error('excitation:kind','Unknown excitation "%s".', kind);
end
prof.name = kind;
prof.args = o;
end

function o = defaults(o, varargin)
for k = 1:2:numel(varargin)
    if ~isfield(o, varargin{k}), o.(varargin{k}) = varargin{k+1}; end
end
end

function [tsw, lev] = binary_sequence(thold, tEnd, seed)
s = RandStream('twister','Seed',seed);
tsw = 0;  lev = double(rand(s) > 0.5);
while tsw(end) < tEnd
    tsw(end+1) = tsw(end) + thold*(1 + floor(3*rand(s)));
    lev(end+1) = 1 - lev(end);
end
end

function v = lookup(t, tsw, val)
k = find(tsw <= t, 1, 'last');
if isempty(k), k = 1; end
v = val(k);
end
