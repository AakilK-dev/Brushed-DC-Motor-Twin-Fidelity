function S = sample_machines(p, n, seed)

u  = params_uncertainty();
k  = size(u.factors, 1);
rng(seed, 'twister');
U  = lhsdesign(n, k + 1);

F = zeros(n, k);
for j = 1:k
    dist = u.factors{j,2};
    cv   = u.factors{j,3};
    switch dist
        case 'normal'
            F(:,j) = norminv(U(:,j), 1, cv);
        case 'lognormal'
            sl = sqrt(log(1 + cv^2));
            F(:,j) = logninv(U(:,j), -sl^2/2, sl);
        otherwise
            error('sample_machines:dist','Unknown distribution "%s".', dist);
    end
end
theta = u.theta.lo + (u.theta.hi - u.theta.lo)*U(:,k+1);

for m = 1:n
    q = p;
    for j = 1:k
        moved = u.factors{j,4};
        for r = 1:numel(moved)
            q.(moved{r}) = p.(moved{r})*F(m,j);
        end
    end
    q.theta   = theta(m);
    q.machine = m;
    P(m) = q;
end

S.P     = P;
S.F     = F;
S.U     = U;
S.theta = theta;
S.names = [u.factors(:,1)' {'theta'}];
S.seed  = seed;
S.n     = n;
end
