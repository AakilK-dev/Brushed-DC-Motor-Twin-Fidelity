function q = make_bearing_noise(p, cfg, tEnd, seed)
n = floor(tEnd/cfg.dt) + 2;
s = RandStream('twister','Seed',seed);
q = p;
q.brg.xi   = randn(s, n, p.brg.Nb);
q.brg.seed = seed;
end
