function u = params_uncertainty()

% WU: W. Wu, "DC Motor Parameter Identification Using Speed Step Responses", Modelling and Simulation in Engineering, vol. 2012, 189757, 2012
u.factors = {
   'R'    'normal'     0.050  {'R'}                            'TRANSFERRED ASSUMPTION: WU spec of a small RK370CA motor, +/-15 percent as 3 sigma; sensitivity-tested'
   'phi'  'normal'     0.060  {'Ke','Kt'}                      'TRANSFERRED ASSUMPTION: WU spec of a small RK370CA motor, +/-18 percent as 3 sigma; sensitivity-tested'
   'L'    'normal'     0.100  {'L'}                            'ASSUMED'
   'J'    'normal'     0.050  {'J'}                            'ASSUMED'
   'fr'   'lognormal'  0.300  {'b_lin','b','Tc','Ts'}          'ASSUMED; lognormal as friction cannot be negative'
};

u.theta = struct('dist','uniform','lo',0,'hi',70, ...
                 'basis','cold start to the rated steady state rise');

% Sankardoss and Geethanjali, IEEE Access, vol. 5, pp. 11244-11254, 2017, Table III
u.cov_id = struct('R',0.0121,'L',0.0695,'Ke',0.0107,'Kt',0.0171, ...
                  'J',0.0153,'b',0.1147);
end
