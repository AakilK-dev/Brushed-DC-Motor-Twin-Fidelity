function p = params_default()
% Sources of the values. Each sourced value below carries its tag.
%   [SANKARDOSS]      V. Sankardoss and P. Geethanjali, "PMDC Motor Parameter Estimation Using
%                     Bio-Inspired Optimization Algorithms", IEEE Access, vol. 5, pp. 11244-11254,
%                     2017, doi: 10.1109/ACCESS.2017.2679743. Table III, experimental column.
%   [ABDULLAH]        M. N. Abdullah, M. K. Mat Desa, E. Abu Bakar and M. N. Akhtar, "Experimental
%                     and numerical studies for parameters identification of direct current motor",
%                     IJEECS, vol. 27, no. 2, pp. 592-600, 2022, doi: 10.11591/ijeecs.v27.i2.pp592-600.
%   [SYAKURO]         A. 'A. Syakuro, V. Virdyawan, S. Raharno, Indrawanto and T. Tjahjowidodo,
%                     "Parameter identification and continuous friction modelling of a brushed DC
%                     motor", IJEECS, vol. 42, no. 3, pp. 699-707, 2026,
%                     doi: 10.11591/ijeecs.v42.i3.pp699-707.
%   [BROWN]           P. Brown and J. McPhee, "A Continuous Velocity-Based Friction Model for
%                     Dynamics and Control With Physically Meaningful Parameters", ASME J. Comput.
%                     Nonlinear Dyn., vol. 11, no. 5, 054502, 2016, doi: 10.1115/1.4033658.
%   [MELLAH]          H. Mellah, K. E. Hemsas, R. Taleb and C. Cecati, "Estimation of speed, armature
%                     temperature, and resistance in brushed DC machines using a CFNN based on BFGS
%                     BP", Turk. J. Electr. Eng. Comput. Sci., vol. 26, no. 6, pp. 3182-3192, 2018,
%                     doi: 10.3906/elk-1711-330.
%   [BASTAMI]         A. Rohani Bastami and S. Vahid, "A comprehensive evaluation of the effect of
%                     defect size in rolling element bearings on the statistical features of the
%                     vibration signal", Mech. Syst. Signal Process., vol. 151, 107334, 2021.
%   [BEHZAD]          M. Behzad, A. R. Bastami and D. Mba, "A new model for estimating vibrations
%                     generated in the defective rolling element bearings", J. Vib. Acoust.,
%                     vol. 133, no. 4, 041011, 2011, doi: 10.1115/1.4003595.
%   [HARRIS]          T. A. Harris and M. N. Kotzalas, Essential Concepts of Bearing Technology
%                     (Rolling Bearing Analysis, 5th ed., vol. 1), CRC Press, 2006, ch. 7.
%   [SKF]             SKF, "1206 EM Self-aligning ball bearing", product page, skf.com.
%   [RETANA]          R. Retana, A. Paweletz and H.-G. Herzog, "Analysis and detection of short
%                     circuits in fractional horsepower commutator machines", IEEE Trans. Energy
%                     Convers., vol. 23, no. 2, pp. 484-491, 2008, doi: 10.1109/TEC.2008.918655.
%   [DUNKERMOTOREN]   Dunkermotoren GmbH, GR 80x40 and GR 80x80 data sheets.
%   [BARRY]           Barry Controls (Hutchinson), isolator selection guide, Table 1.
%   [PCB]             PCB Piezotronics, "Model 352C33 ICP Accelerometer", specification sheet, Rev. H.
%   [NI 9234]         National Instruments, "NI-9234 Specifications", 377849B-01, 2025.
%   [ALLEGRO]         Allegro MicroSystems, ACS712 datasheet ACS712-DS, Rev. 21, 2023.
%   [MCP3208]         Microchip Technology, MCP3204/3208 datasheet DS21298E, 2008.
%   [OMRON]           Omron Corporation, E6B2-C rotary encoder datasheet CSM_E6B2-C_DS_E_6_3, 2023.
%   [MAGTROL DS]      Magtrol, "HB/MHB Data Sheet: HB Hysteresis Brakes and MHB Matched Brakes",
%                     HB-US 11/06.
%   [MAGTROL MANUAL]  Magtrol, "Hysteresis Brakes and Clutches", user manual.
%   [MEAN WELL]       Mean Well, "LRS-350 series 350 W single output switching power supply",
%                     specification, 2015.


p.R      = 0.162;                            % [SANKARDOSS]
p.L      = 282e-6;                           % [SANKARDOSS]
p.Ke     = 0.0503;                           % [SANKARDOSS]
p.Kt     = p.Ke;

p.J      = 0.00046;                          % [SANKARDOSS]
p.b_lin  = 0.0001778;                        % [SANKARDOSS]

p.Vs     = 24;                               % [SANKARDOSS]
p.Irated = 16.5;
p.Prated = 320;                              % [SANKARDOSS]
p.nNL    = 4600;                             % [SANKARDOSS]

p.fr.Tc_ref = 0.024428;                      % fitted to [ABDULLAH], Table 4
p.fr.b_ref  = 7.27723e-5;                    % fitted to [ABDULLAH], Table 4
w_ref  = p.Kt*p.Vs/(p.R*p.b_lin + p.Kt*p.Ke);
frac   = p.fr.Tc_ref/(p.fr.Tc_ref + p.fr.b_ref*w_ref);
Ttot   = p.b_lin*w_ref;
p.Tc   = frac*Ttot;
p.b    = (1 - frac)*Ttot/w_ref;
p.w_ref = w_ref;
p.beta   = 214;                              % [SYAKURO]
p.wt     = 1/214;

p.Ts     = 1.3*p.Tc;
p.ws     = 2.0;
p.delta  = 2;                                % [BROWN]

p.N      = 1;
p.eta    = 1.00;

p.alpha  = 0.004;                            % [MELLAH]
p.kT     = 0.0028;                           % [MELLAH]
p.kir    = 0;
p.th.rise = 70;
p.th.tau  = 1200;
p.k0 = p.R*p.Irated^2*(1 + p.alpha*p.th.rise)/(p.th.rise*(1 + p.kT*w_ref));
p.H  = p.th.tau*(p.k0*(1 + p.kT*w_ref) - p.R*p.Irated^2*p.alpha);
p.theta  = 0;
p.Tamb   = 25;

p.TL     = 0;
p.TLfrac = 0.2;

p.brake.Tfs = 1.00;                          % [MAGTROL DS]
p.brake.J   = 1.00e-4;                       % [MAGTROL DS]
p.brake.reg = 0.01;                          % [MAGTROL MANUAL]
p.supply.tol = 0.01;                         % [MEAN WELL]
p.dTL = 0;
p.eVs = 0;

p.mr     = 0;
p.g      = 9.81;

p.modes.f    = [85 90 560 600 6100 6200];    % [BASTAMI]
p.modes.zeta = [0.05 0.4 0.2 0.2 0.08 0.08]; % mode 1 [BARRY], others [BASTAMI]
p.modes.m2   = 1;
p.modes.m3   = [1 5 6];
p.M          = 5.2;                          % derived from [DUNKERMOTOREN]
p.M_range    = [4.0 6.5];
p.Mhf        = 0.5;
p.mount.f1cov = 0.15;
p.mount.zeta  = [0.05 0.12];                 % [BARRY]
p.mount.Mfac  = [1.25 1.75];

p.brg.type  = '1206';                        % [BASTAMI]
p.brg.Nb    = 14;                            % [BASTAMI]
p.brg.BPFO  = 5.787;                         % [BASTAMI]
p.brg.BPFI  = 8.213;                         % [BASTAMI]
p.brg.BSF   = 2.760;                         % [BASTAMI]
p.brg.FTF   = 0.413;                         % [BASTAMI]
p.brg.Dp    = 0.046;                         % [SKF]
p.brg.dDp   = 0.174;
p.brg.eta_h = 1e8;                           % [BASTAMI]
p.brg.eta_d = 1e5;                           % [BASTAMI]
p.brg.cv    = 1.3;                           % derived from [BEHZAD]
p.brg.W     = 3.61;
p.brg.W_svc = 9.65;
p.brg.Qfac  = 4.37;                          % [HARRIS]
p.brg.D     = 0;
p.brg.loc   = 'outer';
p.brg.kf    = 1;
p.brg.vroll = 0.05;
p.brg.xi    = [];

p.nslots   = 12;                             % [RETANA]
p.nbars    = 24;
p.nbrush   = 2;
p.eps_c    = 0.018;                          % [ABDULLAH]
p.delta0   = 3.71812e-4;                     % calibrated to [RETANA]
p.delta_s  = p.delta0;
p.sc.range = [0.5 20];                       % [RETANA]
p.sc.growth= 15;                             % [RETANA]
p.sc.dK    = 0.03875;                        % calibrated to [RETANA]

p.acc.sens   = 0.100;                        % [PCB]
p.acc.range  = 50;                           % [PCB]
p.acc.fmin   = 0.5;                          % [PCB]
p.acc.fmax   = 10000;                        % [PCB]
p.acc.nd_sensor = 1.5e-6;                    % derived from [PCB]
p.acc.bits   = 24;                           % [NI 9234]
p.acc.vfs    = 5;                            % [NI 9234]
p.acc.fs     = 50e3;                         % [NI 9234]
p.acc.nd_daq = 3.10e-6;                      % [NI 9234]
p.acc.nd     = hypot(p.acc.nd_sensor, p.acc.nd_daq);

p.cur.sens   = 0.100;                        % [ALLEGRO]
p.cur.nd_sensor = 3.27e-4;                   % derived from [ALLEGRO]
p.cur.lin    = 2.0;                          % [ALLEGRO]
p.cur.bits   = 12;                           % [MCP3208]
p.cur.vfs    = 5.0;                          % [MCP3208]
p.cur.fs     = 10e3;

p.enc.ppr    = 1000;                         % [OMRON]
p.enc.quad   = 4;

p.vsense.div = 0.174;
p.vsense.bits= 12;                           % [MCP3208]
p.vsense.vfs = 5.0;                          % [MCP3208]
p.vsense.fs  = 10e3;

p.aa.order   = 8;
p.aa.frac    = 0.4;

p.adc.sinad = 72;                            % [MCP3208]
p.adc.vin   = (4.9 - 0.1)/2/sqrt(2);         % [MCP3208]
lsbA  = p.cur.vfs/2^p.cur.bits;
p.adc.rms   = sqrt((p.adc.vin/10^(p.adc.sinad/20))^2 - lsbA^2/12);
enbwA = p.aa.frac*p.cur.fs*(pi/(2*p.aa.order))/sin(pi/(2*p.aa.order));
p.cur.nd    = hypot(p.cur.nd_sensor, p.adc.rms/p.cur.sens/sqrt(enbwA));
p.vsense.nd = p.adc.rms/p.vsense.div/sqrt(enbwA);

p.cur_svc    = p.cur;
p.vsense_svc = p.vsense;
end
