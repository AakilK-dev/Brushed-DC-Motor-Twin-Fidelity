function v = physics_provenance(p)
v = p;
end
