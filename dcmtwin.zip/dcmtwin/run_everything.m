function run_everything(outdir, mode)

codever = code_version();
if nargin >= 2
    if ~(ischar(mode) || isstring(mode)) || ~strcmpi(char(mode), 'figures')
        error('run_everything:mode', 'The only mode is ''figures'': run_everything(outdir, ''figures'').');
    end
    redraw_figures(outdir, codever);
    return
end
marker = fullfile(outdir, 'BUILD_IN_PROGRESS.txt');
if exist(outdir, 'dir')
    d = dir(outdir);  d = d(~ismember({d.name}, {'.', '..'}));
    if ~isempty(d) && ~exist(marker, 'file')
        error('run_everything:notEmpty', ['%s already holds results that this run did not create.\n' ...
              'Give an empty or new folder.'], outdir);
    end
else
    mkdir(outdir);
end
if exist(marker, 'file')
    old = regexp(fileread(marker), 'version (\d+\.\d+\.\d+)', 'tokens', 'once');
    if isempty(old) || ~strcmp(old{1}, codever)
        error('run_everything:version', ['%s holds an unfinished run begun by another code version.\n' ...
              'Delete that folder, or give a new one, and start again.'], outdir);
    end
else
    fid = fopen(marker, 'w');  fprintf(fid, 'Run started %s with dcmtwin version %s\n', datestr(now), codever);  fclose(fid);
end
diary(fullfile(outdir, sprintf('build_log_%s.txt', datestr(now, 'yyyymmdd_HHMM'))));
c = onCleanup(@() diary('off'));
fprintf('dcmtwin version %s, every result into %s\n', codever, outdir);
t0 = tic;  stage = @(s) fprintf('\n==== %s   (%.1f h elapsed)\n', s, toc(t0)/3600);
fd = fullfile(outdir, 'figures');  if ~exist(fd, 'dir'), mkdir(fd); end

stage('1  verification');
if run_all_verifications() > 0, error('run_everything:verify', 'Verification failed: fix before running.'); end

stage('2  validation and calibrated constants');
validate_friction(fullfile(fd, 'validation'));
validate_bearing(fullfile(fd, 'validation'));
p = params_default();  cal = calibrate_commutation();
if abs(cal.delta0/p.delta0 - 1) > 1e-3 || abs(cal.dK/p.sc.dK - 1) > 1e-3
    error('run_everything:commutation', 'params_default is out of date: delta0 %.5e, dK %.5f (calibrate_commutation)', cal.delta0, cal.dK);
end

stage('3  ensemble');
run_ensemble(outdir);
export_ensemble(outdir);

stage('4  calibration');
calibrate_ensemble(outdir);

stage('5  adequacy');
adequacy_test(outdir);
adequacy_verdicts(outdir);

stage('6  plans');
make_sessions(outdir);
make_tuning_sessions(outdir);
allocate_reserve(outdir);
make_onset_sessions(outdir);

stage('7  datasets');
for m = [3 2 1], generate_dataset(outdir, m); check_dataset(outdir, m); end
generate_dataset(outdir, 3, [], 'tuning');

stage('8  Kalman filter');
ekf_tune(outdir);
for c2 = [1 1; 2 2; 3 1; 3 2]'
    ekf_find_failures(outdir, c2(1), c2(2));
    run_ekf_dataset(outdir, c2(1), c2(2));
    check_estimates(outdir, c2(1), c2(2));
end
for m = [1 2], ekf_matched_check(outdir, m); end

stage('9  analysis');
for m = 1:3, extract_features(outdir, m); end
run_grid(outdir);
feature_importance(outdir);
run_severity(outdir);
grid_intervals(outdir);
severity_intervals(outdir);
run_learning_mixed(outdir);
check_normal_spread(outdir);
shortcut_test(outdir);
make_figures(outdir);

stage('10 onset');
generate_dataset(outdir, 3, [], 'onset');
for tw = 1:2, run_ekf_dataset(outdir, 3, tw, 'onset'); end
run_onset(outdir);

stage('11 Appendix C and signal figures');
try, make_appendix_c_figures(fullfile(fd, 'appendix_c')); catch err, fprintf('skipped the Appendix C figures: %s\n', err.message); end
try, make_signal_figures(outdir); catch err, fprintf('skipped the signal figures: %s\n', err.message); end

stage('12 least squares');
for m = 1:3, run_lsq_dataset(outdir, m);  extract_features_lsq(outdir, m); end
run_grid_lsq(outdir);

stage('13 integrated diagnosis tool');
run_integrated(outdir);
try, plot_integrated(outdir); catch err, fprintf('skipped the integrated tool figures: %s\n', err.message); end

stage('14 hold-out test');
make_holdout_sessions(outdir);
generate_dataset(outdir, 3, [], 'holdout');
for tw = 1:2, run_ekf_dataset(outdir, 3, tw, 'holdout'); end
run_lsq_dataset(outdir, 3, 'holdout');
extract_holdout_features(outdir);
extract_features_lsq(outdir, 3, 'holdout');
run_holdout(outdir);
try, plot_holdout(outdir); catch err, fprintf('skipped the hold-out figure: %s\n', err.message); end

stage('15 sensitivity analysis');
run_sensitivity(outdir);
try, plot_sensitivity(outdir); catch err, fprintf('skipped the sensitivity figures: %s\n', err.message); end

delete(marker);
fid = fopen(fullfile(outdir, 'BUILD_COMPLETE.txt'), 'w');
fprintf(fid, 'Run completed %s, %.1f h, dcmtwin version %s\n', datestr(now), toc(t0)/3600, codever);  fclose(fid);
stage('done');
fprintf('Every result is in %s: tables (*.csv), results%s, figures%s, and this log.\n', outdir, filesep, filesep);
fprintf('Any figure that could not be drawn is reported in this log by a line beginning ''skipped''.\n');
end

function v = code_version()
txt = fileread(fullfile(fileparts(mfilename('fullpath')), 'README.md'));
t = regexp(txt, 'Version (\d+\.\d+\.\d+)', 'tokens', 'once');
if isempty(t), error('run_everything:noVersion', 'README.md has no version line.'); end
v = t{1};
end
