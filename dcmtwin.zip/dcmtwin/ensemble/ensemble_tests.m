function R = ensemble_tests(q, cfgRef, seedBase, opts)

if nargin < 4, opts = struct(); end
o = defaults(opts, 'Tstep',0.3, 'Tprbs',2.5, 'Tsteady',2.5, 'Tcoast',12.0, ...
                   'tA',0.5, 'duties',[0.4 0.6 0.8], 'coastDuties',[0.4 0.7 1.0], ...
                   'toff',0.3, 'dtCoast',1e-4, 'Vstep',1.0, ...
                   'prbsDuty',0.6, 'prbsAmp',0.025);
Vs  = q.Vs;
seed = @(k) seedBase + k;

R.machine = q.machine;
R.theta   = q.theta;
R.seed    = seedBase;
R.opts    = o;

cLR = cfgRef;  cLR.locked_rotor = true;  cLR.commutation = false;
cLR.bearing = false;  cLR.modes = [];
Vlr = 0.1*q.Irated*0.162;
out = run_sim(q, cLR, excitation('lockedrotor','V0',Vlr), 15*q.L/q.R);
R.lockedrotor = compact(virtual_sensors(out, q, seed(1), {'cur','vsup'}));
R.lockedrotor.V0 = Vlr;

qb  = make_bearing_noise(q, cfgRef, o.Tstep, seed(51));
out = run_sim(qb, cfgRef, excitation('step','V0',o.Vstep,'t0',0), o.Tstep);
R.step = compact(virtual_sensors(out, qb, seed(2), {'cur','vsup','enc'}));

R.coast = coast_tests(q, cfgRef, seedBase, o);

qb  = make_bearing_noise(q, cfgRef, o.Tprbs, seed(52));
V0  = o.prbsDuty*Vs;
pr  = excitation('prbs','Vlo',V0*(1-o.prbsAmp),'Vhi',V0*(1+o.prbsAmp), ...
                 'thold',0.05,'tEnd',o.Tprbs,'seed',3);
out = run_sim(qb, cfgRef, pr, o.Tprbs, steady_start(q, cfgRef, V0));
R.prbs = compact(virtual_sensors(out, qb, seed(3), {'cur','vsup','enc'}));

for k = 1:numel(o.duties)
    qb  = make_bearing_noise(q, cfgRef, o.Tsteady, seed(60+k));
    dz  = excitation('dither','V0',o.duties(k)*Vs,'amp',0.02,'thold',0.02, ...
                     'tEnd',o.Tsteady,'seed',40+k);
    out = run_sim(qb, cfgRef, dz, o.Tsteady, steady_start(q, cfgRef, o.duties(k)*Vs));
    c = compact(virtual_sensors(out, qb, seed(20+k), {'cur','vsup','enc','acc'}));
    c.duty = o.duties(k);
    R.steady(k) = c;
end

R.summary = summarise(R, o);
end

function coast = coast_tests(q, cfgRef, seedBase, o)
cCD = cfgRef;  cCD.commutation = false;  cCD.bearing = false;
cCD.modes = [];  cCD.dt = o.dtCoast;
for k = 1:numel(o.coastDuties)
    prof = excitation('coastdown','V0',o.coastDuties(k)*q.Vs,'toff',o.toff);
    out  = run_sim(q, cCD, prof, o.Tcoast);
    s    = virtual_sensors(out, q, seedBase + 10 + k, {'enc'});
    c.enc.fs = 1/(s.enc.t(2) - s.enc.t(1));
    c.enc.y  = single(s.enc.theta);
    c.duty   = o.coastDuties(k);
    c.toff   = o.toff;
    n   = round(0.1*c.enc.fs);  k0 = round(o.toff*c.enc.fs);
    th  = double(c.enc.y);
    w0  = (th(k0) - th(k0-n))/0.1;
    wE  = (th(end) - th(end-n))/0.1;
    c.stopped = wE < 0.01*max(w0, eps);
    coast(k) = c;
end
end

function x0 = steady_start(q, cfg, V)
idx = state_index(cfg);
R   = q.R;
if cfg.thermal, R = R*(1 + q.alpha*q.theta); end
w0  = (q.Kt*V/R - q.Tc)/(q.Kt*q.Ke/R + q.b);
x0  = zeros(idx.n,1);
x0(idx.i) = (V - q.Ke*w0)/R;
x0(idx.w) = w0;
end

function c = compact(s)
c = struct();
for f = {'cur','vsup','enc','acc'}
    if ~isfield(s, f{1}), continue; end
    ch = s.(f{1});
    c.(f{1}).fs = 1/(ch.t(2) - ch.t(1));
    switch f{1}
        case 'cur',  c.cur.y  = single(ch.i);
        case 'vsup', c.vsup.y = single(ch.v);
        case 'enc',  c.enc.y  = single(ch.theta);
        case 'acc',  c.acc.y  = single(ch.a);
    end
end
end

function v = summarise(R, o)
v = zeros(1,7);
for k = 1:3
    y = double(R.steady(k).cur.y);  n0 = round(o.tA*R.steady(k).cur.fs);
    v(k) = mean(y(n0:end));
end
m  = 2;  n0 = round(o.tA*R.steady(m).cur.fs);
th = double(R.steady(m).enc.y(n0:end));  ii = double(R.steady(m).cur.y(n0:end));
a = order_amplitude(ii, th, 24);
v(4) = a;
a0 = round(o.tA*R.steady(m).acc.fs);
aa = double(R.steady(m).acc.y(a0:end));  v(5) = sqrt(mean((aa - mean(aa)).^2));
c  = R.coast(end);  k0 = round(c.toff*c.enc.fs) + 1;
v(6) = double(c.enc.y(end)) - double(c.enc.y(k0));
v(7) = max(double(R.step.cur.y));
end

function o = defaults(o, varargin)
for k = 1:2:numel(varargin)
    if ~isfield(o, varargin{k}), o.(varargin{k}) = varargin{k+1}; end
end
end
