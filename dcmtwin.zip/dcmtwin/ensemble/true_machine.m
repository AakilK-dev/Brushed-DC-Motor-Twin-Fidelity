function q = true_machine(p, R)

u = params_uncertainty();  q = p;
for j = 1:size(u.factors,1)
    f = R.factors(strcmp(R.names, u.factors{j,1}));
    moved = u.factors{j,4};
    for r = 1:numel(moved), q.(moved{r}) = p.(moved{r})*f; end
end
q.machine = R.machine;
end
