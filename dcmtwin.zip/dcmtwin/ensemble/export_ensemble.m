function T = export_ensemble(outdir)

files = dir(fullfile(outdir, 'machine_*.mat'));
n = numel(files);
if n == 0, error('export_ensemble:empty','No machine files in %s.', outdir); end
fprintf('\nReading %d machine files ...\n', n);

rows = zeros(n, 16);
for k = 1:n
    L = load(fullfile(outdir, files(k).name), 'R');  R = L.R;
    stopped = all([R.coast.stopped]);
    rows(k,:) = [R.machine R.batch R.factors R.theta R.summary stopped];
end
rows = sortrows(rows, 1);

vars = {'machine','batch','f_R','f_phi','f_L','f_J','f_fr','theta_degC', ...
        'I40_A','I60_A','I80_A','ripple24_A','vibRMS_g','coastAngle_rad','peakI_A', ...
        'coast_all_stopped'};
T = array2table(rows, 'VariableNames', vars);
writetable(T, fullfile(outdir, 'ensemble_summary.csv'));

labels = {'I 40% (A)','I 60% (A)','I 80% (A)','ripple 24 (A)','vib RMS (g)', ...
          'coast angle (rad)','peak I (A)'};
bt = rows(:,2);  nb = max(bt);
H  = nan(nb, 2 + 14);  prevE = [];
P  = nan(nb, 2);
rsP = RandStream('twister','Seed',2);
for b = 1:nb
    Sb = rows(bt <= b, 9:15);
    e  = prctile(Sb, [2.5 97.5], 1);
    chg = NaN;
    if ~isempty(prevE)
        chg = max(max(abs(e - prevE)./abs(prevE)));
    end
    H(b,:) = [size(Sb,1) chg e(1,:) e(2,:)];
    prevE = e;
    nS = size(Sb,1);  B = zeros(1000, 14);
    for r = 1:1000
        eb = prctile(Sb(randi(rsP, nS, nS, 1), :), [2.5 97.5], 1);
        B(r,:) = [eb(1,:) eb(2,:)];
    end
    ci = prctile(B, [2.5 97.5], 1);
    hw = 100*(ci(2,:) - ci(1,:))/2./abs([e(1,:) e(2,:)]);
    P(b,:) = [max(hw) median(hw)];
end
short = {'I40','I60','I80','rip24','vib','coast','peakI'};
hv = [{'n_machines','largest_change'} strcat('p2.5_',short) strcat('p97.5_',short) ...
      {'worst_edge_precision_pct','median_edge_precision_pct'}];
writetable(array2table([H P], 'VariableNames', hv), fullfile(outdir, 'ensemble_history.csv'));

S = rows(:, 9:15);
band = prctile(S, [2.5 50 97.5], 1);

nb = 2000;  rs = RandStream('twister','Seed',1);
lo = zeros(nb,7);  hi = zeros(nb,7);
for k = 1:nb
    Sb = S(randi(rs, n, n, 1), :);
    e  = prctile(Sb, [2.5 97.5], 1);
    lo(k,:) = e(1,:);  hi(k,:) = e(2,:);
end
ciLo = prctile(lo, [2.5 97.5], 1);   ciHi = prctile(hi, [2.5 97.5], 1);
hwLo = 100*(ciLo(2,:) - ciLo(1,:))/2./abs(band(1,:));
hwHi = 100*(ciHi(2,:) - ciHi(1,:))/2./abs(band(3,:));

fprintf('\n%d machines.  Final 95 percent band, with bootstrap precision of each edge:\n\n', n);
fprintf('%-20s %12s %9s %12s %12s %9s\n', 'summary', '2.5th', '+/-', 'median', '97.5th', '+/-');
for j = 1:7
    fprintf('%-20s %12.5g %8.1f%% %12.5g %12.5g %8.1f%%\n', labels{j}, ...
            band(1,j), hwLo(j), band(2,j), band(3,j), hwHi(j));
end
B = table(labels(:), band(1,:)', ciLo(1,:)', ciLo(2,:)', band(2,:)', ...
          band(3,:)', ciHi(1,:)', ciHi(2,:)', ...
          'VariableNames', {'summary','p2_5','p2_5_ci_lo','p2_5_ci_hi','median', ...
                            'p97_5','p97_5_ci_lo','p97_5_ci_hi'});
writetable(B, fullfile(outdir, 'ensemble_band.csv'));
fprintf('\nLargest band edge change per batch: %s\n', mat2str(round(100*H(:,2)',2)));
fprintf('Worst band edge precision per batch: %s\n', mat2str(round(P(:,1)',1)));

nNot = sum(rows(:,16) == 0);
fprintf('\nMachines with a coast-down that did not reach rest: %d of %d\n', nNot, n);
if nNot > 0
    fprintf('  Their coast angles are truncated; lengthen Tcoast in ensemble_tests.\n');
end

try
    plot_ensemble(outdir);
catch err
    fprintf('skipped the ensemble figures: %s\n', err.message);
end
fprintf('\nWritten: ensemble_summary.csv, ensemble_history.csv, ensemble_band.csv,\n');
fprintf('         ensemble_convergence.svg and seven ensemble_hist_*.svg\n');
fprintf('in %s\n\n', outdir);
end
