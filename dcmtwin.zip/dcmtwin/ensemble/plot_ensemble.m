function plot_ensemble(outdir)

St = fig_style();
H = read_csv(fullfile(outdir, 'ensemble_history.csv'));
T = read_csv(fullfile(outdir, 'ensemble_summary.csv'));
B = read_csv(fullfile(outdir, 'ensemble_band.csv'));
cols  = {'I40_A', 'I60_A', 'I80_A', 'ripple24_A', 'vibRMS_g', 'coastAngle_rad', 'peakI_A'};
names = {'Current at 40% duty (A)', 'Current at 60% duty (A)', 'Current at 80% duty (A)', ...
         'Ripple amplitude, order 24 (A)', 'Vibration RMS (g)', 'Coast angle (rad)', 'Peak step current (A)'};
files = {'I40', 'I60', 'I80', 'ripple24', 'vibRMS', 'coastAngle', 'peakI'};

nM = H.n_machines(:);  P1 = H.worst_edge_precision_pct(:);  P2 = H.median_edge_precision_pct(:);
ref = P1(end)*sqrt(nM(end)./nM);
[fig, ax] = new_figure();
plot(ax, nM, P1, '-o', 'Color', St.black, 'MarkerFaceColor', St.black, 'LineWidth', St.line, 'MarkerSize', St.marker);
plot(ax, nM, P2, '--s', 'Color', St.dark, 'MarkerFaceColor', 'w', 'LineWidth', St.line, 'MarkerSize', St.marker);
plot(ax, nM, ref, ':', 'Color', St.black, 'LineWidth', St.ref);
style_axes(ax, 'Number of machines', 'Band edge precision (%)');
style_legend(legend(ax, {'Worst edge', 'Median edge', '1/\surd{n} reference'}, 'Location', 'northeast'));
save_figure(fig, fullfile(outdir, 'ensemble_convergence.svg'));  close(fig);

for j = 1:7
    x = T.(cols{j});  x = x(:);
    [fig, ax] = new_figure();
    [cnt, edg] = histcounts(x, 25);
    ctr = (edg(1:end-1) + edg(2:end))/2;
    bar(ax, ctr, cnt, 1, 'FaceColor', St.fill, 'EdgeColor', St.black, 'LineWidth', 0.8);
    xline(ax, B.p2_5(j), '--', 'Color', St.black, 'LineWidth', St.ref);
    xline(ax, B.p97_5(j), '--', 'Color', St.black, 'LineWidth', St.ref);
    style_axes(ax, names{j}, 'Machines');
    xlim(ax, [edg(1) - 0.5*(edg(2) - edg(1)), edg(end) + 0.5*(edg(2) - edg(1))]);
    ylim(ax, [0, 1.1*max(cnt)]);
    save_figure(fig, fullfile(outdir, ['ensemble_hist_' files{j} '.svg']));  close(fig);
end
fprintf('written: ensemble_convergence.svg and seven ensemble_hist_*.svg (%d machines; worst band-edge precision %.1f%% at the end)\n', ...
        numel(T.(cols{1})), P1(end));
end

function T = read_csv(f)
try
    T = readtable(f, 'VariableNamingRule', 'preserve');
catch
    T = readtable(f);
end
end
