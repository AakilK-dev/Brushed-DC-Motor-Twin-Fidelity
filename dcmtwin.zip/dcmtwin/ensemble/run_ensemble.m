function E = run_ensemble(outdir, varargin)

a    = struct(varargin{:});
nB   = getdef(a, 'nBatch',   50);
maxB = getdef(a, 'maxBatch', 10);
seed = getdef(a, 'seed',     2026);
tol  = getdef(a, 'tol',      0.01);
opts = getdef(a, 'opts',     struct());
usePar = getdef(a, 'parallel', true) && license('test','Distrib_Computing_Toolbox');
nW   = getdef(a, 'workers',  feature('numcores'));

if ~exist(outdir, 'dir'), mkdir(outdir); end
stale = dir(fullfile(outdir, 'tmp_machine_*.mat'));
for k = 1:numel(stale), delete(fullfile(outdir, stale(k).name)); end

p   = params_default();
cfg = cfg_model3();
prov = physics_provenance(p);
labels = {'I 40% (A)','I 60% (A)','I 80% (A)','ripple 24 (A)','vib RMS (g)','coast angle (rad)','peak I (A)'};

if usePar
    pool = gcp('nocreate');
    if isempty(pool) || pool.NumWorkers ~= nW
        delete(pool);
        pool = parpool('local', nW);
    end
    fprintf('Running in parallel on %d workers.\n\n', pool.NumWorkers);
    dq = parallel.pool.DataQueue;
    t0 = tic;
    afterEach(dq, @(id) fprintf('machine %4d done   elapsed %6.1f min\n', id, toc(t0)/60));
else
    fprintf('Running serially.\n\n');
    t0 = tic;
end

Ssum = [];  history = [];  below = 0;  prev = [];
for b = 1:maxB
    S     = sample_machines(p, nB, seed + b);
    P     = S.P;  F = S.F;  names = S.names;
    batch = zeros(nB, 7);
    ids   = (b-1)*nB + (1:nB);
    if usePar
        parfor m = 1:nB
            batch(m,:) = one_machine(P(m), F(m,:), names, b, ids(m), outdir, cfg, seed, opts, prov);
            send(dq, ids(m));
        end
    else
        for m = 1:nB
            batch(m,:) = one_machine(P(m), F(m,:), names, b, ids(m), outdir, cfg, seed, opts, prov);
            fprintf('machine %4d done   elapsed %6.1f min\n', ids(m), toc(t0)/60);
        end
    end
    Ssum = [Ssum; batch];

    band = prctile(Ssum, [2.5 50 97.5], 1);
    history(b).band = band;  history(b).n = size(Ssum,1);
    if ~isempty(prev)
        rel = abs(band([1 3],:) - prev([1 3],:))./abs(prev([1 3],:));
        chg = max(rel(:));
        history(b).change = chg;
        [~, worst] = max(max(rel, [], 1));
        fprintf('\nafter %d machines: largest band edge change %.2f %% (%s)\n\n', ...
                size(Ssum,1), 100*chg, labels{worst});
        if chg < tol, below = below + 1; else, below = 0; end
    end
    prev = band;
    save(fullfile(outdir, 'ensemble_index.mat'), 'Ssum', 'history', 'labels', 'seed', 'nB');
    if below >= 2
        fprintf('Converged: band edges moved less than %.1f %% on two consecutive batches.\n\n', 100*tol);
        break
    end
end
if below < 2
    fprintf('Stopped at maxBatch without meeting the convergence criterion.\n\n');
end

E.summaries = Ssum;
E.history   = history;
E.labels    = labels;
E.band      = prctile(Ssum, [2.5 50 97.5], 1);
E.converged = below >= 2;
E.n         = size(Ssum,1);
E.minutes   = toc(t0)/60;
end

function v = one_machine(q, f, names, b, id, outdir, cfg, seed, opts, prov)
file = fullfile(outdir, sprintf('machine_%04d.mat', id));
if exist(file, 'file')
    L = load(file, 'R');
    if isfield(L.R, 'provenance') && isequal(L.R.provenance, prov)
        v = L.R.summary;  return
    end
end
q.machine = id;
R = ensemble_tests(q, cfg, seed*1e5 + id*100, opts);
R.factors = f;  R.names = names;  R.batch = b;  R.provenance = prov;
tmp = fullfile(outdir, sprintf('tmp_machine_%04d.mat', id));
save(tmp, 'R', '-v7.3');
movefile(tmp, file);
v = R.summary;
end

function v = getdef(s, f, d)
if isfield(s, f), v = s.(f); else, v = d; end
end
