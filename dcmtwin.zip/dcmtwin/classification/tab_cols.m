function S = tab_cols(T)

if isstruct(T), S = T;
else, S = table2struct(T, 'ToScalar', true);
end
f = fieldnames(S);
for k = 1:numel(f)
    if isa(S.(f{k}), 'string') || isa(S.(f{k}), 'categorical'), S.(f{k}) = cellstr(S.(f{k})); end
end
end
