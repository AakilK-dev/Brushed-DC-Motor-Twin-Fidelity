function V = run_severity(outdir)

p = params_default();
FT = cell(1,3);
for d = 1:3, L = load(fullfile(outdir, 'features', sprintf('F_D%d.mat', d)), 'FT');  FT{d} = L.FT; end
nA = {'A_spv','A_cur','A_i1','A_i2','A_i24','A_vrms','A_kurt','A_crest','A_v1','A_env'};
nB = {'B_R','B_Ke','B_L','B_Tf','B_h2','B_nis','B_rmsi'};
S = load(fullfile(outdir, 'datasets', 'sessions.mat'), 'S');  sess = S.S.session;
rs = RandStream('mt19937ar', 'Seed', 20261004);  perm = sess(randperm(rs, numel(sess)));
foldOf = containers.Map('KeyType','double','ValueType','double');
for k = 1:numel(perm), foldOf(perm(k)) = mod(k-1, 5) + 1; end
cells = {'within 1->1',1,1,1; 'within 2->2',2,2,2; 'within 3->3',3,3,2; ...
         'forward 1->3',1,3,1; 'forward 2->3',2,3,2; 'reverse 3->1',3,1,1; 'reverse 3->2',3,2,2};
faults = ["resistive","shorted_bar","bearing_outer","imbalance"];
range  = [0.28, 0.9, 0.95, 2.0e-5];
V = struct('fault', {}, 'cell', {}, 'method', {}, 'mae', {}, 'maePct', {}, 'rho', {}, ...
           'biasPct', {}, 'pred', {}, 'truth', {}, 'session', {});
for fi = 1:numel(faults)
    fname = faults(fi);
    fprintf('\nSEVERITY, %s: mean absolute error as %% of range (Spearman rho)\n%-16s %22s %22s %22s\n', ...
            fname, 'cell', 'RF A', 'RF A+B', 'Physics');
    B = nan(size(cells,1), 3);
    for c = 1:size(cells,1)
        a = cells{c,2};  b = cells{c,3};  tw = cells{c,4};
        if fname == "imbalance" && (a == 1 || b == 1), continue; end
        [XAtr, XBtr, ytr, ftr]        = take(FT{a}, tw, nA, nB, fname, foldOf);
        [XAte, XBte, yte, fte, auxte, sste] = take(FT{b}, tw, nA, nB, fname, foldOf);
        pred = nan(numel(yte), 3);
        for k = 1:5
            itr = ftr ~= k;  ite = fte == k;
            pred(ite,1) = rfreg(XAtr(itr,:), ytr(itr), XAte(ite,:), k);
            pred(ite,2) = rfreg([XAtr(itr,:) XBtr(itr,:)], ytr(itr), [XAte(ite,:) XBte(ite,:)], k);
        end
        pred(:,3) = physics(fname, XAte, XBte, auxte, p, b);
        fprintf('%-16s', cells{c,1});
        for mth = 1:3
            e = abs(pred(:,mth) - yte);  mae = mean(e, 'omitnan');
            rho = corr(pred(:,mth), yte, 'Type', 'Spearman', 'Rows', 'complete');
            bias = mean(pred(:,mth) - yte, 'omitnan');  B(c,mth) = 100*bias/range(fi);
            fprintf('       %6.1f%% (%5.2f)', 100*mae/range(fi), rho);
            V(end+1) = struct('fault', fname, 'cell', cells{c,1}, 'method', mth, ...
                              'mae', mae, 'maePct', 100*mae/range(fi), 'rho', rho, ...
                              'biasPct', 100*bias/range(fi), 'pred', pred(:,mth), 'truth', yte, 'session', sste);
        end
        fprintf('\n');
    end
    fprintf('  signed bias, %% of range (negative = underestimate):\n');
    for c = 1:size(cells,1)
        if all(isnan(B(c,:))), continue; end
        fprintf('  %-16s %+21.1f%% %+21.1f%% %+21.1f%%\n', cells{c,1}, B(c,1), B(c,2), B(c,3));
    end
end
d = fullfile(outdir, 'results');  if ~exist(d, 'dir'), mkdir(d); end
save(fullfile(d, 'severity.mat'), 'V');
fprintf('\n');
end

function [A, B, y, fold, aux, sess] = take(FT, tw, nA, nB, fname, foldOf)
T = FT.A;  TB = FT.B.(sprintf('T%d', tw));
k = T.state == fname;
A = T{k, nA};  B = TB{k, nB};  A(~isfinite(A)) = 0;  B(~isfinite(B)) = 0;
y = T.severity(k);
fold = arrayfun(@(s) foldOf(s), T.session(k));
aux = [TB.X_w(k), TB.X_bbase(k)];
sess = T.session(k);
end

function yhat = rfreg(X, y, Xt, seed)
rng(seed, 'twister');
mdl  = TreeBagger(200, X, y, 'Method', 'regression');
yhat = predict(mdl, Xt);
end

function s = physics(fname, A, B, aux, p, dataModel)
w = aux(:,1);  bb = aux(:,2);
switch fname
    case "resistive",     s = B(:,1);
    case "shorted_bar",   s = -B(:,2)/p.sc.dK;
    case "bearing_outer", s = B(:,4)./(p.brg.kf*bb.*w);
    case "imbalance"
        a  = A(:,9)*9.81;
        wn = 2*pi*p.modes.f(1);  z = p.modes.zeta(1);
        s  = a.*p.M.*sqrt((wn^2 - w.^2).^2 + (2*z*wn*w).^2)./w.^4;
end
end
