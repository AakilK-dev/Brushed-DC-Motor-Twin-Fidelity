function G = run_grid(outdir)

FT = cell(1,3);
for d = 1:3
    L = load(fullfile(outdir, 'features', sprintf('F_D%d.mat', d)), 'FT');  FT{d} = L.FT;
end
nA = {'A_spv','A_cur','A_i1','A_i2','A_i24','A_vrms','A_kurt','A_crest','A_v1','A_env'};
nB = {'B_R','B_Ke','B_L','B_Tf','B_h2','B_nis','B_rmsi'};
all5 = ["normal","resistive","shorted_bar","bearing_outer","imbalance"];
S = load(fullfile(outdir, 'datasets', 'sessions.mat'), 'S');  sess = S.S.session;
rs = RandStream('mt19937ar', 'Seed', 20261004);
perm = sess(randperm(rs, numel(sess)));
foldOf = containers.Map('KeyType','double','ValueType','double');
for k = 1:numel(perm), foldOf(perm(k)) = mod(k-1, 5) + 1; end
cells = {'within 1->1',1,1,1,0; 'within 2->2',2,2,2,0; 'within 3->3',3,3,2,0; 'within 3->3 (Model 1 filter)',3,3,1,0; ...
         'forward 1->3',1,3,1,0; 'forward 2->3',2,3,2,0; 'reverse 3->1',3,1,1,0; 'reverse 3->2',3,2,2,0; ...
         'SHARED 4: within 2->2',2,2,2,1; 'SHARED 4: within 3->3',3,3,2,1; ...
         'SHARED 4: forward 2->3',2,3,2,1; 'SHARED 4: reverse 3->2',3,2,2,1};
methods = {'RF A','RF A+B','SVM A','SVM A+B','Rule'};
G = struct('cell', {}, 'method', {}, 'classes', {}, 'ytrue', {}, 'ypred', {}, 'sev', {}, 'session', {}, 'm', {});
t0 = tic;
for c = 1:size(cells,1)
    a = cells{c,2};  b = cells{c,3};  tw = cells{c,4};
    if a == 1 || b == 1 || cells{c,5}, cls = all5(1:4); else, cls = all5; end
    [Atr, Btr, ytr, ftr]       = take(FT{a}, tw, nA, nB, cls, foldOf);
    [Ate, Bte, yte, fte, sevte, sste] = take(FT{b}, tw, nA, nB, cls, foldOf);
    P = repmat(categorical(missing), numel(yte), numel(methods));
    for k = 1:5
        itr = ftr ~= k;  ite = fte == k;
        XA  = Atr(itr,:);  XAB = [Atr(itr,:), Btr(itr,:)];  y = ytr(itr);
        P(ite,1) = fitpred('rf',  XA,  y, Ate(ite,:),               k);
        P(ite,2) = fitpred('rf',  XAB, y, [Ate(ite,:), Bte(ite,:)], k);
        P(ite,3) = fitpred('svm', XA,  y, Ate(ite,:),               k);
        P(ite,4) = fitpred('svm', XAB, y, [Ate(ite,:), Bte(ite,:)], k);
        P(ite,5) = rules(Btr(itr & ytr == "normal", :), Bte(ite,:), cls);
    end
    for mth = 1:numel(methods)
        G(end+1) = struct('cell', cells{c,1}, 'method', methods{mth}, 'classes', cls, ...
            'ytrue', yte, 'ypred', P(:,mth), 'sev', sevte, 'session', sste, ...
            'm', scores(yte, P(:,mth), cls, sevte));
    end
    fprintf('%-30s done   %5.1f min\n', cells{c,1}, toc(t0)/60);
end
d = fullfile(outdir, 'results');  if ~exist(d, 'dir'), mkdir(d); end
save(fullfile(d, 'grid.mat'), 'G');
report(G, cells(:,1), methods);
end

function [A, B, y, fold, sev, sess] = take(FT, tw, nA, nB, cls, foldOf)
T  = FT.A;  TB = FT.B.(sprintf('T%d', tw));
k  = ismember(T.state, cls);
A  = clean(T{k, nA});  B = clean(TB{k, nB});
y  = categorical(T.state(k), cls);
fold = arrayfun(@(s) foldOf(s), T.session(k));
sev  = T.severity(k);
sess = T.session(k);
end

function X = clean(X)
bad = ~isfinite(X);
if any(bad(:)), warning('run_grid:nonfinite', '%d non-finite feature values set to 0', nnz(bad)); end
X(bad) = 0;
end

function yhat = fitpred(kind, X, y, Xt, seed)
rng(seed, 'twister');
switch kind
    case 'rf'
        mdl  = TreeBagger(200, X, y, 'Method', 'classification');
        yhat = categorical(predict(mdl, Xt), categories(y));
    case 'svm'
        t    = templateSVM('KernelFunction', 'rbf', 'KernelScale', 'auto', 'Standardize', true);
        mdl  = fitcecoc(X, y, 'Learners', t);
        yhat = categorical(cellstr(predict(mdl, Xt)), categories(y));
end
end

function yhat = rules(Bn, B, cls)
thr  = prctile(abs(Bn), 99, 1);
lab  = repmat("normal", size(B,1), 1);
lab(B(:,4) >  thr(4)) = "bearing_outer";
lab(B(:,1) >  thr(1)) = "resistive";
lab(B(:,2) < -thr(2)) = "shorted_bar";
yhat = categorical(lab, cls);
end

function m = scores(y, yhat, cls, sev)
C = zeros(numel(cls));
for i = 1:numel(cls), for j = 1:numel(cls), C(i,j) = sum(y == cls(i) & yhat == cls(j)); end, end
rec = diag(C)./max(sum(C,2), 1);  pre = diag(C)./max(sum(C,1)', 1);
f1  = 2*rec.*pre./max(rec + pre, eps);
m.acc = mean(y == yhat);  m.macroF1 = mean(f1);  m.recall = rec';  m.C = C;
m.bySev = nan(numel(cls), 3);
for i = 2:numel(cls)
    k = y == cls(i);  s = sev(k);  ok = yhat(k) == cls(i);
    e = quantile(s, [0 1/3 2/3 1]);
    for b3 = 1:3, in = s >= e(b3) & s <= e(b3+1); m.bySev(i,b3) = mean(ok(in)); end
end
end

function report(G, cellNames, methods)
fprintf('\nACCURACY (macro F1 in brackets)\n%-30s', 'cell');
fprintf('%17s', methods{:});  fprintf('\n');
for c = 1:numel(cellNames)
    fprintf('%-30s', cellNames{c});
    for mth = 1:numel(methods)
        g = G(strcmp({G.cell}, cellNames{c}) & strcmp({G.method}, methods{mth}));
        fprintf('   %5.1f%% (%5.3f)', 100*g.m.acc, g.m.macroF1);
    end
    fprintf('\n');
end
fprintf('\nRECALL OF EACH FAULT AT ITS SMALLEST SEVERITY THIRD (RF A / RF A+B / Rule)\n%-30s', 'cell');
fprintf('%22s', 'resistive', 'shorted_bar', 'bearing_outer', 'imbalance');  fprintf('\n');
for c = 1:numel(cellNames)
    fprintf('%-30s', cellNames{c});
    gA = G(strcmp({G.cell}, cellNames{c}) & strcmp({G.method}, 'RF A'));
    gB = G(strcmp({G.cell}, cellNames{c}) & strcmp({G.method}, 'RF A+B'));
    gR = G(strcmp({G.cell}, cellNames{c}) & strcmp({G.method}, 'Rule'));
    for i = 2:5
        if i > numel(gA.classes), fprintf('%22s', '(not in cell)'); continue; end
        fprintf('       %4.0f/%4.0f/%4.0f%%', 100*gA.m.bySev(i,1), 100*gB.m.bySev(i,1), 100*gR.m.bySev(i,1));
    end
    fprintf('\n');
end
for nm = {'forward 2->3', 'forward 1->3', 'reverse 3->2'}
    for mth = {'RF A', 'RF A+B'}
        g = G(strcmp({G.cell}, nm{1}) & strcmp({G.method}, mth{1}));
        fprintf('\nConfusion, %s, %s (rows true, columns predicted)\n%-15s', nm{1}, mth{1}, '');
        fprintf('%15s', g.classes);  fprintf('\n');
        for i = 1:numel(g.classes)
            fprintf('%-15s', g.classes(i));  fprintf('%15d', g.m.C(i,:));  fprintf('\n');
        end
    end
end
fprintf('\n');
end
