function L = learning_core(D, foldVec, cellsL, sizes, nRep, fitter, W, sAll)
L = struct('cell', {}, 'cols', {}, 'size', {}, 'acc', {}, 'lo', {}, 'hi', {}, 'bootAcc', {}, 'low', {});
for c = 1:size(cellsL, 1)
    Dtr = D.(cellsL{c,2});  Dte = D.(cellsL{c,3});  cols = cellsL{c,4};
    for si = 1:numel(sizes)
        n = sizes(si);  y = [];  p = [];  sv = [];  ss = [];
        reps = nRep;  if n >= 120, reps = 1; end
        for r = 1:reps
            pick = @(k, pool) choose(Dtr, pool, n, seed_of(c, si, r, k));
            o = train_test_core(Dtr, Dte, foldVec, pick, fitter, cols, cellsL{c,1});
            y = [y; o.y];  p = [p; o.p];  sv = [sv; o.sev];  ss = [ss; o.sess];
        end
        K = boot_counts(y, p, sv, ss, Dte.nC);  [~, rows] = ismember(K.s, sAll);
        F = boot_scores(K, ones(numel(K.s), 1));  B = boot_scores(K, W(rows,:));
        q = quantile(B.acc, [0.025 0.975]);
        L(end+1) = struct('cell', cellsL{c,1}, 'cols', cols, 'size', n, 'acc', F.acc, 'lo', q(1), 'hi', q(2), ...
                          'bootAcc', B.acc, 'low', F.bySev(:,1)');
    end
end
fprintf('\nLEARNING CURVES: accuracy (%%) against training sessions, 95%% interval; grid folds\n%-34s', 'cell, features');
fprintf('%19d', sizes);  fprintf('   rise %d to %d\n', sizes(end-1), sizes(end));
for c = 1:size(cellsL, 1)
    k = find(strcmp({L.cell}, cellsL{c,1}) & strcmp({L.cols}, cellsL{c,4}));
    fprintf('%-34s', [cellsL{c,1} ', ' strrep(cellsL{c,4}, 'AB', 'A+B')]);
    for j = k, fprintf('  %5.1f [%4.1f,%5.1f]', 100*L(j).acc, 100*L(j).lo, 100*L(j).hi); end
    d = 100*(L(k(end)).bootAcc - L(k(end-1)).bootAcc);  qd = quantile(d, [0.025 0.975]);
    v = 'flat';  if qd(1) > 0, v = 'still rising'; elseif qd(2) < 0, v = 'falling'; end
    fprintf('   %+5.1f [%+5.1f,%+5.1f] %s\n', 100*(L(k(end)).acc - L(k(end-1)).acc), qd(1), qd(2), v);
end
end

function sel = choose(Dtr, pool, n, seed)
if n >= numel(pool), use = pool; else, ix = seeded_perm(numel(pool), seed);  use = pool(ix(1:n)); end
rows = ismember(Dtr.sess, use);
sel = struct('rows', rows, 'w', ones(nnz(rows), 1));
end

function s = seed_of(c, si, r, k)
s = 20261008 + 100000*c + 1000*si + 10*r + k;
end
