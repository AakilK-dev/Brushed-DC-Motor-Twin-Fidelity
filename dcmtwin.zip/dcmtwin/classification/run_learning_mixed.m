function [L, M] = run_learning_mixed(outdir)

for d = 1:3
    Lf = load(fullfile(outdir, 'features', sprintf('F_D%d.mat', d)), 'FT');  FT{d} = Lf.FT;
end
nA = {'A_spv','A_cur','A_i1','A_i2','A_i24','A_vrms','A_kurt','A_crest','A_v1','A_env'};
nB = {'B_R','B_Ke','B_L','B_Tf','B_h2','B_nis','B_rmsi'};
all5 = ["normal","resistive","shorted_bar","bearing_outer","imbalance"];  all4 = all5(1:4);
S = load(fullfile(outdir, 'datasets', 'sessions.mat'), 'S');  sess = S.S.session;
rs = RandStream('mt19937ar', 'Seed', 20261004);
perm = sess(randperm(rs, numel(sess)));
foldVec = zeros(max(sess), 1);
for k = 1:numel(perm), foldVec(perm(k)) = mod(k-1, 5) + 1; end

D = struct();
D.M3_T2_5 = as_arrays(FT{3}, 2, nA, nB, all5);  D.M2_T2_5 = as_arrays(FT{2}, 2, nA, nB, all5);
D.M3_T2_4 = as_arrays(FT{3}, 2, nA, nB, all4);  D.M2_T2_4 = as_arrays(FT{2}, 2, nA, nB, all4);
D.M3_T1_4 = as_arrays(FT{3}, 1, nA, nB, all4);  D.M1_T1_4 = as_arrays(FT{1}, 1, nA, nB, all4);

sAll = unique(sess(:));  nS = numel(sAll);  nBoot = 2000;
rb = RandStream('mt19937ar', 'Seed', 20261009);  W = zeros(nS, nBoot);
for b = 1:nBoot, W(:,b) = accumarray(randi(rb, nS, nS, 1), 1, [nS 1]); end
fitter = @rf_fit;  t0 = tic;

cellsL = {'within 3->3', 'M3_T2_5', 'M3_T2_5', 'A';   'within 3->3', 'M3_T2_5', 'M3_T2_5', 'AB';
          'within 2->2', 'M2_T2_5', 'M2_T2_5', 'AB';  'within 1->1', 'M1_T1_4', 'M1_T1_4', 'AB';
          'forward 2->3', 'M2_T2_5', 'M3_T2_5', 'AB'; 'SHARED 4: forward 2->3', 'M2_T2_4', 'M3_T2_4', 'AB';
          'forward 1->3', 'M1_T1_4', 'M3_T1_4', 'AB'};
L = learning_core(D, foldVec, cellsL, [20 40 60 90 120], 3, fitter, W, sAll);
fprintf('learning curves done   %5.1f min\n', toc(t0)/60);

mixDef = {'Model 2, five classes', 'M2_T2_5', 'M3_T2_5';
          'Model 2, shared four',  'M2_T2_4', 'M3_T2_4';
          'Model 1, shared four',  'M1_T1_4', 'M3_T1_4'};
M = mixed_core(D, foldVec, mixDef, [0 2 5 10 20 40], 3, fitter, W, sAll);
fprintf('mixed training done    %5.1f min\n', toc(t0)/60);

d = fullfile(outdir, 'results');  if ~exist(d, 'dir'), mkdir(d); end
save(fullfile(d, 'learning_mixed.mat'), 'L', 'M', 'nBoot');
try, plot_learning_mixed(outdir); catch err, fprintf('skipped the learning-curve figures: %s\n', err.message); end
end

function Dx = as_arrays(FT, tw, nA, nB, cls)
T = FT.A;  TB = FT.B.(sprintf('T%d', tw));  k = ismember(T.state, cls);
A = T{k, nA};  B = TB{k, nB};  A(~isfinite(A)) = 0;  B(~isfinite(B)) = 0;
[~, y] = ismember(cellstr(T.state(k)), cellstr(cls));
Dx = struct('A', A, 'B', B, 'y', y(:), 'sev', T.severity(k), 'sess', T.session(k), 'nC', numel(cls));
end

function p = rf_fit(X, y, w, Xt, seed)
persistent warned
rng(seed, 'twister');
opts = statset('UseParallel', ~isempty(gcp('nocreate')), 'UseSubstreams', true, ...
               'Streams', RandStream('mlfg6331_64', 'Seed', seed));
if all(w == 1)
    mdl = TreeBagger(200, X, y, 'Method', 'classification', 'Options', opts);
    p = str2double(predict(mdl, Xt));  return
end
try
    mdl = TreeBagger(200, X, y, 'Method', 'classification', 'Weights', w, 'Options', opts);
    p = str2double(predict(mdl, Xt));
catch
    if isempty(warned), warning('run_learning_mixed:weights', 'TreeBagger rejected weights: using a bagged ensemble of 200 trees instead'); warned = true; end
    mdl = fitcensemble(X, y, 'Method', 'Bag', 'NumLearningCycles', 200, 'Weights', w);
    p = predict(mdl, Xt);
end
end
