function S = severity_intervals(outdir, nBoot)

if nargin < 2 || isempty(nBoot), nBoot = 2000; end
L = load(fullfile(outdir, 'results', 'severity.mat'), 'V');  V = L.V;
if ~isfield(V, 'session')
    error('severity_intervals:noSession', 'severity.mat has no sessions: rerun run_severity (1.0.37 or later) first.');
end
sAll = unique(vertcat(V.session));  nS = numel(sAll);
W = zeros(nS, nBoot);  draw = resampler(20261007);
for b = 1:nBoot, W(:,b) = accumarray(draw(nS), 1, [nS 1]); end
mNames = {'RF A', 'RF A+B', 'Physics'};
S = struct('fault', {}, 'cell', {}, 'method', {}, 'full', {}, 'boot', {});
for i = 1:numel(V)
    rangeF = V(i).mae/max(V(i).maePct, eps)*100;
    e = V(i).pred(:) - V(i).truth(:);  ok = isfinite(e);
    [~, si] = ismember(V(i).session(:), sAll);
    full = stats_of(e(ok), V(i).pred(ok), V(i).truth(ok), ones(nnz(ok),1), rangeF);
    bt = struct('mae', zeros(1,nBoot), 'bias', zeros(1,nBoot), 'rho', zeros(1,nBoot));
    for b = 1:nBoot
        w = W(si(ok), b);  t = stats_of(e(ok), V(i).pred(ok), V(i).truth(ok), w, rangeF);
        bt.mae(b) = t.mae;  bt.bias(b) = t.bias;  bt.rho(b) = t.rho;
    end
    S(i) = struct('fault', char(V(i).fault), 'cell', V(i).cell, 'method', mNames{V(i).method}, 'full', full, 'boot', bt);
end

faults = unique({S.fault}, 'stable');
for f = 1:numel(faults)
    fprintf('\nSEVERITY, %s: mean absolute error, %% of range [95%% interval]; rank correlation [interval]\n', faults{f});
    k = find(strcmp({S.fault}, faults{f}));  cells = unique({S(k).cell}, 'stable');
    fprintf('%-16s', 'cell');  fprintf('%34s', mNames{:});  fprintf('\n');
    for c = 1:numel(cells)
        fprintf('%-16s', cells{c});
        for m = 1:3
            r = k(strcmp({S(k).cell}, cells{c}) & strcmp({S(k).method}, mNames{m}));
            qa = quantile(S(r).boot.mae, [0.025 0.975]);  qr = quantile(S(r).boot.rho, [0.025 0.975]);
            fprintf('  %5.1f [%4.1f,%5.1f] %4.2f [%4.2f,%4.2f]', S(r).full.mae, qa(1), qa(2), S(r).full.rho, qr(1), qr(2));
        end
        fprintf('\n');
    end
end

P = {'Imbalance: physics bias, within reference',                        'imbalance','within 3->3','Physics', '','', 'bias';
     'Imbalance: physics minus learned (A+B) error, within reference',   'imbalance','within 3->3','Physics', 'within 3->3','RF A+B', 'mae';
     'Imbalance: physics minus learned (A+B) rank correlation',          'imbalance','within 3->3','Physics', 'within 3->3','RF A+B', 'rho';
     'Bearing: Model 1 physics bias, forward to reference',              'bearing_outer','forward 1->3','Physics', '','', 'bias';
     'Bearing: learned (A+B) minus physics error, within reference',     'bearing_outer','within 3->3','RF A+B', 'within 3->3','Physics', 'mae';
     'Resistive: learned (A+B) minus physics error, within reference',   'resistive','within 3->3','RF A+B', 'within 3->3','Physics', 'mae';
     'Resistive: Set B lowers the learned error, within reference',      'resistive','within 3->3','RF A+B', 'within 3->3','RF A', 'mae';
     'Shorted bar: learned (A+B) bias, reverse to Model 1',              'shorted_bar','reverse 3->1','RF A+B', '','', 'bias'};
fprintf('\nPAIRED COMPARISONS (A minus B, or A alone; 95%% interval)\n');
cmp = struct('label', {}, 'value', {}, 'lo', {}, 'hi', {}, 'differs', {});
for j = 1:size(P,1)
    a = pickS(S, P{j,2}, P{j,3}, P{j,4});  fld = P{j,7};
    v = a.full.(fld);  bv = a.boot.(fld);
    if ~isempty(P{j,5}), o = pickS(S, P{j,2}, P{j,5}, P{j,6});  v = v - o.full.(fld);  bv = bv - o.boot.(fld); end
    q = quantile(bv, [0.025 0.975]);  dif = q(1) > 0 || q(2) < 0;
    fprintf('%-66s %+7.2f [%+7.2f, %+7.2f]  %s\n', P{j,1}, v, q(1), q(2), ifelse(dif, 'differs from zero', 'not distinguishable from zero'));
    cmp(j) = struct('label', P{j,1}, 'value', v, 'lo', q(1), 'hi', q(2), 'differs', dif);
end
fprintf('(errors and biases in percent of range; correlations as differences of rho)\n');
save(fullfile(outdir, 'results', 'severity_intervals.mat'), 'S', 'cmp', 'nBoot');
fprintf('\nSaved results/severity_intervals.mat\n\n');
end

function t = stats_of(e, pred, truth, w, rangeF)
w = w(:);  sw = sum(w);
t.mae  = 100*sum(w.*abs(e))/sw/rangeF;
t.bias = 100*sum(w.*e)/sw/rangeF;
keep = w > 0;  rep = repelem_(find(keep), w(keep));
t.rho = pearson(ranks(pred(rep)), ranks(truth(rep)));
end

function r = ranks(x)
x = x(:);  [xs, i] = sort(x);  n = numel(x);  r = zeros(n,1);  k = 1;
while k <= n
    j = k;  while j < n && xs(j+1) == xs(k), j = j + 1; end
    r(i(k:j)) = (k + j)/2;  k = j + 1;
end
end

function c = pearson(a, b)
a = a - mean(a);  b = b - mean(b);  c = sum(a.*b)/sqrt(sum(a.^2)*sum(b.^2));
end

function v = repelem_(idx, cnt)
v = zeros(sum(cnt), 1);  p = 0;
for k = 1:numel(idx), v(p+1:p+cnt(k)) = idx(k);  p = p + cnt(k); end
end

function s = pickS(S, fault, cellName, method)
r = find(strcmp({S.fault}, fault) & strcmp({S.cell}, cellName) & strcmp({S.method}, method));
if isempty(r), error('severity_intervals:missing', 'no result for %s, %s, %s', fault, cellName, method); end
s = S(r);
end

function f = resampler(seed)
if exist('RandStream', 'class') == 8 || exist('RandStream', 'file') == 2
    rs = RandStream('mt19937ar', 'Seed', seed);  f = @(n) randi(rs, n, n, 1);
else
    rand('seed', seed);  f = @(n) randi(n, n, 1);
end
end

function v = ifelse(c, a, b)
if c, v = a; else, v = b; end
end
