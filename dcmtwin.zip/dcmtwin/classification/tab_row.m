function r = tab_row(T, k)

S = tab_cols(T);  f = fieldnames(S);  r = struct();
for j = 1:numel(f)
    c = S.(f{j});
    if iscell(c), r.(f{j}) = c{k}; else, r.(f{j}) = c(k,:); end
end
end
