function K = boot_counts(yc, pc, sev, sess, nCls)
s = unique(sess(:));  nS = numel(s);
C = zeros(nCls, nCls, nS);  T = zeros(nCls, 3, 2, nS);
third = zeros(size(yc));
for i = 2:nCls
    k = yc == i;  if ~any(k), continue; end
    e = quantile(sev(k), [0 1/3 2/3 1]);
    t = ones(nnz(k), 1);  v = sev(k);
    t(v > e(2)) = 2;  t(v > e(3)) = 3;
    third(k) = t;
end
[~, si] = ismember(sess(:), s);
for r = 1:numel(yc)
    p = pc(r);
    if ~isnan(p), C(yc(r), p, si(r)) = C(yc(r), p, si(r)) + 1; end
    if yc(r) > 1
        T(yc(r), third(r), 1, si(r)) = T(yc(r), third(r), 1, si(r)) + 1;
        T(yc(r), third(r), 2, si(r)) = T(yc(r), third(r), 2, si(r)) + (p == yc(r));
    end
end
K = struct('s', s, 'C', C, 'T', T, 'nRun', accumarray(si, 1, [nS 1]));
end
