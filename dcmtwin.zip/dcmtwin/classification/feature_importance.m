function feature_importance(outdir)

nA = {'A_spv','A_cur','A_i1','A_i2','A_i24','A_vrms','A_kurt','A_crest','A_v1','A_env'};
nB = {'B_R','B_Ke','B_L','B_Tf','B_h2','B_nis','B_rmsi'};
names = [nA nB];
for d = [2 3]
    L = load(fullfile(outdir, 'features', sprintf('F_D%d.mat', d)), 'FT');  FT = L.FT;
    X = [FT.A{:, nA}, FT.B.T2{:, nB}];  X(~isfinite(X)) = 0;
    for target = ["imbalance", "bearing_outer"]
        y = categorical(FT.A.state == target, [false true], {'rest', char(target)});
        rng(1, 'twister');
        mdl = TreeBagger(300, X, y, 'Method', 'classification', 'OOBPredictorImportance', 'on');
        imp = mdl.OOBPermutedPredictorDeltaError;
        [v, k] = sort(imp, 'descend');
        fprintf('\nModel %d data, %s against the rest: top features by permutation importance\n', d, target);
        for r = 1:6, fprintf('  %d. %-8s %7.3f\n', r, names{k(r)}, v(r)); end
    end
end
fprintf('\n');
end
