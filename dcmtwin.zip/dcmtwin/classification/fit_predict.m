function yhat = fit_predict(kind, X, y, Xt, seed)

rng(seed, 'twister');
switch kind
    case 'rf'
        mdl  = TreeBagger(200, X, y(:), 'Method', 'classification');
        yhat = str2double(predict(mdl, Xt));
    case 'svm'
        t    = templateSVM('KernelFunction', 'rbf', 'KernelScale', 'auto', 'Standardize', true);
        mdl  = fitcecoc(X, y(:), 'Learners', t);
        yhat = double(predict(mdl, Xt));
    case 'rfreg'
        mdl  = TreeBagger(200, X, y(:), 'Method', 'regression');
        yhat = predict(mdl, Xt);
    otherwise
        error('fit_predict:kind', 'unknown kind "%s"', kind);
end
yhat = yhat(:);
end
