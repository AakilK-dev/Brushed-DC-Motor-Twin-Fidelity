function shortcut_test(outdir)
for d = [1 2 3]
    Lf = load(fullfile(outdir, 'features', sprintf('F_D%d.mat', d)), 'FT');  FT{d} = Lf.FT;
end
nA = {'A_spv','A_cur','A_i1','A_i2','A_i24','A_vrms','A_kurt','A_crest','A_v1','A_env'};
nB = {'B_R','B_Ke','B_L','B_Tf','B_h2','B_nis','B_rmsi'};
all5 = ["normal","resistive","shorted_bar","bearing_outer","imbalance"];  all4 = all5(1:4);
S = load(fullfile(outdir, 'datasets', 'sessions.mat'), 'S');  sess = S.S.session;
rs = RandStream('mt19937ar', 'Seed', 20261004);  perm = sess(randperm(rs, numel(sess)));
foldVec = zeros(max(sess), 1);  for k = 1:numel(perm), foldVec(perm(k)) = mod(k-1, 5) + 1; end
sAll = unique(sess(:));  nS = numel(sAll);  rb = RandStream('mt19937ar', 'Seed', 20261009);
W = zeros(nS, 2000);  for b = 1:2000, W(:,b) = accumarray(randi(rb, nS, nS, 1), 1, [nS 1]); end
mixes = {'Model 2, shared four', 2, 2, all4;  'Model 1, shared four', 1, 1, all4;  'Model 2, five classes', 2, 2, all5};
fprintf('\nSHORTCUT TEST: twin plus real NORMAL runs (weighted) against the pure twin, on unseen reference machines\n');
for m = 1:size(mixes, 1)
    Dtw = arrays(FT{mixes{m,2}}, mixes{m,3}, nA, nB, mixes{m,4});  Dre = arrays(FT{3}, mixes{m,3}, nA, nB, mixes{m,4});
    Dc = struct('A', [Dtw.A; Dre.A], 'B', [Dtw.B; Dre.B], 'y', [Dtw.y; Dre.y], 'sev', [Dtw.sev; Dre.sev], ...
                'sess', [Dtw.sess; Dre.sess], 'src', [ones(numel(Dtw.y),1); 2*ones(numel(Dre.y),1)]);
    fprintf('\n%s\n', mixes{m,1});
    for fs = {'AB', 'ABnv'}
        lab = 'Set A+B';  if strcmp(fs{1}, 'ABnv'), lab = 'Set A+B, no vibration'; end
        fprintf('  %s\n', lab);
        R = struct();  cfgs = {'pure', 'x1', 'x2', 'xW'};
        names = {'pure twin', 'plus real normal, normal weight kept (x1)', 'plus real normal, unweighted', 'plus real normal, weighted to the twin'};
        for c = 1:numel(cfgs)
            pick = @(f, pool) choose(Dc, pool, cfgs{c});
            o = train_test_core(Dc, Dre, foldVec, pick, @rf_fit, fs{1}, [mixes{m,1} ', ' cfgs{c}]);
            K = boot_counts(o.y, o.p, o.sev, o.sess, Dre.nC);  [~, rows] = ismember(K.s, sAll);
            sel = choose(Dc, unique(Dc.sess), cfgs{c});
            nw = sum(sel.w(Dc.y(sel.rows) == 1))/nnz(Dc.y(sel.rows) == 1 & Dc.src(sel.rows) == 1);
            R.(cfgs{c}) = struct('F', boot_scores(K, ones(numel(K.s),1)), 'B', boot_scores(K, W(rows,:)), 'o', o, 'nw', nw);
            kb = o.y == 4;  r = R.(cfgs{c});
            if c == 1
                fprintf('    %-44s %5.1f%%                          normal weight %3.1f x   bearing called normal %4.1f%%\n', ...
                        names{c}, 100*r.F.acc, r.nw, 100*mean(o.p(kb) == 1));
            else
                d = 100*(r.B.acc - R.pure.B.acc);  q = quantile(d, [0.025 0.975]);
                v = '  ';  if q(1) > 0 || q(2) < 0, v = ' *'; end
                fprintf('    %-44s %5.1f%%  change %+5.1f [%+5.1f,%+5.1f]%s  normal weight %3.1f x   bearing called normal %4.1f%%\n', ...
                        names{c}, 100*r.F.acc, 100*(r.F.acc - R.pure.F.acc), q(1), q(2), v, r.nw, 100*mean(o.p(kb) == 1));
            end
        end
    end
end
fprintf(['\n* differs from the pure twin.  Normal weight: the normal class''s total training weight as a\n' ...
         'multiple of the pure twin''s.  If the CLASS BALANCE is the cause, the harm grows with the normal\n' ...
         'weight and vanishes at 1 x; any harm left at 1 x with vibration, but not without, is the\n' ...
         'vibration shortcut.\n\n']);
end

function sel = choose(Dc, pool, cfg)
twin = Dc.src == 1 & ismember(Dc.sess, pool);
realN = Dc.src == 2 & ismember(Dc.sess, pool) & Dc.y == 1;
if strcmp(cfg, 'pure'), rows = twin; else, rows = twin | realN; end
w = ones(nnz(rows), 1);  sr = Dc.src(rows);  yr = Dc.y(rows);
switch cfg
    case 'x1'
        tn = sr == 1 & yr == 1;  rn = sr == 2;
        w(tn) = 0.5;  w(rn) = 0.5*nnz(tn)/max(nnz(rn), 1);
    case 'xW'
        if any(sr == 2), w(sr == 2) = nnz(sr == 1)/nnz(sr == 2); end
end
sel = struct('rows', rows, 'w', w);
end

function Dx = arrays(FT, tw, nA, nB, cls)
T = FT.A;  TB = FT.B.(sprintf('T%d', tw));  k = ismember(T.state, cls);
A = T{k, nA};  B = TB{k, nB};  A(~isfinite(A)) = 0;  B(~isfinite(B)) = 0;
[~, y] = ismember(cellstr(T.state(k)), cellstr(cls));
Dx = struct('A', A, 'B', B, 'y', y(:), 'sev', T.severity(k), 'sess', T.session(k), 'nC', numel(cls));
end

function p = rf_fit(X, y, w, Xt, seed)
rng(seed, 'twister');
opts = statset('UseParallel', ~isempty(gcp('nocreate')), 'UseSubstreams', true, ...
               'Streams', RandStream('mlfg6331_64', 'Seed', seed));
try
    mdl = TreeBagger(200, X, y, 'Method', 'classification', 'Weights', w, 'Options', opts);  p = str2double(predict(mdl, Xt));
catch
    mdl = fitcensemble(X, y, 'Method', 'Bag', 'NumLearningCycles', 200, 'Weights', w);  p = predict(mdl, Xt);
end
end
