function plot_learning_mixed(outdir)
R = load(fullfile(outdir, 'results', 'learning_mixed.mat'), 'L', 'M');  L = R.L;  M = R.M;
S = fig_style();  fd = fullfile(outdir, 'figures');  if ~exist(fd, 'dir'), mkdir(fd); end
sets = {'fig_learning_curves_five', 'five classes', ...
        {'within 3->3',            'A',  'Within the reference, Set A',     'o-',  'w',    S.black;
         'within 3->3',            'AB', 'Within the reference, Set A+B',   's-',  'line', S.black;
         'within 2->2',            'AB', 'Within Model 2',                  '^-',  'w',    S.dark;
         'forward 2->3',           'AB', 'Model 2 to the reference',        'd--', 'w',    S.black};
        'fig_learning_curves_four', 'four shared classes', ...
        {'within 1->1',            'AB', 'Within Model 1',                  'o-',  'w',    S.dark;
         'SHARED 4: forward 2->3', 'AB', 'Model 2 to the reference',        '^:',  'line', S.dark;
         'forward 1->3',           'AB', 'Model 1 to the reference',        'd:',  'line', S.black}};
for g = 1:size(sets, 1)
    show = sets{g,3};
    [fig, ax] = new_figure();  hw = 0;  h = [];  hl = {};
    for i = 1:size(show, 1)
        k = find(strcmp({L.cell}, show{i,1}) & strcmp({L.cols}, show{i,2}));
        if isempty(k), fprintf('learning curves: no results for %s, %s (rerun run_learning_mixed)\n', show{i,1}, show{i,2}); continue; end
        x = [L(k).size];  a = 100*[L(k).acc];
        hw = max([hw, a - 100*[L(k).lo], 100*[L(k).hi] - a]);
        if strcmp(show{i,5}, 'line'), mf = show{i,6}; else, mf = 'w'; end
        h(end+1) = plot(ax, x, a, show{i,4}, 'Color', show{i,6}, 'LineWidth', S.line, ...
                        'MarkerSize', S.marker, 'MarkerFaceColor', mf);
        hl{end+1} = show{i,3};
        fprintf('  learning curve, %s, %-24s %s: %s %%\n', sets{g,2}, show{i,1}, show{i,2}, sprintf('%.1f ', a));
    end
    xlim(ax, [10 130]);  ylim(ax, [50 100]);  set(ax, 'XTick', [20 40 60 90 120]);
    style_axes(ax, 'Training machines', 'Accuracy (%)');
    style_legend(legend(ax, h, hl, 'Location', 'southeast'));
    save_figure(fig, fullfile(fd, sets{g,1}));  close(fig);
    fprintf('written: %s (%s; every plotted 95%% interval lies within +/-%.1f points, for the caption)\n', sets{g,1}, sets{g,2}, hw);
end
ks = unique([M.k]);  ks = ks(ks > 0);
[x, d, lo, hi] = diffs(M, ks, 'Model 2, five classes', 'twin + k, weighted', 'Model 2, five classes', 'real only, k');
[fig, ax] = new_figure();
draw_diff(ax, S, x, d, lo, hi, 'Model 2 twin added to the real machines');
xlim(ax, [0 42]);  set(ax, 'XTick', ks);
style_axes(ax, 'Real machines in training', 'Accuracy added by the twin (points)');
save_figure(fig, fullfile(fd, 'fig_mixed_twin_adds'));  close(fig);
fprintf('twin adds: %s points at k = %s\n', sprintf('%+.1f ', d), sprintf('%d ', x));
ks0 = unique([M.k]);
[x, d, lo, hi] = diffs(M, ks0, 'Model 2, shared four', 'twin + k, weighted', 'Model 1, shared four', 'twin + k, weighted');
[fig, ax] = new_figure();
draw_diff(ax, S, x, d, lo, hi, 'Model 2 minus Model 1, same real machines');
m = ceil(max(abs([lo hi]))) + 2;  ylim(ax, [-m m]);
xlim(ax, [-2 42]);  set(ax, 'XTick', ks0);
style_axes(ax, 'Real machines in training', 'Model 2 minus Model 1 (points)');
save_figure(fig, fullfile(fd, 'fig_mixed_fidelity'));  close(fig);
fprintf('Model 2 minus Model 1: %s points at k = %s\n', sprintf('%+.1f ', d), sprintf('%d ', x));
end

function [x, d, lo, hi] = diffs(M, ks, mixA, cfgA, mixB, cfgB)
x = [];  d = [];  lo = [];  hi = [];
for k = ks
    a = pick(M, mixA, cfgA, k);  b = pick(M, mixB, cfgB, k);
    if isempty(a) || isempty(b), continue; end
    bd = 100*(a.bootAcc - b.bootAcc);  q = quantile(bd, [0.025 0.975]);
    x(end+1) = k;  d(end+1) = 100*(a.acc - b.acc);  lo(end+1) = q(1);  hi(end+1) = q(2);
end
end

function s = pick(M, mix, cfg, k)
if k == 0 && ~isempty(strfind(cfg, 'weighted')), cfg = 'twin + k real'; end
j = find(strcmp({M.mix}, mix) & strcmp({M.config}, cfg) & [M.k] == k);
if isempty(j), s = []; else, s = M(j); end
end

function draw_diff(ax, S, x, d, lo, hi, label)
hb = fill(ax, [x fliplr(x)], [lo fliplr(hi)], S.fill, 'EdgeColor', 'none');
plot(ax, [-5 50], [0 0], '--', 'Color', S.dark, 'LineWidth', S.ref);
hl = plot(ax, x, d, 'o-', 'Color', S.black, 'LineWidth', S.line, 'MarkerSize', S.marker, 'MarkerFaceColor', 'w');
set(ax, 'Layer', 'top');
style_legend(legend(ax, [hl hb], {label, '95% interval'}, 'Location', 'northeast'));
end
