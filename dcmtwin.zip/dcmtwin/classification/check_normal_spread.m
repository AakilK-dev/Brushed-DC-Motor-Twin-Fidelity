function check_normal_spread(outdir)
F2 = load(fullfile(outdir, 'features', 'F_D2.mat'), 'FT');  F3 = load(fullfile(outdir, 'features', 'F_D3.mat'), 'FT');
T2 = F2.FT.A;  B2 = F2.FT.B.T2;  T3 = F3.FT.A;  B3 = F3.FT.B.T2;
n2 = T2.state == "normal";  n3 = T3.state == "normal";  b2 = T2.state == "bearing_outer";  b3 = T3.state == "bearing_outer";
fprintf('\nNORMAL RUNS: twin (Model 2 data) against reference, both through Model 2''s filter\n');
fprintf('%-8s %26s %26s %12s %14s\n', 'feature', 'twin: median [5%, 95%]', 'reference: median [5%, 95%]', 'spread ratio', 'median shift');
nA = {'A_spv','A_cur','A_i1','A_i2','A_i24','A_vrms','A_kurt','A_crest','A_v1','A_env'};
nB = {'B_R','B_Ke','B_L','B_Tf','B_h2','B_nis','B_rmsi'};
for f = nA, show(f{1}, T2.(f{1})(n2), T3.(f{1})(n3)); end
for f = nB, show(f{1}, B2.(f{1})(n2), B3.(f{1})(n3)); end
fprintf(['spread ratio: reference 5-95%% range over the twin''s; median shift: the difference of\n' ...
         'medians in units of the twin''s 5-95%% range.  A feature with a ratio far from 1 or a large\n' ...
         'shift can tell real normal runs from twin normal runs: a potential SOURCE CUE.\n']);
t2 = prctile(abs(B2.B_Tf(n2)), 99);  t3 = prctile(abs(B3.B_Tf(n3)), 99);
fprintf('\nfriction torque change of bearing faults: twin median %.2f mN.m, reference median %.2f mN.m\n', ...
        1e3*median(B2.B_Tf(b2)), 1e3*median(B3.B_Tf(b3)));
fprintf('99th percentile of |normal|: twin %.2f mN.m, reference %.2f mN.m\n', 1e3*t2, 1e3*t3);
fprintf('reference bearing faults above the TWIN''s normal band:      %5.1f%%\n', 100*mean(B3.B_Tf(b3) > t2));
fprintf('reference bearing faults above the REFERENCE''s normal band: %5.1f%%\n\n', 100*mean(B3.B_Tf(b3) > t3));
end

function show(name, x2, x3)
q2 = prctile(x2, [5 50 95]);  q3 = prctile(x3, [5 50 95]);
w2 = max(q2(3) - q2(1), eps);  r = (q3(3) - q3(1))/w2;  sh = (q3(2) - q2(2))/w2;
flag = '';  if r > 1.5 || r < 1/1.5 || abs(sh) > 0.5, flag = '  <- source cue'; end
fprintf('%-8s %9.3g [%8.3g, %8.3g] %9.3g [%8.3g, %8.3g] %10.1f x %+12.2f%s\n', name, q2(2), q2(1), q2(3), q3(2), q3(1), q3(3), r, sh, flag);
end
