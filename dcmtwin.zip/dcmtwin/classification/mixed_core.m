function M = mixed_core(D, foldVec, mixDef, ks, nRep, fitter, W, sAll)
M = struct('mix', {}, 'config', {}, 'k', {}, 'acc', {}, 'lo', {}, 'hi', {}, 'bootAcc', {}, 'rec', {}, 'bootRec', {}, 'accRep', {});
for m = 1:size(mixDef, 1)
    Dtw = D.(mixDef{m,2});  Dre = D.(mixDef{m,3});  nC = Dre.nC;
    Dc = struct('A', [Dtw.A; Dre.A], 'B', [Dtw.B; Dre.B], 'y', [Dtw.y; Dre.y], 'sev', [Dtw.sev; Dre.sev], ...
                'sess', [Dtw.sess; Dre.sess], 'src', [ones(numel(Dtw.y),1); 2*ones(numel(Dre.y),1)]);
    cfgs = {};
    for k = ks, cfgs(end+1,:) = {'twin + k real', k, 0}; end
    for k = ks(ks > 0), cfgs(end+1,:) = {'twin + k, weighted', k, 1}; end
    for k = ks(ks > 0), cfgs(end+1,:) = {'real only, k', k, 0}; end
    cfgs(end+1,:) = {'twin + real normal', 0, 0};  cfgs(end+1,:) = {'twin + real normal, weighted', 0, 1};
    for c = 1:size(cfgs, 1)
        name = cfgs{c,1};  k = cfgs{c,2};  wtd = cfgs{c,3};
        reps = nRep;  if k == 0, reps = 1; end
        y = [];  p = [];  sv = [];  ss = [];  accR = zeros(1, reps);
        for r = 1:reps
            pick = @(f, pool) choose(Dc, pool, name, k, wtd, 7000000 + 10*r + f);
            o = train_test_core(Dc, Dre, foldVec, pick, fitter, 'AB', [mixDef{m,1} ', ' name]);
            y = [y; o.y];  p = [p; o.p];  sv = [sv; o.sev];  ss = [ss; o.sess];
            accR(r) = mean(o.y == o.p);
        end
        K = boot_counts(y, p, sv, ss, nC);  [~, rows] = ismember(K.s, sAll);
        F = boot_scores(K, ones(numel(K.s), 1));  B = boot_scores(K, W(rows,:));
        q = quantile(B.acc, [0.025 0.975]);
        M(end+1) = struct('mix', mixDef{m,1}, 'config', name, 'k', k, 'acc', F.acc, 'lo', q(1), 'hi', q(2), ...
                          'bootAcc', B.acc, 'rec', F.recall', 'bootRec', B.recall, 'accRep', accR);
    end
end
report(M, mixDef, ks);
end

function sel = choose(Dc, pool, name, k, wtd, seed)
twinRows = Dc.src == 1 & ismember(Dc.sess, pool);
if k > 0, ix = seeded_perm(numel(pool), seed);  realS = pool(ix(1:min(k, numel(pool)))); else, realS = []; end
switch name
    case {'twin + k real', 'twin + k, weighted'}
        rows = twinRows | (Dc.src == 2 & ismember(Dc.sess, realS));
    case 'real only, k'
        rows = Dc.src == 2 & ismember(Dc.sess, realS);
    case {'twin + real normal', 'twin + real normal, weighted'}
        rows = twinRows | (Dc.src == 2 & ismember(Dc.sess, pool) & Dc.y == 1);
end
w = ones(nnz(rows), 1);  sr = Dc.src(rows);
if wtd && any(sr == 2) && any(sr == 1), w(sr == 2) = nnz(sr == 1)/nnz(sr == 2); end
sel = struct('rows', rows, 'w', w);
end

function report(M, mixDef, ks)
fprintf('\nMIXED TRAINING: accuracy (%%) on unseen reference machines, Set A+B, 95%% interval\n');
for m = 1:size(mixDef, 1)
    hdr = arrayfun(@(k) sprintf('k = %d', k), ks, 'UniformOutput', false);
    fprintf('\n%s\n%-30s', mixDef{m,1}, 'configuration');  fprintf('%18s', hdr{:});  fprintf('\n');
    for name = {'twin + k real', 'twin + k, weighted', 'real only, k'}
        fprintf('%-30s', name{1});
        for k = ks
            j = find(strcmp({M.mix}, mixDef{m,1}) & strcmp({M.config}, name{1}) & [M.k] == k);
            if isempty(j), fprintf('%18s', '-'); else, fprintf('  %4.1f [%4.1f,%4.1f]', 100*M(j).acc, 100*M(j).lo, 100*M(j).hi); end
        end
        fprintf('\n');
    end
    for name = {'twin + real normal', 'twin + real normal, weighted'}
        j = find(strcmp({M.mix}, mixDef{m,1}) & strcmp({M.config}, name{1}));
        fprintf('%-30s  %4.1f [%4.1f,%4.1f]   recall by class: %s\n', name{1}, 100*M(j).acc, 100*M(j).lo, 100*M(j).hi, sprintf('%3.0f ', 100*M(j).rec));
    end
    j0 = find(strcmp({M.mix}, mixDef{m,1}) & strcmp({M.config}, 'twin + k real') & [M.k] == 0);
    fprintf('%-30s  recall by class: %s\n', 'pure twin (k = 0)', sprintf('%3.0f ', 100*M(j0).rec));
end
fprintf('\nPAIRED COMPARISONS (accuracy, percentage points; 95%% interval)\n');
for m = 1:size(mixDef, 1)
    for k = ks(ks > 0)
        a = pickM(M, mixDef{m,1}, 'twin + k, weighted', k);  b = pickM(M, mixDef{m,1}, 'real only, k', k);
        cmp_line(sprintf('%s: twin + %d weighted minus real only %d', mixDef{m,1}, k, k), a, b);
    end
    a = pickM(M, mixDef{m,1}, 'twin + real normal, weighted', 0);  b = pickM(M, mixDef{m,1}, 'twin + k real', 0);
    cmp_line(sprintf('%s: real normal anchor (weighted) minus pure twin', mixDef{m,1}), a, b);
    if any(ks == 10)
        a = pickM(M, mixDef{m,1}, 'twin + k, weighted', 10);  b = pickM(M, mixDef{m,1}, 'twin + k real', 10);
        cmp_line(sprintf('%s: weighting effect at k = 10', mixDef{m,1}), a, b);
    end
end
i2 = find(~cellfun(@isempty, strfind(mixDef(:,1), 'Model 2, shared')));  i1 = find(~cellfun(@isempty, strfind(mixDef(:,1), 'Model 1')));
if ~isempty(i1) && ~isempty(i2)
    for k = ks
        cfg = 'twin + k, weighted';  if k == 0, cfg = 'twin + k real'; end
        a = pickM(M, mixDef{i2,1}, cfg, k);  b = pickM(M, mixDef{i1,1}, cfg, k);
        cmp_line(sprintf('Fidelity with real data: Model 2 minus Model 1, shared, k = %d', k), a, b);
    end
end
end

function s = pickM(M, mix, cfg, k)
j = find(strcmp({M.mix}, mix) & strcmp({M.config}, cfg) & [M.k] == k);  s = M(j);
end

function cmp_line(label, a, b)
d = 100*(a.bootAcc - b.bootAcc);  q = quantile(d, [0.025 0.975]);
v = 'not distinguishable';  if q(1) > 0 || q(2) < 0, v = 'differs'; end
fprintf('%-72s %+6.1f [%+6.1f, %+6.1f]  %s\n', label, 100*(a.acc - b.acc), q(1), q(2), v);
if numel(a.accRep) > 1 && numel(a.accRep) == numel(b.accRep)
    fprintf('%-72s %s\n', '      the same difference, draw by draw', sprintf(' %+6.1f', 100*(a.accRep - b.accRep)));
end
end
