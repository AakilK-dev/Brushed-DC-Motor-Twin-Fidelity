function R = grid_intervals(outdir, nBoot)

if nargin < 2 || isempty(nBoot), nBoot = 2000; end
L = load(fullfile(outdir, 'results', 'grid.mat'), 'G');  G = L.G;
if ~isfield(G, 'session')
    error('grid_intervals:noSession', 'grid.mat has no sessions: rerun run_grid (1.0.37 or later) first.');
end
sAll = unique(vertcat(G.session));  nS = numel(sAll);
W = zeros(nS, nBoot);  draw = resampler(20261006);
for b = 1:nBoot, W(:,b) = accumarray(draw(nS), 1, [nS 1]); end

R = struct('cell', {}, 'method', {}, 'classes', {}, 'full', {}, 'boot', {}, 'nSess', {}, 'nSessThird', {});
for i = 1:numel(G)
    cls = cellstr(G(i).classes);  nC = numel(cls);
    yc = codes(G(i).ytrue, cls);  pc = codes(G(i).ypred, cls);
    K = boot_counts(yc, pc, G(i).sev, G(i).session, nC);
    [~, rows] = ismember(K.s, sAll);
    nT = squeeze(sum(K.T(:,:,1,:) > 0, 4));
    R(i) = struct('cell', G(i).cell, 'method', G(i).method, 'classes', {cls}, ...
                  'full', boot_scores(K, ones(numel(K.s), 1)), 'boot', boot_scores(K, W(rows,:)), ...
                  'nSess', numel(K.s), 'nSessThird', nT);
end

cellsP = unique({R.cell}, 'stable');  meths = unique({R.method}, 'stable');
fprintf('\nACCURACY with 95%% interval, %d resamples of whole sessions\n%-30s', nBoot, 'cell');
fprintf('%22s', meths{:});  fprintf('\n');
for c = 1:numel(cellsP)
    fprintf('%-30s', cellsP{c});
    for m = 1:numel(meths)
        r = find(strcmp({R.cell}, cellsP{c}) & strcmp({R.method}, meths{m}));
        fprintf('%22s', ci_text(R(r).full.acc, R(r).boot.acc, R(r).nSess));
    end
    fprintf('\n');
end

faults = {'resistive', 'shorted_bar', 'bearing_outer', 'imbalance'};
fprintf('\nRECALL AT THE SMALLEST SEVERITY THIRD with 95%% interval (RF A / RF A+B / Rule)\n');
for c = 1:numel(cellsP)
    fprintf('%-30s', cellsP{c});
    for f = 1:numel(faults)
        txt = '';
        for m = {'RF A', 'RF A+B', 'Rule'}
            r = find(strcmp({R.cell}, cellsP{c}) & strcmp({R.method}, m{1}));
            k = find(strcmp(R(r).classes, faults{f}));
            if isempty(k), txt = 'not in cell'; break; end
            txt = [txt ci_text(R(r).full.bySev(k,1), squeeze(R(r).boot.bySev(k,1,:)), R(r).nSessThird(k,1), 0) ' '];
        end
        fprintf(' %-36s', txt);
    end
    fprintf('\n');
end

P = {'H3: Set B adds to resistive, within reference',  'within 3->3','RF A+B',  'within 3->3','RF A',  'resistive';
     'H3: Set B adds to resistive, forward from Model 2','forward 2->3','RF A+B','forward 2->3','RF A', 'resistive';
     'H3: Set B adds to resistive, forward from Model 1','forward 1->3','RF A+B','forward 1->3','RF A', 'resistive';
     'Set B adds to shorted bars, within reference',   'within 3->3','RF A+B',  'within 3->3','RF A',  'shorted_bar';
     'Fidelity, shared faults: Model 2 minus Model 1, Set A',   'SHARED 4: forward 2->3','RF A',   'forward 1->3','RF A',   '';
     'Fidelity, shared faults: Model 2 minus Model 1, Set A+B', 'SHARED 4: forward 2->3','RF A+B', 'forward 1->3','RF A+B', '';
     'Reference easier than Model 2, shared faults, Set A+B',   'SHARED 4: within 3->3','RF A+B', 'SHARED 4: within 2->2','RF A+B', '';
     'Transfer loss from Model 2, shared faults, Set A+B',      'SHARED 4: within 3->3','RF A+B', 'SHARED 4: forward 2->3','RF A+B', '';
     'Rules minus forest, reverse to Model 1',                  'reverse 3->1','Rule', 'reverse 3->1','RF A+B', '';
     'Rules minus forest, reverse to Model 2, shared faults',   'SHARED 4: reverse 3->2','Rule', 'SHARED 4: reverse 3->2','RF A+B', '';
     'Model 1 filter minus Model 2 filter, within reference',   'within 3->3 (Model 1 filter)','SVM A+B', 'within 3->3','SVM A+B', ''};
fprintf('\nPAIRED COMPARISONS (difference A minus B, percentage points; 95%% interval)\n');
cmp = struct('label', {}, 'diff', {}, 'lo', {}, 'hi', {}, 'differs', {});
for j = 1:size(P,1)
    [vA, bA] = metric(R, P{j,2}, P{j,3}, P{j,6});  [vB, bB] = metric(R, P{j,4}, P{j,5}, P{j,6});
    d = 100*(bA - bB);  q = quantile(d, [0.025 0.975]);  dif = q(1) > 0 || q(2) < 0;
    fprintf('%-58s %+6.1f  [%+6.1f, %+6.1f]  %s\n', P{j,1}, 100*(vA - vB), q(1), q(2), ifelse(dif, 'differs', 'not distinguishable'));
    cmp(j) = struct('label', P{j,1}, 'diff', 100*(vA - vB), 'lo', q(1), 'hi', q(2), 'differs', dif);
end
fprintf(['\nA perfect (or zero) score resamples to a zero-width interval, which understates its\n' ...
         'uncertainty; it is reported instead as a one-sided 95%% bound by the rule of three,\n' ...
         'taking n as the number of SESSIONS the score rests on (conservative, since runs within\n' ...
         'a session are correlated): at least 1 - 3/n (or at most 3/n), shown with >= (<=).\n' ...
         'Other zero-width intervals are genuine: one class wrong in every session, the rest right.\n']);
save(fullfile(outdir, 'results', 'intervals.mat'), 'R', 'cmp', 'nBoot');
fprintf('\nSaved results/intervals.mat\n\n');
end

function c = codes(y, cls)
if isa(y, 'categorical') || iscellstr(y) || isa(y, 'string')
    [tf, c] = ismember(cellstr(y(:)), cls);  c = double(c);  c(~tf) = NaN;
else
    c = double(y(:));
end
end

function [v, b] = metric(R, cellName, method, cls)
r = find(strcmp({R.cell}, cellName) & strcmp({R.method}, method));
if isempty(r), error('grid_intervals:missing', 'no result for %s, %s', cellName, method); end
if isempty(cls)
    v = R(r).full.acc;  b = R(r).boot.acc(:);
else
    k = find(strcmp(R(r).classes, cls));
    v = R(r).full.bySev(k,1);  b = squeeze(R(r).boot.bySev(k,1,:));
end
end

function f = resampler(seed)
if exist('RandStream', 'class') == 8 || exist('RandStream', 'file') == 2
    rs = RandStream('mt19937ar', 'Seed', seed);  f = @(n) randi(rs, n, n, 1);
else
    rand('seed', seed);  f = @(n) randi(n, n, 1);
end
end

function t = ci_text(v, b, nEff, dec)
if nargin < 4, dec = 1; end
q = quantile(b(:), [0.025 0.975]);  f = sprintf('%%.%df', dec);
if q(2) - q(1) < 1e-12 && (v >= 1 - 1e-12 || v <= 1e-12) && nEff > 0
    if v >= 1 - 1e-12, t = sprintf(['%s (>=' f ')'], sprintf(f, 100*v), 100*(1 - 3/nEff));
    else,              t = sprintf(['%s (<=' f ')'], sprintf(f, 100*v), 100*3/nEff); end
else
    t = sprintf([f ' [' f ', ' f ']'], 100*v, 100*q(1), 100*q(2));
end
end

function v = ifelse(c, a, b)
if c, v = a; else, v = b; end
end
