function Q = run_grid_lsq(outdir)

nA = {'A_spv','A_cur','A_i1','A_i2','A_i24','A_vrms','A_kurt','A_crest','A_v1','A_env'};
all5 = {'normal','resistive','shorted_bar','bearing_outer','imbalance'};
FA = cell(1, 3);  FB = cell(1, 3);
for d = 1:3
    L = load(fullfile(outdir, 'features', sprintf('F_D%d.mat', d)), 'FT');  FA{d} = tab_cols(L.FT.A);
    L = load(fullfile(outdir, 'features', sprintf('F_LS_D%d.mat', d)), 'FL');  FB{d} = L.FL;
    if ~isequal(FA{d}.session(:), FB{d}.session(:)) || ~isequal(FA{d}.state(:), FB{d}.state(:))
        error('run_grid_lsq:align', 'least-squares features of Model %d do not align with Set A', d);
    end
end
S = load(fullfile(outdir, 'datasets', 'sessions.mat'), 'S');  S = tab_cols(S.S);  sess = S.session;
rs = RandStream('mt19937ar', 'Seed', 20261004);
perm = sess(randperm(rs, numel(sess)));
fold = zeros(max(sess), 1);  fold(perm) = mod((1:numel(perm))' - 1, 5) + 1;
L = load(fullfile(outdir, 'results', 'grid.mat'), 'G');  G = L.G;
cells = {'within 3->3', 3, 3, 5;  'forward 2->3', 2, 3, 5;  'forward 1->3', 1, 3, 4;  'SHARED 4: forward 2->3', 2, 3, 4};
methods = {'RF', 'rf';  'SVM', 'svm'};
Q = struct('cell', {}, 'method', {}, 'classes', {}, 'ytrue', {}, 'ypred', {}, 'yfilt', {}, ...
           'sev', {}, 'session', {}, 'acc', {}, 'accFilt', {}, 'rs', {}, 'rsFilt', {}, 'cmp', {});
t0 = tic;
for c = 1:size(cells, 1)
    a = cells{c,2};  b = cells{c,3};  cls = all5(1:cells{c,4});
    [Xtr, ytr, ftr] = take(FA{a}, FB{a}, nA, cls, fold);
    [Xte, yte, fte, sev, ste] = take(FA{b}, FB{b}, nA, cls, fold);
    for mth = 1:size(methods, 1)
        yp = nan(size(yte));
        for k = 1:5
            itr = ftr ~= k;  ite = fte == k;
            yp(ite) = fit_predict(methods{mth,2}, Xtr(itr,:), ytr(itr), Xte(ite,:), k);
        end
        g = G(strcmp({G.cell}, cells{c,1}) & strcmp({G.method}, [methods{mth,1} ' A+B']));
        yf = codes(g.ytrue, cls);  pf = codes(g.ypred, cls);
        if ~isequal(yf(:), yte(:)) || ~isequal(g.session(:), ste(:))
            error('run_grid_lsq:rows', 'test rows of %s do not align with grid.mat', cells{c,1});
        end
        Q(end+1) = struct('cell', cells{c,1}, 'method', [methods{mth,1} ' A+B_LS'], 'classes', {cls}, ...
                          'ytrue', yte, 'ypred', yp, 'yfilt', pf, 'sev', sev, 'session', ste, ...
                          'acc', mean(yp == yte), 'accFilt', mean(pf == yte), ...
                          'rs', small_recall(yte, yp, sev), 'rsFilt', small_recall(yte, pf, sev), ...
                          'cmp', paired(yte, yp, pf, sev, ste));
    end
    fprintf('%-26s done   %5.1f min\n', cells{c,1}, toc(t0)/60);
end
d = fullfile(outdir, 'results');  if ~exist(d, 'dir'), mkdir(d); end
save(fullfile(d, 'grid_lsq.mat'), 'Q');
fprintf('\nSET B FROM LEAST SQUARES against SET B FROM THE FILTER (same cells, folds and methods)\n');
fprintf('%-24s %-14s %18s %18s %26s\n', 'cell', 'method', 'accuracy, LS', 'accuracy, filter', 'LS minus filter [95%]');
for q = Q
    fprintf('%-24s %-14s %17.1f%% %17.1f%%   %+6.1f [%+6.1f, %+6.1f] pp\n', q.cell, q.method, 100*q.acc, 100*q.accFilt, ...
            100*q.cmp.acc(1), 100*q.cmp.acc(2), 100*q.cmp.acc(3));
end
fprintf('\nRECALL OF THE SMALLEST RESISTIVE THIRD\n');
fprintf('%-24s %-14s %18s %18s %26s\n', 'cell', 'method', 'LS', 'filter', 'LS minus filter [95%]');
for q = Q
    fprintf('%-24s %-14s %17.0f%% %17.0f%%   %+6.0f [%+6.0f, %+6.0f] pp\n', q.cell, q.method, 100*q.rs, 100*q.rsFilt, ...
            100*q.cmp.rs(1), 100*q.cmp.rs(2), 100*q.cmp.rs(3));
end
fprintf('\nSaved results/grid_lsq.mat\n\n');
end

function [X, y, f, sev, s] = take(A, B, nA, cls, fold)
k = ismember(A.state, cls);
X = zeros(nnz(k), numel(nA));
for j = 1:numel(nA), c = A.(nA{j});  X(:,j) = c(k); end
X = [X, B.B(k,:)];  X(~isfinite(X)) = 0;
[~, y] = ismember(A.state(k), cls);  y = y(:);
s = A.session(k);  s = s(:);  f = fold(s);  sev = A.severity(k);  sev = sev(:);
end

function c = codes(y, cls)
[tf, c] = ismember(cellstr(y(:)), cls);  c = double(c);  c(~tf) = NaN;
end

function r = small_recall(y, yp, sev)
k = y == 2;  s = sev(k);  e = quantile(s, [0 1/3 2/3 1]);  in = s <= e(2);
ok = yp(k) == 2;  r = mean(ok(in));
end

function C = paired(y, yp, pf, sev, sess)
u = unique(sess);  nS = numel(u);  [~, si] = ismember(sess, u);
k = y == 2;  s = sev(k);  e = quantile(s, [0 1/3 2/3 1]);
small = false(size(y));  small(k) = sev(k) <= e(2);
nR = accumarray(si, 1, [nS 1]);  nSm = accumarray(si, double(small), [nS 1]);
dA = accumarray(si, double(yp == y) - double(pf == y), [nS 1]);
dR = accumarray(si, double(small & yp == 2) - double(small & pf == 2), [nS 1]);
rs = RandStream('mt19937ar', 'Seed', 20261015);  nB = 2000;  W = zeros(nS, nB);
for b = 1:nB, W(:,b) = accumarray(randi(rs, nS, nS, 1), 1, [nS 1]); end
bA = (dA'*W)./(nR'*W);  bR = (dR'*W)./max(nSm'*W, eps);
C.acc = [sum(dA)/sum(nR), quantile(bA, [0.025 0.975])];
C.rs  = [sum(dR)/max(sum(nSm), eps), quantile(bR, [0.025 0.975])];
end
