function out = train_test_core(Dtr, Dte, foldVec, pick, fitter, cols, tag)
y = [];  p = [];  sev = [];  sess = [];
for k = 1:5
    trS  = Dtr.sess(foldVec(Dtr.sess) ~= k);  pool = unique(trS);
    teR  = foldVec(Dte.sess) == k;            teS  = unique(Dte.sess(teR));
    sel  = pick(k, pool);
    used = unique(Dtr.sess(sel.rows));
    if ~isempty(intersect(used, teS))
        error('train_test_core:leak', '%s: fold %d trains on %d test sessions', tag, k, numel(intersect(used, teS)));
    end
    Xtr = feats(Dtr, sel.rows, cols);  Xte = feats(Dte, teR, cols);
    ph  = fitter(Xtr, Dtr.y(sel.rows), sel.w(:), Xte, 1000*k + numel(used));
    y = [y; Dte.y(teR)];  p = [p; ph(:)];  sev = [sev; Dte.sev(teR)];  sess = [sess; Dte.sess(teR)];
end
out = struct('y', y, 'p', p, 'sev', sev, 'sess', sess);
end

function X = feats(D, rows, cols)
switch cols
    case 'A',    X = D.A(rows,:);
    case 'ABnv', X = [D.A(rows,1:5), D.B(rows,:)];
    otherwise,   X = [D.A(rows,:), D.B(rows,:)];
end
end
