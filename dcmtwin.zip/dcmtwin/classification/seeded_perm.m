function ix = seeded_perm(n, seed)
if exist('RandStream', 'class') == 8 || exist('RandStream', 'file') == 2
    rs = RandStream('mt19937ar', 'Seed', seed);  ix = randperm(rs, n);
else
    rand('twister', seed);  ix = randperm(n);
end
end
