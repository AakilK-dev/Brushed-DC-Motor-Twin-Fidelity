function M = boot_scores(K, W)
[nC, ~, nS] = size(K.C);  nB = size(W, 2);
Cf = reshape(K.C, nC*nC, nS)*W;
Tf = reshape(K.T, nC*3*2, nS)*W;
M.acc = zeros(1, nB);  M.macroF1 = zeros(1, nB);  M.recall = zeros(nC, nB);  M.bySev = nan(nC, 3, nB);
for b = 1:nB
    C = reshape(Cf(:,b), nC, nC);  n = sum(K.nRun.*W(:,b));
    rec = diag(C)./max(sum(C,2), 1);  pre = diag(C)./max(sum(C,1)', 1);
    f1  = 2*rec.*pre./max(rec + pre, eps);
    M.acc(b) = trace(C)/max(n, 1);  M.macroF1(b) = mean(f1);  M.recall(:,b) = rec;
    T = reshape(Tf(:,b), nC, 3, 2);
    M.bySev(:,:,b) = T(:,:,2)./T(:,:,1);
end
end
