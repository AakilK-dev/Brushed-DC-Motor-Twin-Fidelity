function FT = extract_features(outdir, dataModel)

S  = load(fullfile(outdir, 'datasets', 'sessions.mat'), 'S');  S = S.S;
src = fullfile(outdir, 'datasets', sprintf('M%d', dataModel));
switch dataModel, case 1, twins = 1; case 2, twins = 2; otherwise, twins = [1 2]; end
nS = height(S);  rowsA = cell(nS,1);  rowsB = cell(nS, 2);
parfor j = 1:nS
    L = load(fullfile(src, sprintf('session_%04d.mat', S.session(j))), 'X');  X = L.X;
    m = arrayfun(@(r) measure(r.rec), X.runs);
    b = m(1);
    A = [];
    for i = 2:numel(X.runs)
        a = m(i);
        A = [A; [a.spv/b.spv - 1, a.cur/b.cur - 1, a.i1 - b.i1, a.i2 - b.i2, a.i24 - b.i24, ...
                 log(a.vrms/b.vrms), a.kurt - b.kurt, a.crest - b.crest, a.v1 - b.v1, log(a.env/b.env)]];
    end
    rowsA{j} = struct('session', S.session(j), 'machine', S.machine(j), 'duty', S.duty(j), ...
        'theta', S.theta_degC(j), 'state', {{X.runs(2:end).state}}, 'severity', [X.runs(2:end).severity], 'A', A);
    tb = cell(1,2);
    for t = twins
        Lz = load(fullfile(outdir, 'estimates', sprintf('D%d_T%d', dataModel, t), ...
                  sprintf('session_%04d.mat', S.session(j))), 'Z');
        R = Lz.Z.runs;  fb = R(1).final;  ib = R(1).innov;  Bt = [];
        for i = 2:numel(R)
            f = R(i).final;  in = R(i).innov;
            Bt = [Bt; [f.R/fb.R - 1, f.Ke/fb.Ke - 1, f.L/fb.L - 1, (f.b - fb.b)*m(i).w, ...
                       log(f.h2/fb.h2), in.meanNIS - ib.meanNIS, in.rms_i/ib.rms_i - 1, ...
                       m(i).w, fb.b]];
        end
        tb{t} = Bt;
    end
    rowsB(j,:) = tb;
end
namesA = {'A_spv','A_cur','A_i1','A_i2','A_i24','A_vrms','A_kurt','A_crest','A_v1','A_env'};
namesB = {'B_R','B_Ke','B_L','B_Tf','B_h2','B_nis','B_rmsi','X_w','X_bbase'};
meta = table();  Amat = [];
for j = 1:nS
    r = rowsA{j};  n = size(r.A,1);
    meta = [meta; table(repmat(r.session,n,1), repmat(r.machine,n,1), repmat(r.duty,n,1), ...
        repmat(r.theta,n,1), string(r.state(:)), r.severity(:), ...
        'VariableNames', {'session','machine','duty','theta','state','severity'})];
    Amat = [Amat; r.A];
end
meta.state(meta.state == "healthy") = "normal";
FT.A = [meta, array2table(Amat, 'VariableNames', namesA)];
for t = twins
    FT.B.(sprintf('T%d', t)) = [meta, array2table(vertcat(rowsB{:, t}), 'VariableNames', namesB)];
end
FT.dataModel = dataModel;
d = fullfile(outdir, 'features');  if ~exist(d, 'dir'), mkdir(d); end
save(fullfile(d, sprintf('F_D%d.mat', dataModel)), 'FT');
fprintf('\nFeatures of the Model %d dataset: %d runs\n', dataModel, height(FT.A));
summary(FT.A, namesA, 'Set A (measured)');
for t = twins, summary(FT.B.(sprintf('T%d', t)), namesB(1:7), sprintf('Set B, Model %d filter', t)); end
end

function m = measure(rec)
fs = rec.cur.fs;  k0 = round(0.5*fs) + 1;
th = double(rec.enc.y);  i = double(rec.cur.y);  v = double(rec.vsup.y);
n  = numel(th);
m.w   = (th(end) - th(k0))/((n - k0)/fs);
m.spv = m.w/mean(v(k0:end));
m.cur = mean(i(k0:end));
ic = i(k0:end) - m.cur;  tc = th(k0:end);
m.i1 = abs(ordern(ic, tc, 1));  m.i2 = abs(ordern(ic, tc, 2));  m.i24 = abs(ordern(ic, tc, 24));
fa = rec.acc.fs;  a0 = round(0.5*fa) + 1;
a  = double(rec.acc.y(a0:end));  a = a - mean(a);
m.vrms  = sqrt(mean(a.^2));
m.kurt  = mean(a.^4)/m.vrms^4;
m.crest = max(abs(a))/m.vrms;
ta = (a0-1:numel(rec.acc.y)-1)'/fa;  tcg = (0:n-1)'/fs;
tha = interp1(tcg, th, ta, 'linear', 'extrap');
m.v1 = abs(ordern(a, tha, 1));
[bb, aa] = butter(4, [5500 7000]/(fa/2), 'bandpass');
env = abs(hilbert(filtfilt(bb, aa, a)));  env = env - mean(env);
m.env = abs(ordern(env, tha, 5.787));
end

function c = ordern(x, th, n)
t0 = th(1);  nrev = floor((th(end) - t0)/(2*pi));
k  = th <= t0 + nrev*2*pi;  tt = th(k);  xx = x(k);  dth = gradient(tt);
c  = 2*sum(xx.*exp(-1i*n*tt).*dth)/sum(dth);
end

function summary(T, names, label)
fprintf('\n%s: median per run type\n%-14s', label, 'run');
fprintf('%10s', names{:});  fprintf('\n');
for s = ["normal","resistive","shorted_bar","bearing_outer","imbalance"]
    k = T.state == s;  if ~any(k), continue; end
    fprintf('%-14s', s);  fprintf('%10.4g', median(T{k, names}, 1));  fprintf('\n');
end
end
