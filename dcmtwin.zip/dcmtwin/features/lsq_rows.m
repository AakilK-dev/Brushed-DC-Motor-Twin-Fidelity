function B = lsq_rows(runs)

eb = runs(1).final;  n = numel(runs) - 1;  B = zeros(n, 7);
for i = 2:numel(runs)
    e = runs(i).final;
    B(i-1,:) = [e.R/eb.R - 1, e.Ke/eb.Ke - 1, e.L/eb.L - 1, e.Tf - eb.Tf, ...
                log(e.h2/eb.h2), e.unexplained - eb.unexplained, e.rms/eb.rms - 1];
end
end
