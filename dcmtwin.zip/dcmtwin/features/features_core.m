function F = features_core(X, Zs, band)

if nargin < 3 || isempty(band), band = [5500 7000]; end
m = arrayfun(@(r) measure(r.rec, band), X.runs);
b = m(1);
n = numel(X.runs) - 1;
A = zeros(n, 10);
for i = 2:numel(X.runs)
    a = m(i);
    A(i-1,:) = [a.spv/b.spv - 1, a.cur/b.cur - 1, a.i1 - b.i1, a.i2 - b.i2, a.i24 - b.i24, ...
                log(a.vrms/b.vrms), a.kurt - b.kurt, a.crest - b.crest, a.v1 - b.v1, log(a.env/b.env)];
end
F.A = A;
F.B = cell(1, 2);
for t = 1:2
    if numel(Zs) < t || isempty(Zs{t}), continue; end
    R = Zs{t}.runs;  fb = R(1).final;  ib = R(1).innov;  Bt = zeros(n, 9);
    for i = 2:numel(R)
        f = R(i).final;  in = R(i).innov;
        Bt(i-1,:) = [f.R/fb.R - 1, f.Ke/fb.Ke - 1, f.L/fb.L - 1, (f.b - fb.b)*m(i).w, ...
                     log(f.h2/fb.h2), in.meanNIS - ib.meanNIS, in.rms_i/ib.rms_i - 1, ...
                     m(i).w, fb.b];
    end
    F.B{t} = Bt;
end
F.state    = {X.runs(2:end).state};
F.severity = [X.runs(2:end).severity];
F.w        = [m(2:end).w];
end

function m = measure(rec, band)
fs = rec.cur.fs;  k0 = round(0.5*fs) + 1;
th = double(rec.enc.y);  i = double(rec.cur.y);  v = double(rec.vsup.y);
n  = numel(th);
m.w   = (th(end) - th(k0))/((n - k0)/fs);
m.spv = m.w/mean(v(k0:end));
m.cur = mean(i(k0:end));
ic = i(k0:end) - m.cur;  tc = th(k0:end);
m.i1 = abs(ordern(ic, tc, 1));  m.i2 = abs(ordern(ic, tc, 2));  m.i24 = abs(ordern(ic, tc, 24));
fa = rec.acc.fs;  a0 = round(0.5*fa) + 1;
a  = double(rec.acc.y(a0:end));  a = a - mean(a);
m.vrms  = sqrt(mean(a.^2));
m.kurt  = mean(a.^4)/m.vrms^4;
m.crest = max(abs(a))/m.vrms;
ta = (a0-1:numel(rec.acc.y)-1)'/fa;  tcg = (0:n-1)'/fs;
tha = interp1(tcg, th, ta, 'linear', 'extrap');
m.v1 = abs(ordern(a, tha, 1));
[bb, aa] = butter(4, band/(fa/2), 'bandpass');
env = abs(hilbert(filtfilt(bb, aa, a)));  env = env - mean(env);
m.env = abs(ordern(env, tha, 5.787));
end

function c = ordern(x, th, n)
t0 = th(1);  nrev = floor((th(end) - t0)/(2*pi));
k  = th <= t0 + nrev*2*pi;  tt = th(k);  xx = x(k);  dth = gradient(tt);
c  = 2*sum(xx.*exp(-1i*n*tt).*dth)/sum(dth);
end
