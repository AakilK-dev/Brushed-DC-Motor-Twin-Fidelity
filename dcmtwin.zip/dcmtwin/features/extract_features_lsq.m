function FL = extract_features_lsq(outdir, dataModel, planName)

if nargin < 3 || isempty(planName), planName = 'sessions'; end
isHold = strcmpi(planName, 'holdout');
if isHold
    L = load(fullfile(outdir, 'datasets', 'holdout_sessions.mat'), 'S');
    src = fullfile(outdir, 'estimates', 'holdout_LS');  fo = 'F_holdout_LS.mat';
else
    L = load(fullfile(outdir, 'datasets', 'sessions.mat'), 'S');
    src = fullfile(outdir, 'estimates', sprintf('LS_D%d', dataModel));  fo = sprintf('F_LS_D%d.mat', dataModel);
end
S = tab_cols(L.S);  sess = S.session(:);
FL = struct('session', [], 'state', {{}}, 'severity', [], 'B', [], ...
            'names', {{'BL_R','BL_Ke','BL_L','BL_Tf','BL_h2','BL_nis','BL_rmsi'}}, 'dataModel', dataModel);
for j = 1:numel(sess)
    Lz = load(fullfile(src, sprintf('session_%04d.mat', sess(j))), 'Z');
    B = lsq_rows(Lz.Z.runs);  n = size(B, 1);
    FL.session  = [FL.session; repmat(sess(j), n, 1)];
    FL.state    = [FL.state; strrep({Lz.Z.runs(2:end).state}', 'healthy', 'normal')];
    FL.severity = [FL.severity; [Lz.Z.runs(2:end).severity]'];
    FL.B        = [FL.B; B];
end
d = fullfile(outdir, 'features');  if ~exist(d, 'dir'), mkdir(d); end
save(fullfile(d, fo), 'FL');
fprintf('\nLeast-squares Set B of the Model %d %s records: %d runs\n', dataModel, ifelse(isHold, 'hold-out', 'diagnosis'), size(FL.B, 1));
fprintf('%-14s', 'run');  fprintf(' %10s', FL.names{:});  fprintf('\n');
for s = {'normal','resistive','shorted_bar','bearing_outer','imbalance'}
    k = strcmp(FL.state, s{1});  if ~any(k), continue; end
    fprintf('%-14s', s{1});  fprintf(' %10.4g', median(FL.B(k,:), 1));  fprintf('\n');
end
end

function v = ifelse(c, a, b)
if c, v = a; else, v = b; end
end
