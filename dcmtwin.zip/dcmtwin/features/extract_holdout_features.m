function FH = extract_holdout_features(outdir)

L  = load(fullfile(outdir, 'datasets', 'holdout_sessions.mat'), 'S');  S = tab_cols(L.S);
nS = numel(S.session);  parts = cell(nS, 1);
src = fullfile(outdir, 'datasets', 'holdout_M3');
parfor j = 1:nS
    Lx = load(fullfile(src, sprintf('session_%04d.mat', S.session(j))), 'X');
    Zs = cell(1, 2);
    for t = 1:2
        Lz = load(fullfile(outdir, 'estimates', sprintf('holdout_T%d', t), sprintf('session_%04d.mat', S.session(j))), 'Z');
        Zs{t} = Lz.Z;
    end
    F = features_core(Lx.X, Zs);
    n = size(F.A, 1);
    parts{j} = struct('session', repmat(S.session(j), n, 1), 'machine', repmat(S.machine(j), n, 1), ...
                      'duty', repmat(S.duty(j), n, 1), 'state', {strrep(F.state(:), 'healthy', 'normal')}, ...
                      'severity', F.severity(:), 'A', F.A, 'B1', F.B{1}, 'B2', F.B{2});
end
P = [parts{:}];
FH = struct('session', vertcat(P.session), 'machine', vertcat(P.machine), 'duty', vertcat(P.duty), ...
            'state', {vertcat(P.state)}, 'severity', vertcat(P.severity), 'A', vertcat(P.A), ...
            'B1', vertcat(P.B1), 'B2', vertcat(P.B2), ...
            'namesA', {{'A_spv','A_cur','A_i1','A_i2','A_i24','A_vrms','A_kurt','A_crest','A_v1','A_env'}}, ...
            'namesB', {{'B_R','B_Ke','B_L','B_Tf','B_h2','B_nis','B_rmsi','X_w','X_bbase'}});
d = fullfile(outdir, 'features');  if ~exist(d, 'dir'), mkdir(d); end
save(fullfile(d, 'F_holdout.mat'), 'FH');
fprintf('\nFeatures of the hold-out records: %d runs on %d machines\n', numel(FH.session), nS);
end
