function q = apply_fault(p, kind, sev)

q = p;
switch lower(kind)
    case 'healthy'
    case 'resistive'
        q.R = p.R*(1 + sev);
    case 'shorted_bar'
        r   = sev;
        if r < p.sc.range(1) || r > p.sc.range(2)
            warning('apply_fault:range', ...
                'Rsc/Rcoil = %g lies outside the calibrated range [%g, %g].', ...
                r, p.sc.range(1), p.sc.range(2));
        end
        sf  = 1/(1 + r);
        smn = 1/(1 + p.sc.range(2));
        smx = 1/(1 + p.sc.range(1));
        f   = (sf - smn)/(smx - smn);
        q.delta_s = p.delta0*(1 + (p.sc.growth - 1)*f);
        k   = 1 - p.sc.dK*f;
        q.Ke = p.Ke*k;
        q.Kt = p.Kt*k;
        q.L  = p.L*k^2;
        q.R  = p.R*k;
    case 'imbalance'
        q.mr = sev;
    case {'bearing_outer','bearing_inner'}
        q.brg.D   = sev;
        q.brg.loc = strrep(lower(kind), 'bearing_', '');
        q.b       = p.b*(1 + p.brg.kf*sev);
        q.b_lin   = p.b_lin*(1 + p.brg.kf*sev);
    otherwise
        error('apply_fault:kind','Unknown fault "%s".', kind);
end
q.fault = struct('kind',kind,'sev',sev);
end
