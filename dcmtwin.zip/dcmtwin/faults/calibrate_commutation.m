function cal = calibrate_commutation()

p   = params_default();
cfg = cfg_model3();  cfg.bearing = false;  cfg.modes = [];
T   = 0.5;  tA = 0.2;  V = p.Vs;

h = @(q) harmonic(run_sim(q, cfg, @(t) V, T), tA);

q = p;  q.delta_s = 1e-3;
[r, ~] = h(q);
% Targets (0.01734 and 1.04): Retana et al., IEEE Trans. Energy Convers., vol. 23, no. 2, pp. 484-491, 2008
d0 = 0.01734/(r/1e-3);
for k = 1:2
    q.delta_s = d0;  [r, ~] = h(q);
    d0 = d0*0.01734/r;
end
q.delta_s = d0;  [rH, wH] = h(q);

severe = @(dK) apply_turn_loss(p, p.sc.growth*d0, dK);
f  = @(dK) speed_of(h, severe(dK))/wH - 1.04;
dK = fzero(f, [0 0.08], optimset('TolX',1e-6));
[rS, wS] = h(severe(dK));

fprintf('\nCommutation surrogate calibration\n\n');
fprintf('%-32s %.5e   (params file: %.5e)\n', 'delta0', d0, p.delta0);
fprintf('%-32s %.5f     (params file: %.5f)\n', 'dK', dK, p.sc.dK);
fprintf('%-32s %.4f %%\n', 'healthy 2nd harmonic', 100*rH);
fprintf('%-32s %.3f %%\n', 'severe speed rise', 100*(wS/wH - 1));
fprintf('%-32s %.2f times\n\n', 'severe harmonic growth', rS/rH);
if abs(d0/p.delta0 - 1) > 1e-3 || abs(dK/p.sc.dK - 1) > 1e-3
    fprintf('The params file is OUT OF DATE: copy the values above into it.\n\n');
else
    fprintf('The params file matches the calibration.\n\n');
end
cal = struct('delta0',d0,'dK',dK,'healthy',rH,'rise',wS/wH - 1,'growth',rS/rH);
end

function q = apply_turn_loss(p, delta, dK)
q = p;  q.delta_s = delta;  k = 1 - dK;
q.Ke = p.Ke*k;  q.Kt = p.Kt*k;  q.L = p.L*k^2;  q.R = p.R*k;
end

function w = speed_of(h, q)
[~, w] = h(q);
end

function [ratio, wm] = harmonic(o, tA)
k  = o.t >= tA;
[a, dc] = order_amplitude(o.x(k,o.idx.i), o.x(k,o.idx.th), 2);
ratio = a/dc;
wm = mean(o.x(k,o.idx.w));
end
