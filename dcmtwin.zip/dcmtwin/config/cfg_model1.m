function cfg = cfg_model1()
cfg.name          = 'Model 1';
cfg.friction      = 'viscous';
cfg.angle         = false;
cfg.thermal       = false;
cfg.imbalance     = false;
cfg.modes         = [];
cfg.commutation   = false;
cfg.coil_resolved = false;
cfg.bearing       = false;
cfg.antialias     = false;
cfg.locked_rotor  = false;
cfg.gearbox       = false;
cfg.dt            = 1e-5;
end
