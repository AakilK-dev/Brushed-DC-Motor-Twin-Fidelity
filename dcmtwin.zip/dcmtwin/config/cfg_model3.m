function cfg = cfg_model3()
cfg             = cfg_model2();
cfg.name        = 'Model 3';
cfg.friction    = 'stribeck';
cfg.commutation = true;
cfg.modes       = [1 5 6];
cfg.bearing     = true;
end
