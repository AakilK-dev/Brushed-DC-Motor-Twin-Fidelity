function cfg = cfg_model2()
cfg          = cfg_model1();
cfg.name     = 'Model 2';
cfg.friction = 'coulomb';
cfg.gearbox  = true;
cfg.angle    = true;
cfg.thermal  = true;
cfg.imbalance= true;
cfg.modes    = 1;
end
