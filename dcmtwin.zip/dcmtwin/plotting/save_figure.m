function save_figure(fig, file)
S = fig_style();
[d, n] = fileparts(file);
file = fullfile(d, [n '.svg']);
set(fig, 'Units', 'centimeters');  p = get(fig, 'Position');
if abs(p(3) - S.wcm) > 1e-3 || abs(p(4) - S.hcm) > 1e-3
    set(fig, 'Position', [p(1:2) S.wcm S.hcm]);
end
drawnow;
ax = findall(fig, 'Type', 'axes');
for k = 1:numel(ax)
    try
        if ~isempty(ax(k).Toolbar), ax(k).Toolbar.Visible = 'off'; end
    catch
    end
end
try
    fit_axes(fig, ax);
catch err
    fprintf('save_figure: margins left as MATLAB set them (%s)\n', err.message);
end
drawnow;
try
    exportgraphics(fig, file, 'ContentType', 'vector', 'BackgroundColor', 'white', 'Padding', 'figure');
catch
    try
        exportgraphics(fig, file, 'ContentType', 'vector', 'BackgroundColor', 'white');
    catch
        set(fig, 'PaperUnits', 'centimeters', 'PaperSize', [S.wcm S.hcm], ...
                 'PaperPosition', [0 0 S.wcm S.hcm], 'PaperPositionMode', 'manual', 'InvertHardcopy', 'off');
        try
            print(fig, file, '-dsvg', '-vector');
        catch
            print(fig, file, '-dsvg');
        end
    end
end
fprintf('Figure saved as %s\n', file);
end

function fit_axes(fig, ax)
if ~isempty(findall(fig, 'Type', 'colorbar')) || ~isempty(findall(fig, 'Tag', 'colorbar')), return; end
lg = [findall(fig, 'Type', 'legend'); findall(fig, 'Tag', 'legend')];
for k = 1:numel(lg)
    try
        loc = lower(char(get(lg(k), 'Location')));
        if ~isempty(strfind(loc, 'outside')), return; end
    catch
    end
end
pad = 0.25;
for k = 1:numel(ax)
    tg = get(ax(k), 'Tag');
    if strcmp(get(ax(k), 'Visible'), 'off') || any(strcmpi(tg, {'legend', 'colorbar'})), continue; end
    u = get(ax(k), 'Units');
    set(ax(k), 'Units', 'centimeters');
    set(ax(k), 'LooseInset', get(ax(k), 'TightInset') + pad);
    set(ax(k), 'Units', u);
end
end
