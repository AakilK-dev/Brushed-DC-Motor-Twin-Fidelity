function [fig, ax] = new_figure()
S   = fig_style();
fig = figure('Color', 'w', 'Visible', 'off', 'WindowStyle', 'normal', ...
             'Units', 'centimeters', 'Position', [2 2 S.wcm S.hcm]);
if isprop(fig, 'Theme'), fig.Theme = 'light'; end
ax  = axes(fig, 'Color', 'w');
hold(ax, 'on');
end
