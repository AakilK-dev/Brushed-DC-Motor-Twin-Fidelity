function style_legend(lgd)
S = fig_style();
set(lgd, 'FontSize', S.legend, 'FontWeight', 'bold', 'Box', 'on', ...
         'EdgeColor', S.black, 'TextColor', S.black, 'Color', 'w');
end
