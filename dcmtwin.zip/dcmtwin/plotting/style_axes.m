function style_axes(ax, xlab, ylab)
S = fig_style();
fig = ancestor(ax, 'figure');
if isprop(fig, 'Theme'), fig.Theme = 'light'; end
set(ax, 'Color', 'w', 'FontSize', S.tick, 'FontWeight', 'normal', 'LineWidth', 1.0, ...
        'Box', 'on', 'XColor', S.black, 'YColor', S.black, ...
        'GridColor', S.grid, 'GridAlpha', 1);
grid(ax, 'on');
xlabel(ax, xlab, 'FontSize', S.label, 'FontWeight', 'bold', 'Color', S.black);
ylabel(ax, ylab, 'FontSize', S.label, 'FontWeight', 'bold', 'Color', S.black);
title(ax, '');
end
