function res = validate_friction(figdir)

if nargin < 1, figdir = ''; end

% Abdullah et al., IJEECS, vol. 27, no. 2, pp. 592-600, 2022, Table 4
w = [23.35 53.19 82.61 112.13 142.71 169.72 206.78 224.27 261.75 288.66 320.07 348.55]';
T = [0.0228 0.0270 0.0305 0.0338 0.0362 0.0395 0.0400 0.0438 0.0437 0.0449 0.0460 0.0475]';

fits = { 'Model 1, viscous only',      @fit_visc, 1 ; ...
         'Model 2, Coulomb + viscous', @fit_cv,   2 };

fprintf('\nFriction validation against Abdullah et al., Table 4\n\n');
for m = 1:size(fits,1)
    [f, prm] = fits{m,2}(w, T);
    res(m) = score(fits{m,1}, f, prm, fits{m,2}, fits{m,3}, w, T);
end

fprintf('\n%-38s %.2f times smaller for Model 2\n', 'leave-one-out prediction error', ...
        res(1).loocv/res(2).loocv);
fprintf('%-38s %.1f in favour of Model 2 (above 10 is conclusive)\n', ...
        'AIC difference', res(1).aic - res(2).aic);
fprintf('\nInterpretation\n');
fprintf('  Model 1 residuals are positive at every low speed and negative at every\n');
fprintf('  high one: the signature of a missing constant term.\n');
fprintf('  Model 2 residuals still show curvature, negative at both ends, so the\n');
fprintf('  measured torque rises less than linearly.  A further speed dependent\n');
fprintf('  effect is present that neither structure represents.\n\n');

if ~isempty(figdir)
    if ~exist(figdir, 'dir'), mkdir(figdir); end
    S  = fig_style();
    ww = linspace(0, 360, 200)';
    [f1,~] = fit_visc(w,T);  [f2,~] = fit_cv(w,T);

    [fig, ax] = new_figure();
    plot(ax, w, 1e3*T, 'o', 'Color',S.black, 'MarkerFaceColor',S.black, 'MarkerSize',S.marker);
    plot(ax, ww, 1e3*f1(ww), '--', 'Color',S.dark,  'LineWidth',S.line);
    plot(ax, ww, 1e3*f2(ww), '-',  'Color',S.black, 'LineWidth',S.line);
    style_axes(ax, 'Speed (rad/s)', 'No-load torque (mN\cdotm)');
    style_legend(legend(ax, {'Measured','Model 1: viscous','Model 2: Coulomb + viscous'}, ...
                        'Location','southeast'));
    save_figure(fig, fullfile(figdir, 'validate_friction_fit.svg'));

    [fig, ax] = new_figure();
    plot(ax, w, 1e3*(T - f1(w)), '--o', 'Color',S.dark,  'MarkerFaceColor','w', ...
         'LineWidth',S.line, 'MarkerSize',S.marker);
    plot(ax, w, 1e3*(T - f2(w)), '-s',  'Color',S.black, 'MarkerFaceColor',S.black, ...
         'LineWidth',S.line, 'MarkerSize',S.marker);
    yline(ax, 0, ':', 'Color',S.black, 'LineWidth',S.ref);
    style_axes(ax, 'Speed (rad/s)', 'Residual (mN\cdotm)');
    style_legend(legend(ax, {'Model 1','Model 2'}, 'Location','northeast'));
    save_figure(fig, fullfile(figdir, 'validate_friction_residuals.svg'));
end
end

function [f, prm] = fit_visc(w, T)
b = sum(w.*T)/sum(w.^2);
f = @(x) b*x;   prm = b;
end

function [f, prm] = fit_cv(w, T)
c = polyfit(w, T, 1);
f = @(x) c(2) + c(1)*x;   prm = [c(2) c(1)];
end

function r = score(name, f, prm, fitter, k, w, T)
n   = numel(w);
res = T - f(w);
sse = sum(res.^2);
sst = sum((T - mean(T)).^2);
R2  = 1 - sse/sst;
adj = 1 - (1 - R2)*(n - 1)/(n - k - 1);
rms = sqrt(sse/n);
aic = n*log(sse/n) + 2*k;
e   = zeros(n,1);
for j = 1:n
    keep = true(n,1);  keep(j) = false;
    [fj,~] = fitter(w(keep), T(keep));
    e(j) = T(j) - fj(w(j));
end
loocv = sqrt(mean(e.^2));
sgn = repmat('-', 1, n);  sgn(res > 0) = '+';
fprintf('%s\n', name);
fprintf('   parameters %s\n', mat2str(prm, 4));
fprintf('   R^2 %.4f   adjusted R^2 %.4f   RMSE %.3f mN.m\n', R2, adj, 1e3*rms);
fprintf('   AIC %.2f   leave-one-out RMSE %.3f mN.m   residual signs %s\n', aic, 1e3*loocv, sgn);
r = struct('name',name,'params',prm,'R2',R2,'adjR2',adj,'rmse',rms, ...
           'aic',aic,'loocv',loocv,'signs',sgn);
end
