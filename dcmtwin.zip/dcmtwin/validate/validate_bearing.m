function res = validate_bearing(figdir)

if nargin < 1, figdir = ''; end

% Rohani Bastami and Vahid, Mech. Syst. Signal Process., vol. 151, 107334, 2021, Table 1
L   = [0.7 2.2 3.2 4.4 8.7 11.3 12.6 16.7];
RMS = [37.7 40.1 52.2 53.4 57.9 65.8 67.4 73.8];
LCR = [1375 1952 2010 2642 2951 4195 4289 4380];
D   = L/8.5;

fprintf('\nBearing validation against Rohani Bastami and Vahid, Table 1\n');
fprintf('defect ratios D = %s\n\n', mat2str(round(D,3)));

cm = polyfit(D, RMS.^2, 1);
R2m = 1 - sum((RMS.^2 - polyval(cm,D)).^2)/sum((RMS.^2 - mean(RMS.^2)).^2);
fprintf('%-44s R^2 = %.4f\n', 'measured: mean square linear in D', R2m);

p   = params_default();
cfg = cfg_model3();
T   = 0.4;   tA = 0.15;
w0  = (p.Kt*p.Vs/p.R - p.Tc)/(p.Kt*p.Ke/p.R + p.b);
idx = state_index(cfg);
x0  = zeros(idx.n,1);  x0(idx.i) = (p.Vs - p.Ke*w0)/p.R;  x0(idx.w) = w0;

ms = zeros(size(D));  A = cell(size(D));
fprintf('running %d model cases, %.1f s each ...\n', numel(D), T);
for k = 1:numel(D)
    q = apply_fault(p, 'bearing_inner', D(k));
    q = make_bearing_noise(q, cfg, T, 200 + k);
    o = run_sim(q, cfg, @(t) p.Vs, T, x0);
    [a, fsA] = measured_accel(o, q, 400 + k, tA);
    A{k} = a;  ms(k) = mean(a.^2);
end
thr = (30/RMS(1))*sqrt(ms(1));
lcr = cellfun(@(a) sum(a(1:end-1) < thr & a(2:end) >= thr)/(numel(a)/fsA), A);

gMeas = (RMS.^2 - RMS(1)^2)/(RMS(end)^2 - RMS(1)^2);
gMod  = (ms - ms(1))/(ms(end) - ms(1));
hMeas = (LCR - LCR(1))/(LCR(end) - LCR(1));
hMod  = (lcr - lcr(1))/(lcr(end) - lcr(1));
in    = 2:numel(D)-1;

fprintf('\n%8s %12s %12s %12s %12s\n','D','MS meas','MS model','LCR meas','LCR model');
for k = 1:numel(D)
    fprintf('%8.3f %12.3f %12.3f %12.3f %12.3f\n', D(k), gMeas(k), gMod(k), hMeas(k), hMod(k));
end

res.ms  = summarise('mean-square growth',       gMeas, gMod, in);
res.lcr = summarise('level crossing growth',    hMeas, hMod, in);

lo = D < 1;
sM = [polyfit(D(lo),LCR(lo),1); polyfit(D(~lo),LCR(~lo),1)];
sS = [polyfit(D(lo),lcr(lo),1); polyfit(D(~lo),lcr(~lo),1)];
fprintf('\n%-44s measured %.2f   model %.2f\n', ...
        'LCR slope ratio above/below D = 1', sM(2,1)/sM(1,1), sS(2,1)/sS(1,1));
fprintf('\nInterpretation\n');
fprintf('  Mean-square growth is reproduced.  The level crossing rate has the\n');
fprintf('  bilinear shape but a sharper knee than measured.  The model omits the\n');
fprintf('  growth of radial clearance with defect size, which the authors show\n');
fprintf('  lowers vibration at larger defects, and the measurement contains other\n');
fprintf('  vibration sources.  Both are stated limitations.\n\n');

res.D = D;  res.gMeas = gMeas;  res.gMod = gMod;  res.hMeas = hMeas;  res.hMod = hMod;
res.R2measured = R2m;

if ~isempty(figdir)
    if ~exist(figdir, 'dir'), mkdir(figdir); end
    S = fig_style();
    curves = {gMeas, gMod, 'Normalised mean-square growth',    'validate_bearing_meansquare.svg'; ...
              hMeas, hMod, 'Normalised level crossing growth', 'validate_bearing_lcr.svg'};
    for c = 1:2
        [fig, ax] = new_figure();
        plot(ax, D, curves{c,1}, 'o', 'Color',S.black, 'MarkerFaceColor',S.black, ...
             'MarkerSize',S.marker);
        plot(ax, D, curves{c,2}, '--s', 'Color',S.dark, 'MarkerFaceColor','w', ...
             'LineWidth',S.line, 'MarkerSize',S.marker);
        xline(ax, 1, ':', 'Color',S.black, 'LineWidth',S.ref);
        style_axes(ax, 'Defect size ratio, D', curves{c,3});
        style_legend(legend(ax, {'Measured','Model 3'}, 'Location','southeast'));
        save_figure(fig, fullfile(figdir, curves{c,4}));
    end
end
end

function s = summarise(name, meas, model, in)
s.r_all    = corr(meas(:), model(:));
s.r_inner  = corr(meas(in)', model(in)');
s.nrmse_in = sqrt(mean((meas(in) - model(in)).^2));
fprintf('%-26s correlation all %.3f, interior %.3f;  interior error %.3f\n', ...
        name, s.r_all, s.r_inner, s.nrmse_in);
end
