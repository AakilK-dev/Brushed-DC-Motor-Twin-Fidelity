function D = integrated_core(Tr, Te, ytype, p, seed)

flagNames = {'R up', 'Ke down', 'L down', 'Tf up', 'h2 up', 'envelope up', '1x vibration up'};
nrm = Tr.code == 1;
thrB = prctile(abs(Tr.B(nrm,:)), 99, 1);
thrA = [prctile(Tr.A(nrm,10), 99), prctile(abs(Tr.A(nrm,9)), 99)];
ev = [Te.B(:,1) > thrB(1), Te.B(:,2) < -thrB(2), Te.B(:,3) < -thrB(3), Te.B(:,4) > thrB(4), ...
      Te.B(:,5) > thrB(5), Te.A(:,10) > thrA(1), Te.A(:,9) > thrA(2)];
t2 = ytype(:);
t2(ytype == 2 & ev(:,2)) = 3;
t2(ytype == 3 & ~ev(:,2) & ev(:,1)) = 2;
drift = 3*sqrt(2)*p.brake.reg*p.brake.Tfs/3;
unconf = t2 == 4 & Te.B(:,4) <= drift & ~ev(:,6);
sup = false(size(t2));
sup(t2 == 1) = ~any(ev(t2 == 1, :), 2);
sup(t2 == 2) = ev(t2 == 2, 1) & ~ev(t2 == 2, 2);
sup(t2 == 3) = ev(t2 == 3, 2);
sup(t2 == 4) = ev(t2 == 4, 4) | ev(t2 == 4, 6);
sup(t2 == 5) = ev(t2 == 5, 7);
mNames = {'RF A', 'RF A+B', 'Physics'};
sev = nan(size(t2));  cvMae = nan(4, 3);  method = cell(1, 4);
for f = 2:5
    k = Tr.code == f;  if nnz(k) < 5, continue; end
    XA = Tr.A(k,:);  XB = [Tr.A(k,:), Tr.B(k,:)];  y = Tr.severity(k);  fo = Tr.fold(k);
    e = nan(numel(y), 3);
    for kk = unique(fo(:))'
        itr = fo ~= kk;  ite = fo == kk;
        e(ite,1) = fit_predict('rfreg', XA(itr,:), y(itr), XA(ite,:), seed + kk) - y(ite);
        e(ite,2) = fit_predict('rfreg', XB(itr,:), y(itr), XB(ite,:), seed + kk) - y(ite);
    end
    e(:,3) = physics(f, Tr.A(k,:), Tr.B(k,:), Tr.aux(k,:), p) - y;
    cvMae(f-1,:) = mean(abs(e), 1, 'omitnan');
    [~, best] = min(cvMae(f-1,:));  method{f-1} = mNames{best};
    kt = t2 == f;  if ~any(kt), continue; end
    switch best
        case 1, sev(kt) = fit_predict('rfreg', XA, y, Te.A(kt,:), seed);
        case 2, sev(kt) = fit_predict('rfreg', XB, y, [Te.A(kt,:), Te.B(kt,:)], seed);
        case 3, sev(kt) = physics(f, Te.A(kt,:), Te.B(kt,:), Te.aux(kt,:), p);
    end
end
D = struct('type1', ytype(:), 'type2', t2, 'unconfirmed', unconf, 'ev', ev, 'evNames', {flagNames}, ...
           'supports', sup, 'sev', sev, 'method', {method}, 'methods', {mNames}, 'cvMae', cvMae, ...
           'thr', struct('B', thrB, 'A', thrA, 'drift', drift));
end

function s = physics(f, A, B, aux, p)
w = aux(:,1);  bb = aux(:,2);
switch f
    case 2, s = B(:,1);
    case 3, s = -B(:,2)/p.sc.dK;
    case 4, s = B(:,4)./(p.brg.kf*bb.*w);
    case 5
        a  = A(:,9)*9.81;
        wn = 2*pi*p.modes.f(1);  z = p.modes.zeta(1);
        s  = a.*p.M.*sqrt((wn^2 - w.^2).^2 + (2*z*wn*w).^2)./w.^4;
end
end
