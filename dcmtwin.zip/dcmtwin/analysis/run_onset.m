function R = run_onset(outdir)
L = load(fullfile(outdir, 'datasets', 'onset_sessions.mat'), 'S');  S = L.S;
nS = height(S);  tMin = 0.5;  tPer = 0.1;  margin = 1.2;  Tw = 0.25;  hop = 0.05;
stats = {'R', 0; 'Ke', 0; 'b', 1; 'vrms', 1; 'v1', 1; 'env', 1};  nSt = size(stats, 1);
faults = {'resistive', 'shorted_bar', 'bearing_outer', 'imbalance'};
Zs = cell(nS, 2);
fprintf('\nOnset analysis: %d sessions (%d calibration, %d scored)\n', nS, nnz(S.calib), nnz(~S.calib));
for j = 1:nS
    X = load(fullfile(outdir, 'datasets', 'onset_M3', sprintf('session_%04d.mat', S.session(j))), 'X');  X = X.X;
    Vb = windowed_vibration(X.runs(1).rec, Tw, hop);
    vb = struct('vrms', median(Vb.vrms), 'v1', median(Vb.v1), 'env', median(Vb.env));
    V = cell(1, numel(X.runs));
    for i = 1:numel(X.runs), V{i} = windowed_vibration(X.runs(i).rec, Tw, hop); end
    for tw = 1:2
        E = load(fullfile(outdir, 'estimates', sprintf('onset_T%d', tw), sprintf('session_%04d.mat', S.session(j))), 'Z');  Y = E.Z.runs;
        fb = Y(1).final;
        recs = struct('t', {}, 'z', {}, 'state', {}, 'sev', {}, 'onset', {});
        for i = 1:numel(Y)
            tf = double(Y(i).t) + Y(i).tStart;  x = double(Y(i).x);
            rr = struct();
            rr.t = {tf, tf, tf, V{i}.t, V{i}.t, V{i}.t};
            rr.z = {(x(:,4) - fb.R)/fb.R, (x(:,5) - fb.Ke)/fb.Ke, (x(:,6) - fb.b)/fb.b, ...
                    log(V{i}.vrms/vb.vrms), V{i}.v1 - vb.v1, log(V{i}.env/vb.env)};
            rr.state = X.runs(i).state;  rr.sev = X.runs(i).severity;  rr.onset = X.runs(i).onset;
            recs(i) = rr;
        end
        Zs{j, tw} = recs;
    end
    if mod(j, 10) == 0, fprintf('  %d of %d sessions read\n', j, nS); end
end
cal = find(S.calib);  sco = find(~S.calib);
thr = zeros(2, nSt);
for tw = 1:2
    for s = 1:nSt
        T = cell(1, numel(cal));  Z = T;
        for c = 1:numel(cal)
            r = Zs{cal(c), tw}(2);  T{c} = r.t{s};  Z{c} = r.z{s};
        end
        thr(tw, s) = onset_threshold(T, Z, stats{s,2}, tMin, margin);
    end
end
R = struct('twin', {}, 'fault', {}, 'detected', {}, 'delay', {}, 'preFA', {}, 'first', {}, 'sev', {}, 'onset', {});
FA = zeros(2, nSt);  FAany = zeros(2, 1);
for tw = 1:2
    for j = sco'
        r = Zs{j, tw}(2);  any1 = false;
        for s = 1:nSt
            a = onset_alarm(r.t{s}, r.z{s}, thr(tw,s), stats{s,2}, tPer, tMin);
            FA(tw, s) = FA(tw, s) + ~isnan(a);  any1 = any1 || ~isnan(a);
        end
        FAany(tw) = FAany(tw) + any1;
    end
    for f = 1:numel(faults)
        det = false(numel(sco),1);  dl = nan(numel(sco),1);  pre = false(numel(sco),1);  first = zeros(numel(sco),1);  sv = dl;  on = dl;
        for jj = 1:numel(sco)
            rr = Zs{sco(jj), tw}(2 + f);  tOn = rr.onset;  sv(jj) = rr.sev;  on(jj) = tOn;
            aPre = inf;  aPost = inf(1, nSt);
            for s = 1:nSt
                a0 = onset_alarm(rr.t{s}, rr.z{s}, thr(tw,s), stats{s,2}, tPer, tMin);
                if ~isnan(a0) && a0 < tOn, aPre = min(aPre, a0); end
                a1 = onset_alarm(rr.t{s}, rr.z{s}, thr(tw,s), stats{s,2}, tPer, tOn);
                if ~isnan(a1), aPost(s) = a1; end
            end
            pre(jj) = isfinite(aPre);
            [m, first(jj)] = min(aPost);
            if isfinite(m), det(jj) = true;  dl(jj) = m - tOn; else, first(jj) = 0; end
        end
        R(end+1) = struct('twin', tw, 'fault', faults{f}, 'detected', det, 'delay', dl, 'preFA', pre, ...
                          'first', first, 'sev', sv, 'onset', on);
    end
end
fprintf('\nTHRESHOLDS (1.2 x the largest excursion on %d calibration machines'' normal records)\n', numel(cal));
fprintf('%-8s', 'twin');  fprintf('%12s', stats{:,1});  fprintf('\n');
for tw = 1:2, fprintf('Model %d ', tw);  fprintf('%12.4g', thr(tw,:));  fprintf('\n'); end
fprintf('\nFALSE ALARMS on the %d scored machines'' normal monitoring records (5.5 s each)\n', numel(sco));
for tw = 1:2
    pairs = reshape([stats(:,1)'; num2cell(FA(tw,:))], 1, []);
    fprintf('Model %d filter: any statistic %d of %d;  by statistic %s\n', tw, FAany(tw), numel(sco), sprintf('%s %d  ', pairs{:}));
end
fprintf('\nDETECTION after onset, %d scored machines per fault\n', numel(sco));
fprintf('%-8s %-14s %10s %22s %16s %12s   %s\n', 'twin', 'fault', 'detected', 'delay median [95%]', 'delay 90th pct', 'pre-onset FA', 'first to notice');
for k = 1:numel(R)
    r = R(k);  n = numel(r.detected);  d = r.delay(r.detected);
    if isempty(d), md = NaN; ci = [NaN NaN]; p90 = NaN;
    else, md = median(d);  ci = boot_median(d);  p90 = prctile(d, 90); end
    fn = '';  for s = 1:nSt, c = nnz(r.first == s); if c, fn = [fn sprintf('%s %d  ', stats{s,1}, c)]; end, end
    fprintf('Model %d  %-14s %5d/%-4d %7.2f s [%4.2f, %4.2f] %12.2f s %9d/%-3d  %s\n', r.twin, r.fault, nnz(r.detected), n, md, ci(1), ci(2), p90, nnz(r.preFA), n, fn);
end
d = fullfile(outdir, 'results');  if ~exist(d, 'dir'), mkdir(d); end
save(fullfile(d, 'onset.mat'), 'R', 'thr', 'FA', 'FAany', 'stats', 'S');
try, plot_onset_figures(outdir, Zs); catch err, fprintf('skipped the onset figures: %s\n', err.message); end
end

function ci = boot_median(d)
rs = RandStream('mt19937ar', 'Seed', 20261012);  B = 2000;  m = zeros(B,1);  n = numel(d);
for b = 1:B, m(b) = median(d(randi(rs, n, n, 1))); end
ci = prctile(m, [2.5 97.5]);
end
