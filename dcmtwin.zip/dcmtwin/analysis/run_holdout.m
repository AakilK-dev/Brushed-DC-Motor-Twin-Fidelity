function H = run_holdout(outdir)

p = params_default();
nA = {'A_spv','A_cur','A_i1','A_i2','A_i24','A_vrms','A_kurt','A_crest','A_v1','A_env'};
nB = {'B_R','B_Ke','B_L','B_Tf','B_h2','B_nis','B_rmsi','X_w','X_bbase'};
all5 = {'normal','resistive','shorted_bar','bearing_outer','imbalance'};
range = [0.28, 0.9, 0.95, 2.0e-5];
TR = cell(1, 3);
for d = 1:3
    L = load(fullfile(outdir, 'features', sprintf('F_D%d.mat', d)), 'FT');  A = tab_cols(L.FT.A);
    T = struct('A', cols(A, nA), 'state', {A.state(:)}, 'severity', A.severity(:), 'session', A.session(:));
    for t = 1:2
        f = sprintf('T%d', t);
        if isfield(L.FT.B, f), T.(sprintf('B%d', t)) = cols(tab_cols(L.FT.B.(f)), nB); else, T.(sprintf('B%d', t)) = []; end
    end
    L = load(fullfile(outdir, 'features', sprintf('F_LS_D%d.mat', d)), 'FL');  T.BLS = L.FL.B;
    TR{d} = T;
end
L = load(fullfile(outdir, 'features', 'F_holdout.mat'), 'FH');  TE = L.FH;
L = load(fullfile(outdir, 'features', 'F_holdout_LS.mat'), 'FL');
if ~isequal(L.FL.session(:), TE.session(:)) || ~isequal(L.FL.state(:), TE.state(:))
    error('run_holdout:align', 'the hold-out least-squares features do not align with Set A');
end
TE.BLS = L.FL.B;
cells = {'within reference', 3, 2, 5;  'forward 2->3', 2, 2, 5;  'forward 1->3', 1, 1, 4;  'SHARED 4: forward 2->3', 2, 2, 4};
methods = {'RF A', 'RF A+B', 'RF A+B_LS', 'Rule'};
sAll = unique(TE.session);  nS = numel(sAll);
rb = RandStream('mt19937ar', 'Seed', 20261014);  nBoot = 2000;  W = zeros(nS, nBoot);
for b = 1:nBoot, W(:,b) = accumarray(randi(rb, nS, nS, 1), 1, [nS 1]); end
H.cells = struct('cell', {}, 'method', {}, 'classes', {}, 'ytrue', {}, 'ypred', {}, 'sev', {}, 'session', {}, ...
                 'full', {}, 'boot', {}, 'nSess', {}, 'nSessThird', {});
for c = 1:size(cells, 1)
    Tr = TR{cells{c,2}};  tw = cells{c,3};  cls = all5(1:cells{c,4});
    ktr = ismember(Tr.state, cls);  kte = ismember(TE.state, cls);
    [~, ytr] = ismember(Tr.state(ktr), cls);  [~, yte] = ismember(TE.state(kte), cls);
    Btr = Tr.(sprintf('B%d', tw));  Bte = TE.(sprintf('B%d', tw));
    XA  = clean(Tr.A(ktr,:));   XAt = clean(TE.A(kte,:));
    XB  = clean(Btr(ktr,1:7));  XBt = clean(Bte(kte,1:7));
    XL  = clean(Tr.BLS(ktr,:)); XLt = clean(TE.BLS(kte,:));
    P = nan(nnz(kte), numel(methods));
    P(:,1) = fit_predict('rf', XA, ytr, XAt, 20261016);
    P(:,2) = fit_predict('rf', [XA XB], ytr, [XAt XBt], 20261016);
    P(:,3) = fit_predict('rf', [XA XL], ytr, [XAt XLt], 20261016);
    P(:,4) = rules(XB(ytr == 1,:), XBt, numel(cls));
    for m = 1:numel(methods)
        K = boot_counts(yte(:), P(:,m), TE.severity(kte), TE.session(kte), numel(cls));
        [~, rr] = ismember(K.s, sAll);
        H.cells(end+1) = struct('cell', cells{c,1}, 'method', methods{m}, 'classes', {cls}, 'ytrue', yte(:), ...
            'ypred', P(:,m), 'sev', TE.severity(kte), 'session', TE.session(kte), ...
            'full', boot_scores(K, ones(numel(K.s), 1)), 'boot', boot_scores(K, W(rr,:)), ...
            'nSess', numel(K.s), 'nSessThird', squeeze(sum(K.T(:,:,1,:) > 0, 4)));
    end
end
S = load(fullfile(outdir, 'datasets', 'sessions.mat'), 'S');  S = tab_cols(S.S);  sess = S.session;
rs = RandStream('mt19937ar', 'Seed', 20261004);
perm = sess(randperm(rs, numel(sess)));
fold = zeros(max(sess), 1);  fold(perm) = mod((1:numel(perm))' - 1, 5) + 1;
cfgs = {'deployment', 'forward 2->3', 2;  'upper bound', 'within reference', 3};
Te = struct('A', clean(TE.A), 'B', clean(TE.B2(:,1:7)), 'aux', TE.B2(:,8:9), 'code', codes(TE.state, all5), ...
            'severity', TE.severity(:), 'session', TE.session(:));
H.integrated = struct('config', {}, 'type1', {}, 'type2', {}, 'unconfirmed', {}, 'supports', {}, 'sev', {}, ...
                      'method', {}, 'score', {});
for c = 1:size(cfgs, 1)
    T = TR{cfgs{c,3}};
    Tr = struct('A', clean(T.A), 'B', clean(T.B2(:,1:7)), 'aux', T.B2(:,8:9), 'code', codes(T.state, all5), ...
                'severity', T.severity(:), 'session', T.session(:));
    Tr.fold = fold(Tr.session);
    g = H.cells(strcmp({H.cells.cell}, cfgs{c,2}) & strcmp({H.cells.method}, 'RF A+B'));
    D = integrated_core(Tr, Te, g.ypred, p, 20261017);
    H.integrated(c) = struct('config', cfgs{c,1}, 'type1', D.type1, 'type2', D.type2, 'unconfirmed', D.unconfirmed, ...
                             'supports', D.supports, 'sev', D.sev, 'method', {D.method}, ...
                             'score', tool_score(Te.code, D.type1, D.type2, D.sev, Te.severity, range));
end
pick = @(cl, m) H.cells(strcmp({H.cells.cell}, cl) & strcmp({H.cells.method}, m));
Pd = {'Transfer gap from Model 2 (within reference minus forward 2->3), RF A+B', 'within reference', 'RF A+B', 'forward 2->3', 'RF A+B', 0;
      'Model 2 minus Model 1, shared four, RF A+B',          'SHARED 4: forward 2->3', 'RF A+B', 'forward 1->3', 'RF A+B', 0;
      'Model 2 minus Model 1, shared four, RF A',            'SHARED 4: forward 2->3', 'RF A',   'forward 1->3', 'RF A',   0;
      'Set B gain, smallest resistive third, within reference', 'within reference', 'RF A+B', 'within reference', 'RF A', 2;
      'Set B gain, smallest resistive third, forward 2->3',  'forward 2->3', 'RF A+B', 'forward 2->3', 'RF A', 2;
      'Least squares minus filter Set B, forward 2->3',     'forward 2->3', 'RF A+B_LS', 'forward 2->3', 'RF A+B', 0};
H.paired = struct('label', {}, 'diff', {}, 'lo', {}, 'hi', {}, 'differs', {});
for j = 1:size(Pd, 1)
    a = pick(Pd{j,2}, Pd{j,3});  b = pick(Pd{j,4}, Pd{j,5});
    if Pd{j,6} == 0, va = a.full.acc;  ba = a.boot.acc;  vb = b.full.acc;  bb = b.boot.acc;
    else, va = a.full.bySev(2,1);  ba = squeeze(a.boot.bySev(2,1,:))';  vb = b.full.bySev(2,1);  bb = squeeze(b.boot.bySev(2,1,:))'; end
    q = quantile(ba(:) - bb(:), [0.025 0.975]);
    H.paired(j) = struct('label', Pd{j,1}, 'diff', va - vb, 'lo', q(1), 'hi', q(2), 'differs', q(1) > 0 || q(2) < 0);
end
H.nBoot = nBoot;  H.nMachines = nS;
report(H, all5);
d = fullfile(outdir, 'results');  if ~exist(d, 'dir'), mkdir(d); end
save(fullfile(d, 'holdout.mat'), 'H');
write_csv(fullfile(outdir, 'holdout_summary.csv'), H);
fprintf('Saved results/holdout.mat and holdout_summary.csv\n\n');
end

function M = cols(S, names)
M = zeros(numel(S.(names{1})), numel(names));
for j = 1:numel(names), M(:,j) = S.(names{j}); end
end

function X = clean(X)
X(~isfinite(X)) = 0;
end

function c = codes(st, cls)
[~, c] = ismember(st(:), cls);  c = double(c);
end

function yhat = rules(Bn, B, nCls)
thr  = prctile(abs(Bn), 99, 1);
yhat = ones(size(B,1), 1);
yhat(B(:,4) >  thr(4)) = 4;
yhat(B(:,1) >  thr(1)) = 2;
yhat(B(:,2) < -thr(2)) = 3;
yhat(yhat > nCls) = 1;
end

function s = tool_score(yt, y1, y2, sv, st, range)
s.acc1 = mean(y1 == yt);  s.acc2 = mean(y2 == yt);
for c = 1:5
    k = yt == c;  s.n(c) = nnz(k);  s.recall2(c) = mean(y2(k) == c);
    if c > 1
        kc = k & y2 == c;  e = sv(kc) - st(kc);
        s.maePct(c) = 100*mean(abs(e))/range(c-1);  s.within10(c) = mean(abs(e) <= 0.1*range(c-1));
    else
        s.maePct(c) = NaN;  s.within10(c) = NaN;
    end
end
end

function t = ci_text(v, b, nEff)
q = quantile(b(:), [0.025 0.975]);
if q(2) - q(1) < 1e-12 && (v >= 1 - 1e-12 || v <= 1e-12) && nEff > 0
    if v >= 1 - 1e-12, t = sprintf('%.1f (>=%.1f)', 100*v, 100*(1 - 3/nEff));
    else,              t = sprintf('%.1f (<=%.1f)', 100*v, 100*3/nEff); end
else
    t = sprintf('%.1f [%.1f, %.1f]', 100*v, 100*q(1), 100*q(2));
end
end

function report(H, all5)
fprintf('\nHOLD-OUT TEST: trained once on the 150 diagnosis sessions, tested once on %d new machines\n', H.nMachines);
fprintf('ACCURACY with 95%% interval (resampling machines)\n%-26s', 'cell');
ms = unique({H.cells.method}, 'stable');  cl = unique({H.cells.cell}, 'stable');
fprintf('%24s', ms{:});  fprintf('\n');
for c = 1:numel(cl)
    fprintf('%-26s', cl{c});
    for m = 1:numel(ms)
        g = H.cells(strcmp({H.cells.cell}, cl{c}) & strcmp({H.cells.method}, ms{m}));
        fprintf('%24s', ci_text(g.full.acc, g.boot.acc, g.nSess));
    end
    fprintf('\n');
end
fprintf('\nRECALL PER CLASS, RF A+B\n%-26s', 'cell');  fprintf('%22s', all5{:});  fprintf('\n');
for c = 1:numel(cl)
    g = H.cells(strcmp({H.cells.cell}, cl{c}) & strcmp({H.cells.method}, 'RF A+B'));
    fprintf('%-26s', cl{c});
    for k = 1:numel(all5)
        if k > numel(g.classes), fprintf('%22s', '(not in cell)'); continue; end
        fprintf('%22s', ci_text(g.full.recall(k), g.boot.recall(k,:), g.nSess));
    end
    fprintf('\n');
end
fprintf('\nRECALL AT THE SMALLEST SEVERITY THIRD (RF A / RF A+B / Rule)\n');
for c = 1:numel(cl)
    fprintf('%-26s', cl{c});
    for k = 2:numel(all5)
        g = H.cells(strcmp({H.cells.cell}, cl{c}) & strcmp({H.cells.method}, 'RF A'));
        if k > numel(g.classes), fprintf('  %-32s', [all5{k} ': not in cell']); continue; end
        t = '';
        for m = {'RF A', 'RF A+B', 'Rule'}
            g = H.cells(strcmp({H.cells.cell}, cl{c}) & strcmp({H.cells.method}, m{1}));
            t = [t sprintf('%.0f/', 100*g.full.bySev(k,1))];
        end
        fprintf('  %-32s', sprintf('%s %s%%', all5{k}, t(1:end-1)));
    end
    fprintf('\n');
end
fprintf('\nTHE TRACKED CONCLUSIONS ON THE HOLD-OUT (difference, percentage points, paired 95%% interval)\n');
for j = 1:numel(H.paired)
    x = H.paired(j);  st = 'not distinguishable';  if x.differs, st = 'differs'; end
    fprintf('%-72s %+6.1f [%+6.1f, %+6.1f]  %s\n', x.label, 100*x.diff, 100*x.lo, 100*x.hi, st);
end
fprintf('\nINTEGRATED TOOL ON THE HOLD-OUT\n');
for c = 1:numel(H.integrated)
    s = H.integrated(c).score;
    fprintf('%-12s accuracy %.1f%% from the classifier, %.1f%% after the rules;  severity MAE (%% of range) ', ...
            H.integrated(c).config, 100*s.acc1, 100*s.acc2);
    fprintf('%s %.1f  ', 'resistive', s.maePct(2), 'shorted bar', s.maePct(3), 'bearing', s.maePct(4), 'imbalance', s.maePct(5));
    fprintf('\n');
end
end

function write_csv(f, H)
fid = fopen(f, 'w');
fprintf(fid, 'cell,method,accuracy,acc_lo,acc_hi,macroF1,small_third_resistive,n_machines\n');
for g = H.cells
    q = quantile(g.boot.acc, [0.025 0.975]);
    fprintf(fid, '"%s",%s,%.4f,%.4f,%.4f,%.4f,%.4f,%d\n', g.cell, g.method, g.full.acc, q(1), q(2), ...
            g.full.macroF1, g.full.bySev(2,1), g.nSess);
end
fprintf(fid, '\npaired comparison,difference,lo,hi,differs\n');
for x = H.paired, fprintf(fid, '"%s",%.4f,%.4f,%.4f,%d\n', x.label, x.diff, x.lo, x.hi, x.differs); end
fclose(fid);
end
