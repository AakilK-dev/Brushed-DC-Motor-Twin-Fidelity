function I = run_integrated(outdir)

p = params_default();
nA = {'A_spv','A_cur','A_i1','A_i2','A_i24','A_vrms','A_kurt','A_crest','A_v1','A_env'};
nB = {'B_R','B_Ke','B_L','B_Tf','B_h2','B_nis','B_rmsi'};
all5 = {'normal','resistive','shorted_bar','bearing_outer','imbalance'};
range = [0.28, 0.9, 0.95, 2.0e-5];
D = cell(1, 3);
for d = 2:3
    L = load(fullfile(outdir, 'features', sprintf('F_D%d.mat', d)), 'FT');
    D{d} = runs_of(tab_cols(L.FT.A), tab_cols(L.FT.B.T2), nA, nB, all5);
end
S = load(fullfile(outdir, 'datasets', 'sessions.mat'), 'S');  S = tab_cols(S.S);  sess = S.session;
rs = RandStream('mt19937ar', 'Seed', 20261004);
perm = sess(randperm(rs, numel(sess)));
fold = zeros(max(sess), 1);  fold(perm) = mod((1:numel(perm))' - 1, 5) + 1;
for d = 2:3, D{d}.fold = fold(D{d}.session); end
L = load(fullfile(outdir, 'results', 'grid.mat'), 'G');  G = L.G;
L = load(fullfile(outdir, 'results', 'onset.mat'), 'R');  On = L.R;
cfgs = {'deployment', 'forward 2->3', 2;  'upper bound', 'within 3->3', 3};
I = struct('config', {}, 'cell', {}, 'type1', {}, 'type2', {}, 'unconfirmed', {}, 'supports', {}, ...
           'sev', {}, 'ytrue', {}, 'sevTrue', {}, 'session', {}, 'methodByFold', {}, 'cvMae', {}, 'score', {});
Te = D{3};
for c = 1:size(cfgs, 1)
    g = G(strcmp({G.cell}, cfgs{c,2}) & strcmp({G.method}, 'RF A+B'));
    yt = codes(g.ytrue, all5);  yp = codes(g.ypred, all5);
    if ~isequal(yt(:), Te.code) || ~isequal(g.session(:), Te.session)
        error('run_integrated:rows', 'the %s predictions of grid.mat do not align with the reference''s runs', cfgs{c,2});
    end
    n = numel(yt);  t2 = nan(n,1);  un = false(n,1);  su = false(n,1);  sv = nan(n,1);
    mbf = cell(5, 4);  cvm = nan(4, 3, 5);
    Tr0 = D{cfgs{c,3}};
    for k = 1:5
        itr = Tr0.fold ~= k;  ite = Te.fold == k;
        R = integrated_core(sub(Tr0, itr), sub(Te, ite), yp(ite), p, 20261107 + 10*k);
        t2(ite) = R.type2;  un(ite) = R.unconfirmed;  su(ite) = R.supports;  sv(ite) = R.sev;
        mbf(k,:) = R.method;  cvm(:,:,k) = R.cvMae;
    end
    sc = score(yt, yp, t2, un, su, sv, Te.severity, range);
    I(c) = struct('config', cfgs{c,1}, 'cell', cfgs{c,2}, 'type1', yp, 'type2', t2, 'unconfirmed', un, ...
                  'supports', su, 'sev', sv, 'ytrue', yt, 'sevTrue', Te.severity, 'session', Te.session, ...
                  'methodByFold', {mbf}, 'cvMae', cvm, 'score', sc);
end
onset = onset_summary(On, all5);
report(I, onset, all5, 'INTEGRATED DIAGNOSIS TOOL, five folds over the 150 diagnosis sessions');
d = fullfile(outdir, 'results');  if ~exist(d, 'dir'), mkdir(d); end
save(fullfile(d, 'integrated.mat'), 'I', 'onset');
write_csv(fullfile(outdir, 'integrated_summary.csv'), I, onset, all5);
fprintf('Saved results/integrated.mat and integrated_summary.csv\n\n');
end

function X = runs_of(A, B, nA, nB, cls)
k = ismember(A.state, cls);
X.A = cols(A, nA);  X.B = cols(B, nB);  X.aux = [B.X_w(:), B.X_bbase(:)];
X.A = X.A(k,:);  X.B = X.B(k,:);  X.aux = X.aux(k,:);
X.A(~isfinite(X.A)) = 0;  X.B(~isfinite(X.B)) = 0;
[~, c] = ismember(A.state(k), cls);  X.code = c(:);
X.severity = A.severity(k);  X.severity = X.severity(:);  X.session = A.session(k);  X.session = X.session(:);
end

function M = cols(S, names)
M = zeros(numel(S.(names{1})), numel(names));
for j = 1:numel(names), M(:,j) = S.(names{j}); end
end

function Y = sub(X, k)
Y = X;
for f = fieldnames(X)'
    v = X.(f{1});  if size(v, 1) == numel(k), Y.(f{1}) = v(k,:); end
end
end

function c = codes(y, cls)
[tf, c] = ismember(cellstr(y(:)), cls);  c = double(c);  c(~tf) = NaN;
end

function s = score(yt, yp, t2, un, su, sv, st, range)
s.acc1 = mean(yp == yt);  s.acc2 = mean(t2 == yt);
for c = 1:5
    k = yt == c;
    s.recall1(c) = mean(yp(k) == c);  s.recall2(c) = mean(t2(k) == c);
    s.n(c) = nnz(k);  s.support(c) = mean(su(k & t2 == c));
    s.unconf(c) = nnz(un(k));
    if c > 1
        kc = k & t2 == c;  e = sv(kc) - st(kc);
        s.maePct(c) = 100*mean(abs(e))/range(c-1);  s.biasPct(c) = 100*mean(e)/range(c-1);
        s.within10(c) = mean(abs(e) <= 0.1*range(c-1));
    else
        s.maePct(c) = NaN;  s.biasPct(c) = NaN;  s.within10(c) = NaN;
    end
end
ok = t2 == yt;  f = yt > 1;
rr = zeros(size(yt));  rr(f) = range(yt(f) - 1);
ok(f) = ok(f) & abs(sv(f) - st(f)) <= 0.1*rr(f);
s.endToEnd = mean(ok);  s.falseNormal = mean(t2(yt > 1) == 1);  s.falseAlarm = mean(t2(yt == 1) > 1);
s.unconfAll = nnz(un);  s.unconfRight = nnz(un & yt == 4);
end

function O = onset_summary(On, cls)
O = struct('fault', {}, 'detected', {}, 'n', {}, 'median', {}, 'p90', {});
for f = 2:numel(cls)
    r = On([On.twin] == 2 & strcmp({On.fault}, cls{f}));
    if isempty(r), O(end+1) = struct('fault', cls{f}, 'detected', NaN, 'n', 0, 'median', NaN, 'p90', NaN); continue; end
    dl = r.delay(r.detected);
    if isempty(dl), md = NaN; p9 = NaN; else, md = median(dl); p9 = prctile(dl, 90); end
    O(end+1) = struct('fault', cls{f}, 'detected', nnz(r.detected), 'n', numel(r.detected), 'median', md, 'p90', p9);
end
end

function report(I, onset, cls, head)
fprintf('\n%s\n', head);
for c = 1:numel(I)
    s = I(c).score;
    fprintf('\n%s (type from %s, RF A+B): accuracy %.1f%% from the classifier, %.1f%% after the rules; end to end %.1f%%\n', ...
            upper(I(c).config), I(c).cell, 100*s.acc1, 100*s.acc2, 100*s.endToEnd);
    fprintf('  faults called normal %.1f%%, normal runs called faulty %.1f%%; bearing calls left unconfirmed %d (of them truly bearing %d)\n', ...
            100*s.falseNormal, 100*s.falseAlarm, s.unconfAll, s.unconfRight);
    fprintf('  %-14s %5s %11s %11s %10s %14s %12s %11s %24s\n', 'class', 'runs', 'recall', 'after rules', 'evidence', ...
            'severity MAE', 'within 10%', 'method', 'onset: found, median');
    for k = 1:numel(cls)
        if k == 1
            fprintf('  %-14s %5d %10.1f%% %10.1f%% %9.0f%% %14s %12s %11s %24s\n', cls{k}, s.n(k), 100*s.recall1(k), ...
                    100*s.recall2(k), 100*s.support(k), '', '', '', '');
        else
            m = I(c).methodByFold(:, k-1);  m = m(~cellfun(@isempty, m));
            if isempty(m), mm = '-'; else, [u, ~, j] = unique(m); [~, b] = max(accumarray(j(:), 1)); mm = u{b}; end
            o = onset(k-1);
            fprintf('  %-14s %5d %10.1f%% %10.1f%% %9.0f%% %13.1f%% %11.0f%% %11s %12d/%-3d %6.2f s\n', cls{k}, s.n(k), ...
                    100*s.recall1(k), 100*s.recall2(k), 100*s.support(k), s.maePct(k), 100*s.within10(k), mm, ...
                    o.detected, o.n, o.median);
        end
    end
end
fprintf(['\nRules (integrated_core): Ke decides between resistive and shorted bar; a bearing call whose friction\n' ...
         'rise is within 3 sqrt(2) brake offsets (14.1 mN.m) needs vibration evidence or is left unconfirmed.\n' ...
         'Severity: the method of smallest cross-validated error on the training folds, per fault and fold.\n']);
end

function write_csv(f, I, onset, cls)
fid = fopen(f, 'w');
fprintf(fid, 'config,class,runs,recall_classifier,recall_after_rules,evidence_support,severity_mae_pct,severity_bias_pct,within10,onset_detected,onset_n,onset_median_s,onset_p90_s\n');
for c = 1:numel(I)
    s = I(c).score;
    for k = 1:numel(cls)
        if k == 1, o = struct('detected', NaN, 'n', NaN, 'median', NaN, 'p90', NaN); else, o = onset(k-1); end
        fprintf(fid, '%s,%s,%d,%.4f,%.4f,%.4f,%.3f,%.3f,%.4f,%g,%g,%.4f,%.4f\n', I(c).config, cls{k}, s.n(k), ...
                s.recall1(k), s.recall2(k), s.support(k), s.maePct(k), s.biasPct(k), s.within10(k), ...
                o.detected, o.n, o.median, o.p90);
    end
end
fclose(fid);
end
