function plot_integrated(outdir)

L = load(fullfile(outdir, 'results', 'integrated.mat'), 'I');  I = L.I;
fd = fullfile(outdir, 'figures');  if ~exist(fd, 'dir'), mkdir(fd); end
S = fig_style();
labels = {'Normal', 'Resistive', 'Shorted bar', 'Bearing', 'Imbalance'};
[fig, ax] = new_figure();
Y = 100*[I(1).score.recall2(:), I(2).score.recall2(:)];
hb = bar(ax, 1:5, Y, 'grouped');
set(hb(1), 'FaceColor', S.dark, 'EdgeColor', S.black);  set(hb(2), 'FaceColor', S.light, 'EdgeColor', S.black);
set(ax, 'XTick', 1:5, 'XTickLabel', labels);  ylim(ax, [0 135]);  set(ax, 'YTick', 0:20:100);
style_axes(ax, 'Class', 'Recall after the rules (%)');
lg = legend(ax, hb, {'Deployment (Model 2)', 'Upper bound (reference)'}, 'Location', 'northeast');
style_legend(lg);
save_figure(fig, fullfile(fd, 'fig_integrated_recall'));  close(fig);
fprintf('written: fig_integrated_recall\n');

lo = [0.02, 0.1, 0.05, 5e-6];  range = [0.28, 0.9, 0.95, 2.0e-5];  mk = {'o', 's', '^', 'd'};
files = {'resistive', 'shorted_bar', 'bearing', 'imbalance'};
pos = @(s, f) 100*(s - lo(f-1))/range(f-1);
for f = 2:5
    k = I(1).ytrue == f & I(1).type2 == f;
    if ~any(k), fprintf('fig_integrated_severity_%s: no correctly typed runs, not drawn\n', files{f-1}); continue; end
    [fig, ax] = new_figure();
    h2 = plot(ax, [0 100], [0 100], '-', 'Color', S.dark, 'LineWidth', S.ref);
    h1 = plot(ax, pos(I(1).sevTrue(k), f), pos(I(1).sev(k), f), mk{f-1}, ...
              'MarkerSize', S.marker - 2, 'MarkerEdgeColor', S.black, 'LineStyle', 'none', 'LineWidth', 1.2);
    xlim(ax, [0 100]);  ylim(ax, [-20 140]);
    style_axes(ax, 'True severity (% of its range)', 'Estimated severity (% of its range)');
    style_legend(legend(ax, [h1 h2], {sprintf('%s, deployment', labels{f}), 'Estimate equals truth'}, 'Location', 'northwest'));
    save_figure(fig, fullfile(fd, ['fig_integrated_severity_' files{f-1}]));  close(fig);
    e = pos(I(1).sev(k), f) - pos(I(1).sevTrue(k), f);
    fprintf('written: fig_integrated_severity_%s (%d runs; error median %+.1f, mean absolute %.1f, points of the range)\n', ...
            files{f-1}, nnz(k), median(e), mean(abs(e)));
end
end
