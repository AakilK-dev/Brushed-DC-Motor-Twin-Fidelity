function [a, fs] = measured_accel(o, q, seed, tA)
s  = virtual_sensors(o, q, seed, {'acc'});
k  = s.acc.t >= tA;
a  = double(s.acc.a(k));
a  = a - mean(a);
fs = q.acc.fs;
end
