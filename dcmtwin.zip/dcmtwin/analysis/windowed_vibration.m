function W = windowed_vibration(rec, Tw, hop)
fs = rec.cur.fs;  fa = rec.acc.fs;
th = double(rec.enc.y);  a = double(rec.acc.y);  a = a - mean(a);
tcg = (0:numel(th)-1)'/fs;  ta = (0:numel(a)-1)'/fa;
tha = interp1(tcg, th, ta, 'linear', 'extrap');
[bb, aa] = butter(4, [5500 7000]/(fa/2), 'bandpass');
env = abs(hilbert(filtfilt(bb, aa, a)));
te = (0.5 + Tw):hop:ta(end);  n = numel(te);
W = struct('t', te(:), 'vrms', nan(n,1), 'v1', nan(n,1), 'env', nan(n,1));
for k = 1:n
    s = ta > te(k) - Tw & ta <= te(k);
    x = a(s) - mean(a(s));  e = env(s) - mean(env(s));  h = tha(s);
    W.vrms(k) = sqrt(mean(x.^2));
    W.v1(k)   = abs(ordern(x, h, 1));
    W.env(k)  = abs(ordern(e, h, 5.787));
end
end

function c = ordern(x, th, n)
t0 = th(1);  nrev = floor((th(end) - t0)/(2*pi));
k  = th <= t0 + nrev*2*pi;  tt = th(k);  xx = x(k);  dth = gradient(tt);
c  = 2*sum(xx.*exp(-1i*n*tt).*dth)/sum(dth);
end
