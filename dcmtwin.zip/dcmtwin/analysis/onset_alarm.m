function tA = onset_alarm(t, z, thr, dirn, tPersist, tMin)
t = t(:);  z = z(:);
switch dirn
    case  1, e = z >  thr;
    case -1, e = z < -thr;
    otherwise, e = abs(z) > thr;
end
e(t < tMin | ~isfinite(z)) = false;
tA = NaN;  s = NaN;
for k = 1:numel(e)
    if e(k)
        if isnan(s), s = t(k); end
        if t(k) - s >= tPersist - 1e-9, tA = t(k); return; end
    else
        s = NaN;
    end
end
end
