function plot_holdout(outdir)

L = load(fullfile(outdir, 'results', 'holdout.mat'), 'H');  H = L.H;
fd = fullfile(outdir, 'figures');  if ~exist(fd, 'dir'), mkdir(fd); end
S = fig_style();
ms = unique({H.cells.method}, 'stable');
mk = {'o', 'o', 's', '^'};  fc = {'w', S.black, S.dark, 'w'};  off = linspace(-0.24, 0.24, numel(ms));
sets = {'fig_holdout_accuracy_five', {'within reference', 'forward 2->3'},           {'within 3 to 3', 'forward 2 to 3'};
        'fig_holdout_accuracy_four', {'forward 1->3', 'SHARED 4: forward 2->3'},     {'forward 1 to 3', 'forward 2 to 3'}};
for q = 1:size(sets, 1)
    cl = sets{q,2};
    [fig, ax] = new_figure();
    h = [];  hl = {};
    for m = 1:numel(ms)
        hm = [];
        for c = 1:numel(cl)
            g = H.cells(strcmp({H.cells.cell}, cl{c}) & strcmp({H.cells.method}, ms{m}));
            if isempty(g), continue; end
            qq = quantile(g.boot.acc, [0.025 0.975]);
            plot(ax, c + off(m)*[1 1], 100*qq, '-', 'Color', S.black, 'LineWidth', S.line);
            hh = plot(ax, c + off(m), 100*g.full.acc, mk{m}, 'MarkerSize', S.marker, 'MarkerEdgeColor', S.black, ...
                      'MarkerFaceColor', fc{m}, 'LineStyle', 'none', 'LineWidth', 1.5);
            if isempty(hm), hm = hh; end
            fprintf('  hold-out, %-24s %-12s %.1f%% [%.1f, %.1f]\n', cl{c}, ms{m}, 100*g.full.acc, 100*qq(1), 100*qq(2));
        end
        if ~isempty(hm), h(end+1) = hm;  hl{end+1} = strrep(ms{m}, '_LS', ' (LS)'); end
    end
    xlim(ax, [0.5 numel(cl) + 0.5]);  ylim(ax, [0 105]);
    set(ax, 'XTick', 1:numel(cl), 'XTickLabel', sets{q,3});
    style_axes(ax, 'Cell', 'Hold-out accuracy (%)');
    lg = legend(ax, h, hl, 'Location', 'south', 'Orientation', 'horizontal');
    style_legend(lg);
    save_figure(fig, fullfile(fd, sets{q,1}));  close(fig);
    fprintf('written: %s\n', sets{q,1});
end
end
