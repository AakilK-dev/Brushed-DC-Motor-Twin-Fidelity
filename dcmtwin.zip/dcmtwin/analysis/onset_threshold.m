function thr = onset_threshold(T, Z, dirn, tMin, margin)
m = 0;
for r = 1:numel(Z)
    t = T{r}(:);  z = Z{r}(:);  k = t >= tMin & isfinite(z);
    switch dirn
        case  1, v = max(z(k));
        case -1, v = max(-z(k));
        otherwise, v = max(abs(z(k)));
    end
    if ~isempty(v), m = max(m, v); end
end
thr = margin*m;
end
