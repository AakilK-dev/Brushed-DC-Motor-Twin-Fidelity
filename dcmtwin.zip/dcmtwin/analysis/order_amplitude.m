function [amp, dc] = order_amplitude(y, th, orders)

th0  = th(1);
nrev = floor((th(end) - th0)/(2*pi));
k1   = find(th >= th0 + nrev*2*pi, 1, 'first');
yy   = y(1:k1);
tt   = th(1:k1) - th0;
dth  = gradient(tt);
W    = sum(dth);
dc   = sum(yy.*dth)/W;
amp  = zeros(size(orders));
for m = 1:numel(orders)
    c = sum(yy.*cos(orders(m)*tt).*dth)/W;
    s = sum(yy.*sin(orders(m)*tt).*dth)/W;
    amp(m) = 2*hypot(c, s);
end
end
