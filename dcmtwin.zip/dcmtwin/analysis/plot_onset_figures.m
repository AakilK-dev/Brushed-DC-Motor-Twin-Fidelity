function plot_onset_figures(outdir, Zs)

S = fig_style();  fd = fullfile(outdir, 'figures');  if ~exist(fd, 'dir'), mkdir(fd); end
L = load(fullfile(outdir, 'results', 'onset.mat'), 'R', 'thr', 'stats', 'S');
R = L.R;  thr = L.thr;  stats = L.stats;  Ses = L.S;
tPer = 0.1;  Tw = 0.25;  hop = 0.05;
faults = {'resistive', 'shorted_bar', 'bearing_outer', 'imbalance'};
files  = {'resistive', 'shorted_bar', 'bearing', 'imbalance'};
own = [1 2 6 5];
sco = find(~Ses.calib);
D = nan(numel(sco), 4);  Rk = cell(1, 4);
for f = 1:4
    k = find([R.twin] == 2 & strcmp({R.fault}, faults{f}), 1);  Rk{f} = R(k);  D(:, f) = R(k).delay(:);
end
md = zeros(1, 4);  for f = 1:4, md(f) = median(D(~isnan(D(:,f)), f)); end
[~, jj] = min(sum(abs(D - repmat(md, size(D, 1), 1))./repmat(md, size(D, 1), 1), 2));
j = sco(jj);
if nargin < 2 || isempty(Zs)
    recs = session_stats(outdir, Ses.session(j), 2, Tw, hop);
    for f = 1:4
        rr = recs(2 + f);  aPost = inf(1, size(stats, 1));
        for s = 1:size(stats, 1)
            a1 = onset_alarm(rr.t{s}, rr.z{s}, thr(2, s), stats{s, 2}, tPer, rr.onset);
            if ~isnan(a1), aPost(s) = a1; end
        end
        m = min(aPost);  if isfinite(m), dl = m - rr.onset; else, dl = NaN; end
        if ~((isnan(dl) && isnan(D(jj, f))) || abs(dl - D(jj, f)) <= 1e-9)
            error('plot_onset_figures:check', ['the %s record of session %d, re-formed from the saved records and estimates, ' ...
                  'gives a delay of %.4f s against %.4f s saved by run_onset'], faults{f}, Ses.session(j), dl, D(jj, f));
        end
    end
    fprintf('onset figures: session %d''s statistics re-formed from its saved records and Model 2''s saved estimates; its four delays match the saved results\n', Ses.session(j));
else
    recs = Zs{j, 2};
end

lab = {'Resistance estimate, R', 'Back EMF constant estimate, K_e', 'Envelope at the outer-race order', ...
       'Once-per-revolution vibration'};
dlo = nan(1, 4);
for f = 1:4
    r = recs(2 + f);  s = own(f);
    t = double(r.t{s}(:)) - r.onset;  z = double(r.z{s}(:))/thr(2, s);
    if stats{s, 2} == 0, z = abs(z); end
    z = max(z, 1e-2);  in = t >= -0.5 & t <= 1;
    [fig, ax] = new_figure();
    plot(ax, [0 0], [1e-2 1e3], ':', 'Color', S.dark, 'LineWidth', S.ref, 'HandleVisibility', 'off');
    h = plot(ax, t(in), z(in), '-', 'Color', S.black, 'LineWidth', S.line);
    h(2) = plot(ax, [-0.5 1], [1 1], '--', 'Color', S.dark, 'LineWidth', S.ref);
    hl = {lab{f}, 'Threshold'};
    a = onset_alarm(r.t{s}, r.z{s}, thr(2, s), stats{s, 2}, tPer, r.onset);
    if ~isnan(a)
        dlo(f) = a - r.onset;
        h(3) = plot(ax, dlo(f), interp1(t, z, dlo(f)), 'o', 'Color', S.black, 'MarkerFaceColor', S.black, ...
                    'MarkerEdgeColor', 'w', 'MarkerSize', S.marker + 3);
        hl{3} = sprintf('Alarm, %.2f s after onset', dlo(f));
    end
    set(ax, 'YScale', 'log');  xlim(ax, [-0.5 1]);  ylim(ax, [1e-2 1e3]);
    style_axes(ax, 'Time from the fault''s onset (s)', 'Statistic relative to its threshold');
    style_legend(legend(ax, h, hl, 'Location', 'southeast'));
    save_figure(fig, fullfile(fd, ['fig_onset_traces_' files{f}]));  close(fig);
end
fprintf('written: fig_onset_traces_* (session %d, Model 2''s filter; each statistic''s own delay %s s)\n', ...
        Ses.session(j), sprintf('%.2f ', dlo));

lims = struct('resistive', [0.02 0.30], 'shorted_bar', [0.1 1.0], 'bearing_outer', [0.05 1.0], 'imbalance', [5e-6 2.5e-5]);
mk = {'o', 's', '^', 'd'};  lab2 = {'Resistive', 'Shorted bar', 'Bearing defect', 'Imbalance'};
ymax = 0;
for f = 1:4, r = Rk{f};  ymax = max([ymax; r.delay(r.detected(:))]); end
yt = 1.1*max(ymax, 0.5);
for f = 1:4
    r = Rk{f};  lm = lims.(r.fault);  x = (r.sev(:) - lm(1))/diff(lm);  dtc = logical(r.detected(:));  dl = r.delay(:);
    [fig, ax] = new_figure();
    h = plot(ax, x(dtc), dl(dtc), mk{f}, 'Color', S.black, 'MarkerFaceColor', 'w', 'MarkerSize', S.marker, 'LineWidth', 1.5);
    hl = {sprintf('%s, Model 2''s filter', lab2{f})};
    if any(~dtc)
        h(2) = plot(ax, x(~dtc), yt*ones(nnz(~dtc), 1), 'x', 'Color', S.black, 'MarkerSize', S.marker + 2, 'LineWidth', 2);
        hl{2} = 'Missed, drawn at the top';
    end
    xlim(ax, [-0.03 1.03]);  ylim(ax, [0 1.15*yt]);
    style_axes(ax, 'Severity, fraction of its range', 'Detection delay after onset (s)');
    style_legend(legend(ax, h, hl, 'Location', 'northeast'));
    save_figure(fig, fullfile(fd, ['fig_onset_delay_' files{f}]));  close(fig);
    fprintf('written: fig_onset_delay_%s (%d of %d detected; median delay %.2f s)\n', files{f}, nnz(dtc), numel(dtc), median(dl(dtc)));
end
end

function recs = session_stats(outdir, session, tw, Tw, hop)
X = load(fullfile(outdir, 'datasets', 'onset_M3', sprintf('session_%04d.mat', session)), 'X');  X = X.X;
Vb = windowed_vibration(X.runs(1).rec, Tw, hop);
vb = struct('vrms', median(Vb.vrms), 'v1', median(Vb.v1), 'env', median(Vb.env));
V = cell(1, numel(X.runs));
for i = 1:numel(X.runs), V{i} = windowed_vibration(X.runs(i).rec, Tw, hop); end
E = load(fullfile(outdir, 'estimates', sprintf('onset_T%d', tw), sprintf('session_%04d.mat', session)), 'Z');  Y = E.Z.runs;
fb = Y(1).final;
recs = struct('t', {}, 'z', {}, 'state', {}, 'sev', {}, 'onset', {});
for i = 1:numel(Y)
    tf = double(Y(i).t) + Y(i).tStart;  x = double(Y(i).x);
    rr = struct();
    rr.t = {tf, tf, tf, V{i}.t, V{i}.t, V{i}.t};
    rr.z = {(x(:,4) - fb.R)/fb.R, (x(:,5) - fb.Ke)/fb.Ke, (x(:,6) - fb.b)/fb.b, ...
            log(V{i}.vrms/vb.vrms), V{i}.v1 - vb.v1, log(V{i}.env/vb.env)};
    rr.state = X.runs(i).state;  rr.sev = X.runs(i).severity;  rr.onset = X.runs(i).onset;
    recs(i) = rr;
end
end
