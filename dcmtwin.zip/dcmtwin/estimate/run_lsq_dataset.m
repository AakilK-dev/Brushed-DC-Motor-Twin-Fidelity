function C = run_lsq_dataset(outdir, dataModel, planName)

if nargin < 3 || isempty(planName), planName = 'sessions'; end
isHold = strcmpi(planName, 'holdout');
if isHold && dataModel ~= 3, error('run_lsq_dataset:holdout', 'hold-out records exist for the reference (model 3) only'); end
p  = params_default();  TL = p.TLfrac*p.Kt*p.Irated;
o  = struct('fsE', 2000, 'fc', 400, 'tSkip', 0.5, 'win', 0.01, 'hSpeed', 0.005);
if isHold
    planFile = 'holdout_sessions.mat';
    src = fullfile(outdir, 'datasets', 'holdout_M3');  dd = fullfile(outdir, 'estimates', 'holdout_LS');
else
    planFile = 'sessions.mat';
    src = fullfile(outdir, 'datasets', sprintf('M%d', dataModel));
    dd  = fullfile(outdir, 'estimates', sprintf('LS_D%d', dataModel));
end
L = load(fullfile(outdir, 'datasets', planFile), 'S');  S = tab_cols(L.S);  sess = S.session(:);  nS = numel(sess);
if ~exist(dd, 'dir'), mkdir(dd); end
prov = struct('o', o, 'TL', TL);
done = false(nS, 1);
for j = 1:nS
    fj = fullfile(dd, sprintf('session_%04d.mat', sess(j)));
    if exist(fj, 'file') ~= 2, continue; end
    try, Lj = load(fj, 'Z');  done(j) = isequaln(Lj.Z.prov, prov); catch, done(j) = false; end
    if ~done(j), delete(fj); end
end
fprintf('\nLeast-squares estimator on the Model %d %s records: %d sessions, %d already finished\n', ...
        dataModel, ifelse(isHold, 'hold-out', 'diagnosis'), nS, nnz(done));
t0 = tic;
parfor j = 1:nS
    if done(j), continue; end
    Lx = load(fullfile(src, sprintf('session_%04d.mat', sess(j))), 'X');  X = Lx.X;
    runs = struct('state', {}, 'severity', {}, 'final', {}, 'diag', {}, 'truth', {});
    for i = 1:numel(X.runs)
        E = lsq_estimate(X.runs(i).rec, TL, o);
        runs(i) = struct('state', X.runs(i).state, 'severity', X.runs(i).severity, ...
                         'final', E.final, 'diag', E.diag, 'truth', X.runs(i).truth);
    end
    Z = struct('session', sess(j), 'dataModel', dataModel, 'prov', prov, 'runs', runs);
    save_atomic(fullfile(dd, sprintf('session_%04d.mat', sess(j))), Z);
end
fprintf('Done in %.1f min: %s\n', toc(t0)/60, dd);
C = check_lsq(dd, sess, dataModel, p);
end

function C = check_lsq(dd, sess, dataModel, p)
st = {};  sev = [];  D = [];  Hr = [];  Ea = [];  Ef = [];
for j = 1:numel(sess)
    L = load(fullfile(dd, sprintf('session_%04d.mat', sess(j))), 'Z');  R = L.Z.runs;  b = R(1).final;
    for i = 1:numel(R)
        e = R(i).final;  t = R(i).truth;
        if i > 1
            st{end+1, 1} = R(i).state;  sev(end+1, 1) = R(i).severity;
            D(end+1, :) = [e.R/b.R - 1, e.Ke/b.Ke - 1, e.L/b.L - 1, e.Tf - b.Tf];
            Hr(end+1, 1) = e.h2/b.h2;
        end
        if any(strcmp(R(i).state, {'baseline', 'healthy'}))
            Ea(end+1, :) = [e.R/t.R, e.Ke/t.Ke, e.L/t.L] - 1;
        end
        Ef(end+1, 1) = e.Tf - (t.TL - p.TLfrac*p.Kt*p.Irated) - (t.b*R(i).diag.wMean + t.Tc);
    end
end
C.absErr = [median(Ea, 1); prctile(abs(Ea), 95, 1)];
C.TfErr  = [median(Ef), prctile(abs(Ef), 95)];
fprintf('\nLeast squares on the Model %d records: error against the truth, baseline and normal runs\n', dataModel);
fprintf('%-26s %9s %9s %9s\n', '', 'R', 'Ke', 'L');
fprintf('%-26s %8.3f%% %8.3f%% %8.3f%%\n', 'median error', 100*C.absErr(1,:));
fprintf('%-26s %8.3f%% %8.3f%% %8.3f%%\n', '95% of |error| below', 100*C.absErr(2,:));
fprintf('Friction torque against b w + Tc + brake offset, every run: median %+.2f mN.m, 95%% of |error| below %.2f mN.m\n', ...
        1e3*C.TfErr(1), 1e3*C.TfErr(2));
fprintf('\nMedian change from baseline (percent; friction torque in mN.m; harmonic as a ratio)\n');
fprintf('%-14s %9s %9s %9s %9s %10s\n', 'run', 'R', 'Ke', 'L', 'Tf', 'harmonic');
for s = {'healthy','resistive','shorted_bar','bearing_outer','imbalance'}
    k = strcmp(st, s{1});  if ~any(k), continue; end
    md = median(D(k,:), 1);
    fprintf('%-14s %9.3f %9.4f %9.3f %9.3f %9.2fx\n', strrep(s{1}, 'healthy', 'normal'), 100*md(1:3), 1e3*md(4), median(Hr(k)));
end
kN = strcmp(st, 'healthy');
thr = prctile(abs(D(kN,:)), 99, 1);  thrH = prctile(abs(log(Hr(kN))), 99);
C.thr = [thr, thrH];
fprintf('\nNormal-run thresholds (99th percentile of |change|): R %.3f%%, Ke %.4f%%, L %.3f%%, Tf %.3f mN.m, harmonic x%.2f\n', ...
        100*thr(1:3), 1e3*thr(4), exp(thrH));
fprintf('\nFraction detected by the fault''s own signature, by severity third\n');
fprintf('%-14s %-22s %9s %9s %9s\n', 'fault', 'signature', 'small', 'middle', 'large');
spec = {'resistive', 'R rises', 1, 1;  'shorted_bar', 'Ke falls', 2, -1;  'bearing_outer', 'friction rises', 4, 1};
C.det = nan(size(spec,1), 3);
for r = 1:size(spec,1)
    k = strcmp(st, spec{r,1});  if ~any(k), continue; end
    s = sev(k);  det = spec{r,4}*D(k, spec{r,3}) > thr(spec{r,3});
    e = quantile(s, [0 1/3 2/3 1]);
    for b3 = 1:3, in = s >= e(b3) & s <= e(b3+1);  C.det(r, b3) = mean(det(in)); end
    fprintf('%-14s %-22s %8.0f%% %8.0f%% %8.0f%%\n', spec{r,1}, spec{r,2}, 100*C.det(r,:));
end
fprintf('\n');
end

function save_atomic(f, Z)
[d, n] = fileparts(f);  tmp = fullfile(d, ['tmp_' n '.mat']);
save(tmp, 'Z', '-v7');  movefile(tmp, f);
end

function v = ifelse(c, a, b)
if c, v = a; else, v = b; end
end
