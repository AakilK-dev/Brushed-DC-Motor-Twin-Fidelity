function o = ekf_defaults()

o.fsE   = 2000;
o.fc    = 400;
o.estL  = true;
o.harm  = true;
o.tStart = 0.05;
o.tAvg  = 1.0;
o.tSkip = 0.5;
o.sig_i  = 5e-3;
o.sig_th = 5e-4;
o.q_i   = 0.05;
o.q_w   = 2.0;
o.q_th  = 1e-4;
o.q_R   = 1e-3;
o.q_Ke  = 1e-4;
o.q_b   = 0.01;
o.q_L   = 1e-3;
o.q_h   = 0.002;
o.p0_R  = 0.15;  o.p0_Ke = 0.03;  o.p0_b = 0.5;  o.p0_L = 0.10;
o.p0_h  = 0.1;
end
