function E = lsq_estimate(rec, TL, o)

if nargin < 3 || isempty(o), o = struct(); end
o = defaults(o, 'fsE', 2000, 'fc', 400, 'tSkip', 0.5, 'win', 0.01, 'hSpeed', 0.005);
fs = rec.cur.fs;  m = round(fs/o.fsE);  dt = m/fs;
[bf, af] = butter(4, o.fc/(fs/2));
iF = filtfilt(bf, af, double(rec.cur.y(:)));
vF = filtfilt(bf, af, double(rec.vsup.y(:)));
tF = filtfilt(bf, af, double(rec.enc.y(:)));
N0 = min([numel(iF), numel(vF), numel(tF)]);  iF = iF(1:N0);  vF = vF(1:N0);  tF = tF(1:N0);
cV = [0; cumsum((vF(1:end-1) + vF(2:end))/2)]/fs;
cI = [0; cumsum((iF(1:end-1) + iF(2:end))/2)]/fs;
ii = iF(1:m:end);  th = tF(1:m:end);  cV = cV(1:m:end);  cI = cI(1:m:end);  N = numel(ii);
h  = max(1, round(o.hSpeed/dt));
k0 = round(o.tSkip/dt) + 1;  nw = round(o.win/dt);
nW = floor((N - h - k0)/nw);
if nW < 10, error('lsq_estimate:short', 'record too short for the span: %d windows', nW); end
a  = k0 + (0:nW-1)'*nw;  b = a + nw;
y  = cV(b) - cV(a);
X  = [cI(b) - cI(a), ii(b) - ii(a), th(b) - th(a), ...
      (sin(2*th(b)) - sin(2*th(a)))/2, -(cos(2*th(b)) - cos(2*th(a)))/2];
s  = sqrt(sum(X.^2, 1));  Xs = X./s;
c  = (Xs\y)./s(:);
r  = y - X*c;
R  = c(1);  L = c(2);  Ke = c(3);
w  = zeros(N, 1);  k = (1+h:N-h)';  w(k) = (th(k+h) - th(k-h))/(2*h*dt);
Dt = (b - a)*dt;
cm = [Dt, w(b) - w(a)]\(Ke*X(:,1) - TL*Dt);
ic = ii(k0:b(end)) - mean(ii(k0:b(end)));
E.final = struct('R', R, 'Ke', Ke, 'L', L, 'Tf', cm(1), 'J', cm(2), ...
                 'h2', abs(ordern(ic, th(k0:b(end)), 2)), 'rms', sqrt(mean(r.^2)), ...
                 'unexplained', sum(r.^2)/sum((y - mean(y)).^2), 'k2', hypot(c(4), c(5))/Ke);
E.diag = struct('nWin', nW, 'span', [(a(1)-1)*dt, (b(end)-1)*dt], 'cond', cond(Xs), ...
                'wMean', (th(b(end)) - th(a(1)))/((b(end) - a(1))*dt));
end

function c = ordern(x, th, n)
t0 = th(1);  nrev = floor((th(end) - t0)/(2*pi));
k  = th <= t0 + nrev*2*pi;  tt = th(k);  xx = x(k);  dth = gradient(tt);
c  = 2*sum(xx.*exp(-1i*n*tt).*dth)/sum(dth);
end

function o = defaults(o, varargin)
for k = 1:2:numel(varargin)
    if ~isfield(o, varargin{k}), o.(varargin{k}) = varargin{k+1}; end
end
end
