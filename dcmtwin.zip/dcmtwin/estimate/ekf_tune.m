function F = ekf_tune(outdir)

p   = params_default();  TLn = p.TLfrac*p.Kt*p.Irated;
L   = load(fullfile(outdir, 'datasets', 'tuning_sessions.mat'), 'S');  S = L.S;
L   = load(fullfile(outdir, 'calibration.mat'), 'T');                   Tcal = L.T;
dd  = fullfile(outdir, 'datasets', 'tuning_M3');
cand = [2 3 5 7 10]*1e-3;
for k = 1:height(S)
    L = load(fullfile(dd, sprintf('session_%04d.mat', S.session(k))), 'X');  runs{k} = L.X.runs;
end
for model = [1 2]
    fprintf('\nModel %d filter on %d normal reference runs from %d reserve machines\n', model, 2*height(S), height(S));
    fprintf('%9s %9s | %9s %9s %9s %9s | %10s\n', 'sigma_i', 'mean NIS', 'scatter R', 'Ke', 'L', 'b', 'R settles');
    res = zeros(numel(cand), 6);
    for c = 1:numel(cand)
        o = ekf_defaults();  o.sig_i = cand(c);
        nisAll = [];  sc = zeros(height(S), 4);  ts = zeros(height(S), 1);
        for k = 1:height(S)
            [q, ~] = calibrated_twin(p, Tcal(Tcal.machine == S.machine(k), :), model);
            q.J = q.J + p.brake.J;  q.TL = TLn;
            E1 = ekf_twin(runs{k}(1).rec, q, model, o);
            E2 = ekf_twin(runs{k}(2).rec, q, model, o);
            nisAll(end+1:end+2) = [E1.innov.meanNIS, E2.innov.meanNIS];
            f1 = E1.final;  f2 = E2.final;
            sc(k,:) = abs([f2.R/f1.R, f2.Ke/f1.Ke, f2.L/f1.L, f2.b/f1.b] - 1);
            r = E1.x(:,4);  kk = find(abs(r/f1.R - 1) > 0.002, 1, 'last');
            if isempty(kk), ts(k) = 0; else, ts(k) = E1.t(min(kk+1, numel(E1.t))); end
        end
        res(c,:) = [mean(nisAll), 100*median(sc, 1), median(ts)];
        fprintf('%7.1f mA %9.2f | %8.3f%% %8.4f%% %8.3f%% %8.3f%% | %8.2f s\n', 1e3*cand(c), res(c,:));
    end
    [~, best] = min(abs(res(:,1) - 2));
    o = ekf_defaults();  o.sig_i = cand(best);
    F.(sprintf('o%d', model)) = o;
    F.(sprintf('table%d', model)) = array2table([1e3*cand(:), res], 'VariableNames', ...
        {'sigma_i_mA','meanNIS','scatterR_pct','scatterKe_pct','scatterL_pct','scatterb_pct','settleR_s'});
    fprintf('FROZEN for Model %d: sigma_i = %.1f mA (mean NIS %.2f)\n', model, 1e3*cand(best), res(best,1));
end
F.date = datestr(now);  F.note = 'Frozen after tuning on reserve machines; do not change for dataset runs.';
save(fullfile(outdir, 'ekf_settings.mat'), 'F');
fprintf('\nSaved %s\n\n', fullfile(outdir, 'ekf_settings.mat'));
end
