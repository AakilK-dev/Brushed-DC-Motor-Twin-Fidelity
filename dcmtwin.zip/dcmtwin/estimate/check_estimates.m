function T = check_estimates(outdir, dataModel, twinModel)

dd = fullfile(outdir, 'estimates', sprintf('D%d_T%d', dataModel, twinModel));
F  = dir(fullfile(dd, 'session_*.mat'));
rows = {};
for f = 1:numel(F)
    L = load(fullfile(dd, F(f).name), 'Z');  Z = L.Z;
    b = Z.runs(1).final;
    for i = 2:numel(Z.runs)
        e = Z.runs(i).final;
        d = [e.R/b.R, e.Ke/b.Ke, e.L/b.L, e.b/b.b] - 1;
        rows(end+1,:) = {Z.runs(i).state, Z.runs(i).severity, d, e.h2/b.h2};
    end
end
st = rows(:,1);  sev = cell2mat(rows(:,2));  D = cell2mat(rows(:,3));  H = cell2mat(rows(:,4));
fprintf('\nModel %d filter on the Model %d dataset: %d sessions\n', twinModel, dataModel, numel(F));
fprintf('\nMedian change from baseline (percent; harmonic as a ratio)\n');
fprintf('%-14s %9s %9s %9s %9s %10s\n', 'run', 'R', 'Ke', 'L', 'b', 'harmonic');
for s = {'healthy','resistive','shorted_bar','bearing_outer','imbalance'}
    k = strcmp(st, s{1});  if ~any(k), continue; end
    fprintf('%-14s %9.3f %9.4f %9.3f %9.2f %9.2fx\n', s{1}, 100*median(D(k,:),1), median(H(k)));
end
kN = strcmp(st, 'healthy');
thr = prctile(abs(D(kN,:)), 99, 1);  thrH = prctile(abs(log(H(kN))), 99);
fprintf('\nNormal-run thresholds (99th percentile of |change|): R %.3f%%, Ke %.4f%%, L %.3f%%, b %.1f%%, harmonic x%.2f\n', ...
        100*thr, exp(thrH));
fprintf('\nFraction detected by the fault''s own signature, by severity third\n');
fprintf('%-14s %-22s %9s %9s %9s\n', 'fault', 'signature', 'small', 'middle', 'large');
spec = {'resistive','R rises', @(d,h) d(:,1) > thr(1);
        'shorted_bar','Ke falls', @(d,h) d(:,2) < -thr(2);
        'shorted_bar','harmonic grows', @(d,h) log(h) > thrH;
        'bearing_outer','friction rises', @(d,h) d(:,4) > thr(4)};
T = table();
for r = 1:size(spec,1)
    k = strcmp(st, spec{r,1});  if ~any(k), continue; end
    s = sev(k);  det = spec{r,3}(D(k,:), H(k));
    edges = quantile(s, [0 1/3 2/3 1]);
    frac = zeros(1,3);
    for b3 = 1:3
        in = s >= edges(b3) & s <= edges(b3+1);  frac(b3) = mean(det(in));
    end
    fprintf('%-14s %-22s %8.0f%% %8.0f%% %8.0f%%\n', spec{r,1}, spec{r,2}, 100*frac);
    T = [T; table(string(spec{r,1}), string(spec{r,2}), frac(1), frac(2), frac(3), ...
         'VariableNames', {'fault','signature','small','middle','large'})];
end
fprintf('\n');
end
