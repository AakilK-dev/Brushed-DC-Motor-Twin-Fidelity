function R = ekf_matched_check(outdir, model, nS)

if nargin < 3 || isempty(nS), nS = 10; end
p   = params_default();  TLn = p.TLfrac*p.Kt*p.Irated;
L   = load(fullfile(outdir, 'datasets', 'sessions.mat'), 'S');   S = L.S;
L   = load(fullfile(outdir, 'calibration.mat'), 'T');             Tcal = L.T;
dd  = fullfile(outdir, 'datasets', sprintf('M%d', model));
rows = {};  t0 = tic;  nRun = 0;
for j = 1:nS
    X  = load(fullfile(dd, sprintf('session_%04d.mat', S.session(j))), 'X');  X = X.X;
    [q, ~] = calibrated_twin(p, Tcal(Tcal.machine == S.machine(j), :), model);
    q.J = q.J + p.brake.J;  q.TL = TLn;
    Eb = [];  tb = [];
    for i = 1:numel(X.runs)
        r  = X.runs(i);  tr = r.truth;
        E  = ekf_twin(r.rec, q, model);  nRun = nRun + 1;
        wbar = mean(E.x(E.t >= E.t(end) - 1, 2));
        beff = tr.b + (tr.TL - TLn)/wbar;
        e = [E.final.R/tr.R, E.final.Ke/tr.Ke, E.final.L/tr.L, E.final.b/beff] - 1;
        if strcmp(r.state, 'baseline'), Eb = E;  tb = tr;  dE = nan(1,4);  dT = nan(1,4);
        else
            dE = [E.final.R/Eb.final.R, E.final.Ke/Eb.final.Ke, E.final.L/Eb.final.L, E.final.b/Eb.final.b] - 1;
            dT = [tr.R/tb.R, tr.Ke/tb.Ke, tr.L/tb.L, tr.b/tb.b] - 1;
        end
        rows(end+1, :) = {r.state, e, E.innov.meanNIS, dE, dT};
    end
end
st = rows(:,1);  E_ = cell2mat(rows(:,2));  nis = cell2mat(rows(:,3));
dE_ = cell2mat(rows(:,4));  dT_ = cell2mat(rows(:,5));
fprintf('\nModel %d filter on the Model %d dataset: %d sessions, %d runs, %.1f s per run\n', ...
        model, model, nS, nRun, toc(t0)/nRun);
fprintf('\nError of the final estimates, median of |error| in percent\n');
fprintf('%-14s %8s %8s %8s %12s %8s\n', 'run', 'R', 'Ke', 'L', 'b effective', 'NIS');
for s = unique(st, 'stable')'
    k = strcmp(st, s{1});
    fprintf('%-14s %8.3f %8.4f %8.2f %12.2f %8.2f\n', s{1}, 100*median(abs(E_(k,:)), 1), median(nis(k)));
end
fprintf('\nEstimated change from the session baseline against the true change, median, percent\n');
fprintf('%-14s %16s %16s %16s %16s\n', 'fault', 'R est / true', 'Ke est / true', 'L est / true', 'b est / true');
for s = {'resistive','shorted_bar','bearing_outer'}
    k = strcmp(st, s{1});  if ~any(k), continue; end
    fprintf('%-14s', s{1});
    for c = 1:4
        a = 100*median(dE_(k,c), 'omitnan');  b = 100*median(dT_(k,c), 'omitnan');
        fprintf(' %7.2f / %6.2f', a, b);
    end
    fprintf('\n');
end
fprintf(['\nThe bearing''s friction change includes the difference between the two runs'' ', ...
         'brake offsets,\nwhich the filter cannot separate from friction; R, Ke and L should be unaffected.\n\n']);
R = rows;
end
