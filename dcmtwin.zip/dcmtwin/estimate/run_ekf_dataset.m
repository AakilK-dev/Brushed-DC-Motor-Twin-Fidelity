function run_ekf_dataset(outdir, dataModel, twinModel, planName)

if nargin < 4 || isempty(planName), planName = 'sessions'; end
onsetPlan = strcmpi(planName, 'onset');
if onsetPlan && dataModel ~= 3, error('run_ekf_dataset:onset', 'onset records exist for the reference (model 3) only'); end
holdPlan = strcmpi(planName, 'holdout');
if holdPlan && dataModel ~= 3, error('run_ekf_dataset:holdout', 'hold-out records exist for the reference (model 3) only'); end
f = fullfile(outdir, 'ekf_settings.mat');
if ~exist(f, 'file'), error('run_ekf_dataset:untuned', 'Run ekf_tune first: no frozen settings in %s', f); end
L = load(f, 'F');  o = L.F.(sprintf('o%d', twinModel));  tuned = L.F.date;
p   = params_default();  TLn = p.TLfrac*p.Kt*p.Irated;
if onsetPlan, planFile = 'onset_sessions.mat'; else, planFile = 'sessions.mat'; end
if holdPlan, planFile = 'holdout_sessions.mat'; end
L   = load(fullfile(outdir, 'datasets', planFile), 'S');   S = L.S;
L   = load(fullfile(outdir, 'calibration.mat'), 'T');             Tcal = L.T;
if onsetPlan
    src = fullfile(outdir, 'datasets', 'onset_M3');
    dd  = fullfile(outdir, 'estimates', sprintf('onset_T%d', twinModel));
else
    src = fullfile(outdir, 'datasets', sprintf('M%d', dataModel));
    dd  = fullfile(outdir, 'estimates', sprintf('D%d_T%d', dataModel, twinModel));
end
if holdPlan
    src = fullfile(outdir, 'datasets', 'holdout_M3');
    dd  = fullfile(outdir, 'estimates', sprintf('holdout_T%d', twinModel));
end
if ~exist(dd, 'dir'), mkdir(dd); end
nS = height(S);
done = false(nS, 1);  nStale = 0;
for j = 1:nS
    fj = fullfile(dd, sprintf('session_%04d.mat', S.session(j)));
    if exist(fj, 'file') ~= 2, continue; end
    try
        Lj = load(fj, 'Z');
        done(j) = isfield(Lj.Z, 'tuned') && strcmp(Lj.Z.tuned, tuned) && isequal(Lj.Z.settings, o);
    catch
        done(j) = false;
    end
    if ~done(j), delete(fj);  nStale = nStale + 1; end
end
fprintf('\nModel %d filter on the Model %d dataset: %d sessions, %d already finished with the current settings, %d stale files removed.\n', ...
        twinModel, dataModel, nS, sum(done), nStale);
t0 = tic;
parfor j = 1:nS
    if done(j), continue; end
    L = load(fullfile(src, sprintf('session_%04d.mat', S.session(j))), 'X');  X = L.X;
    [q, ~] = calibrated_twin(p, Tcal(Tcal.machine == S.machine(j), :), twinModel);
    q.J = q.J + p.brake.J;  q.TL = TLn;
    Y = struct('state',{},'severity',{},'final',{},'innov',{},'t',{},'x',{});
    if onsetPlan, Y = struct('state',{},'severity',{},'final',{},'innov',{},'t',{},'x',{},'onset',{},'tStart',{}); end
    for i = 1:numel(X.runs)
        E = ekf_twin(X.runs(i).rec, q, twinModel, o);
        if onsetPlan
            Y(i) = struct('state', X.runs(i).state, 'severity', X.runs(i).severity, 'final', E.final, ...
                          'innov', E.innov, 't', single(E.t), 'x', single(E.x), ...
                          'onset', X.runs(i).onset, 'tStart', o.tStart);
        else
            Y(i) = struct('state', X.runs(i).state, 'severity', X.runs(i).severity, 'final', E.final, ...
                          'innov', E.innov, 't', single(E.t), 'x', single(E.x));
        end
    end
    Z = struct('session', S(j,:), 'dataModel', dataModel, 'twinModel', twinModel, 'settings', o, ...
               'tuned', tuned, 'runs', Y);
    save_atomic(fullfile(dd, sprintf('session_%04d.mat', S.session(j))), Z);
end
fprintf('Done in %.1f min: %s\n\n', toc(t0)/60, dd);
end

function save_atomic(f, Z)
[d, n] = fileparts(f);  tmp = fullfile(d, ['tmp_' n '.mat']);
save(tmp, 'Z', '-v7');  movefile(tmp, f);
end
