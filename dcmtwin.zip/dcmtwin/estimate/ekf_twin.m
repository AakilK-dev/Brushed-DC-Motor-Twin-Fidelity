function E = ekf_twin(rec, q, model, o)

if nargin < 4 || isempty(o), o = ekf_defaults(); end
fs = rec.cur.fs;  m = round(fs/o.fsE);  dt = m/fs;
[bf, af] = butter(4, o.fc/(fs/2));
ii = filtfilt(bf, af, double(rec.cur.y(:)));    ii = ii(1:m:end);
VV = filtfilt(bf, af, double(rec.vsup.y(:)));   VV = VV(1:m:end);
th = filtfilt(bf, af, double(rec.enc.y(:)));    th = th(1:m:end);
N  = min([numel(ii), numel(VV), numel(th)]);
k0 = round(o.tStart/dt) + 1;
ii = ii(k0:N);  VV = VV(k0:N);  th = th(k0:N);  N = N - k0 + 1;
J = q.J;  TL = q.TL;  wt = q.wt;
if model == 2, Tc = q.Tc; b0 = q.b; else, Tc = 0; b0 = q.b_lin; end
harm = isfield(o,'harm') && o.harm;
nx = 6 + o.estL + 2*harm;  np_ = 6 + o.estL;  ih = np_ + 1;
w0 = (th(min(21, N)) - th(1))/((min(21, N) - 1)*dt);
x  = [ii(1); w0; th(1); q.R; q.Ke; b0];
if o.estL, x(7) = q.L; end
if harm, x(ih:ih+1) = 0; end
P  = diag([0.05^2, 2^2, (5e-4)^2, (o.p0_R*q.R)^2, (o.p0_Ke*q.Ke)^2, (o.p0_b*b0)^2]);
if o.estL, P(7,7) = (o.p0_L*q.L)^2; end
if harm, P(ih,ih) = o.p0_h^2;  P(ih+1,ih+1) = o.p0_h^2; end
qc = [o.q_i^2, o.q_w^2, o.q_th^2, (o.q_R*q.R)^2, (o.q_Ke*q.Ke)^2, (o.q_b*b0)^2];
if o.estL, qc(7) = (o.q_L*q.L)^2; end
if harm, qc(ih:ih+1) = o.q_h^2; end
Qd = diag(qc)*dt;
Rm = diag([o.sig_i^2, o.sig_th^2]);
H  = zeros(2, nx);  H(1,1) = 1;  H(2,3) = 1;
I  = eye(nx);
ks = max(1, round(0.01/dt));
nS = floor((N - 1)/ks) + 1;
E.t = zeros(nS,1);  E.x = zeros(nS, nx);  E.sd = zeros(nS, nx);
nu = zeros(N, 2);  nis = zeros(N, 1);
s = 1;  E.t(1) = 0;  E.x(1,:) = x';  E.sd(1,:) = sqrt(diag(P))';
failed = false;  failTime = NaN;  failState = nan(1, nx);
for k = 1:N-1
    V  = VV(k);  Vm = (VV(k) + VV(k+1))/2;  V1 = VV(k+1);
    k1 = f(x, V);  k2 = f(x + dt/2*k1, Vm);  k3 = f(x + dt/2*k2, Vm);  k4 = f(x + dt*k3, V1);
    xp = x + dt/6*(k1 + 2*k2 + 2*k3 + k4);
    A  = jac(x, V);  Ad = A*dt;
    F  = I + Ad + Ad*Ad/2;
    P  = F*P*F' + Qd;
    if ~all(isfinite(xp)) || ~all(isfinite(P(:)))
        failed = true;  failTime = k*dt;  failState = x';  break
    end
    y  = [ii(k+1); th(k+1)];
    if harm
        c2 = cos(2*xp(3));  s2 = sin(2*xp(3));
        H(1, ih) = c2;  H(1, ih+1) = s2;
        v  = y - [xp(1) + xp(ih)*c2 + xp(ih+1)*s2; xp(3)];
    else
        v  = y - H*xp;
    end
    S  = H*P*H' + Rm;
    K  = (P*H')/S;
    x  = xp + K*v;
    IKH = I - K*H;
    P  = IKH*P*IKH' + K*Rm*K';
    P  = (P + P')/2;
    x(4:np_) = max(x(4:np_), 1e-9);
    nu(k+1,:) = v';  nis(k+1) = v'*(S\v);
    if mod(k, ks) == 0
        s = s + 1;  E.t(s) = k*dt;  E.x(s,:) = x';  E.sd(s,:) = sqrt(diag(P))';
    end
end
E.t = E.t(1:s);  E.x = E.x(1:s,:);  E.sd = E.sd(1:s,:);
E.failed = failed;  E.failTime = failTime;  E.failState = failState;
names = {'R','Ke','b','L'};
if failed
    for j = 1:4, E.final.(names{j}) = NaN; end
    E.final.h2 = NaN;
    E.innov = struct('rms_i', NaN, 'rms_th', NaN, 'meanNIS', NaN, 'frac99', NaN);
    E.model = model;  E.estL = o.estL;  E.settings = o;
    return
end
kA = E.t >= E.t(end) - o.tAvg;
for j = 4:np_, E.final.(names{j-3}) = mean(E.x(kA, j)); end
if ~o.estL, E.final.L = q.L; end
if harm, E.final.h2 = hypot(mean(E.x(kA, ih)), mean(E.x(kA, ih+1))); else, E.final.h2 = NaN; end
kS = (0:N-1)'*dt >= o.tSkip;
E.innov.rms_i   = sqrt(mean(nu(kS,1).^2));
E.innov.rms_th  = sqrt(mean(nu(kS,2).^2));
E.innov.meanNIS = mean(nis(kS));
E.innov.frac99  = mean(nis(kS) > 9.21);
E.model = model;  E.estL = o.estL;  E.settings = o;

    function dx = f(x, V)
        L = q.L;  if o.estL, L = x(7); end
        i = x(1);  w = x(2);  R = x(4);  Ke = x(5);  b = x(6);
        dx = zeros(nx, 1);
        dx(1) = (V - R*i - Ke*w)/L;
        dx(2) = (Ke*i - b*w - (Tc + TL)*tanh(w/wt))/J;
        dx(3) = w;
    end
    function A = jac(x, V)
        L = q.L;  if o.estL, L = x(7); end
        i = x(1);  w = x(2);  R = x(4);  Ke = x(5);  b = x(6);
        A = zeros(nx);
        A(1,1) = -R/L;  A(1,2) = -Ke/L;  A(1,4) = -i/L;  A(1,5) = -w/L;
        if o.estL, A(1,7) = -(V - R*i - Ke*w)/L^2; end
        A(2,1) = Ke/J;
        A(2,2) = (-b - (Tc + TL)*(1/wt)*sech(w/wt)^2)/J;
        A(2,5) = i/J;  A(2,6) = -w/J;
        A(3,2) = 1;
    end
end
