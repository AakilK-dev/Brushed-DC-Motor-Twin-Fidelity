function F = ekf_find_failures(outdir, dataModel, twinModel)

L = load(fullfile(outdir, 'ekf_settings.mat'), 'F');  o = L.F.(sprintf('o%d', twinModel));
p   = params_default();  TLn = p.TLfrac*p.Kt*p.Irated;
L   = load(fullfile(outdir, 'datasets', 'sessions.mat'), 'S');   S = L.S;
L   = load(fullfile(outdir, 'calibration.mat'), 'T');             Tcal = L.T;
src = fullfile(outdir, 'datasets', sprintf('M%d', dataModel));
w1 = warning('off', 'MATLAB:singularMatrix');  w2 = warning('off', 'MATLAB:nearlySingularMatrix');
F = {};  nRun = 0;  t0 = tic;
for j = 1:height(S)
    L = load(fullfile(src, sprintf('session_%04d.mat', S.session(j))), 'X');  X = L.X;
    [q, ~] = calibrated_twin(p, Tcal(Tcal.machine == S.machine(j), :), twinModel);
    q.J = q.J + p.brake.J;  q.TL = TLn;
    for i = 1:numel(X.runs)
        E = ekf_twin(X.runs(i).rec, q, twinModel, o);  nRun = nRun + 1;
        if E.failed
            F(end+1, :) = {S.session(j), S.machine(j), S.duty(j), S.theta_degC(j), X.runs(i).state, ...
                           X.runs(i).severity, E.failTime, E.failState};
        end
    end
end
warning(w1);  warning(w2);
fprintf('\nModel %d filter on the Model %d dataset: %d runs in %.1f min, %d diverged\n', ...
        twinModel, dataModel, nRun, toc(t0)/60, size(F,1));
if isempty(F), fprintf('\n'); return; end
fprintf('%7s %7s %5s %7s  %-13s %8s %8s | last finite estimates: %9s %9s %9s %9s %9s\n', ...
        'session','machine','duty','theta','run','severity','fails at','w','R','Ke','b','L');
for r = 1:size(F,1)
    xs = F{r,8};
    fprintf('%7d %7d %4.0f%% %6.1fC  %-13s %8.3g %7.3f s | %9.1f %9.4f %9.5f %9.3g %9.3g\n', ...
        F{r,1}, F{r,2}, 100*F{r,3}, F{r,4}, F{r,5}, F{r,6}, F{r,7}, xs(2), xs(4), xs(5), xs(6), xs(min(7, numel(xs))));
end
fprintf('\n');
end
