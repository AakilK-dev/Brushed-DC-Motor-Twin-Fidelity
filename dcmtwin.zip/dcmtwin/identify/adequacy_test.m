function A = adequacy_test(outdir, nM)

p    = params_default();
cfg3 = cfg_model3();
L    = load(fullfile(outdir, 'calibration.mat'), 'T');  Tcal = L.T;
if nargin < 2 || isempty(nM), nM = height(Tcal); end

fr   = Tcal.true_Tc/p.Tc;
[~, ord] = sort(fr);
pick = ord(max(1, round(((1:nM) - 0.5)/nM*height(Tcal))));
ids  = Tcal.machine(pick);

TLs    = [0, p.TLfrac*p.Kt*p.Irated];
cnames = {'no load', '20% load'};
faults = {'resistive',     0.02,           0.16;
          'shorted_bar',   r_of_f(0.1, p), r_of_f(0.5, p);
          'bearing_outer', 0.05,           0.525;
          'imbalance',     5e-6,           1.5e-5};

jobs = [repmat((1:nM)', 2, 1), [ones(nM,1); 2*ones(nM,1)]];
fprintf('\nAdequacy test: %d machines, 2 load conditions, %d Model 3 runs ...\n', ...
        nM, size(jobs,1)*(2 + 2*size(faults,1)));
pdir = fullfile(outdir, 'adequacy_parts_service');
if ~exist(pdir, 'dir'), mkdir(pdir); end
stale = dir(fullfile(pdir, 'tmp_*.mat'));
for k = 1:numel(stale), delete(fullfile(pdir, stale(k).name)); end
nJ   = size(jobs,1);
prov = physics_provenance(p);
done = arrayfun(@(j) part_current(part_file(pdir, ids(jobs(j,1)), jobs(j,2)), prov), (1:nJ)');
fprintf('%d of %d jobs already finished with the current settings and will be loaded.\n', sum(done), nJ);
dq = parallel.pool.DataQueue;  t0 = tic;
progress_tick('reset', sum(done));
afterEach(dq, @(~) progress_tick('tick', nJ, t0));
res = cell(nJ, 1);
parfor j = 1:nJ
    m  = jobs(j,1);  c = jobs(j,2);
    f  = part_file(pdir, ids(m), c);
    if done(j)
        L2 = load(f, 'Tj');  res{j} = L2.Tj;
    else
        Tr = Tcal(Tcal.machine == ids(m), :);
        Tj = one_job(outdir, ids(m), TLs(c), cnames{c}, Tr, p, cfg3, faults);
        save_part(f, Tj, prov);
        res{j} = Tj;
        send(dq, j);
    end
end
A = vertcat(res{:});
writetable(A, fullfile(outdir, 'adequacy_results_service.csv'));

fprintf('\nFraction of machines for which each twin is adequate\n');
fprintf('%-10s %-14s %-9s   %-17s   %-17s\n', '', '', '', 'twin-supported', 'any channel');
fprintf('%-10s %-14s %-9s   %8s %8s   %8s %8s\n', 'condition', 'fault', 'severity', ...
        'Model 1', 'Model 2', 'Model 1', 'Model 2');
for c = 1:2
    for f = 1:size(faults,1)
        for lev = {'smallest','middle'}
            k  = strcmp(A.condition, cnames{c}) & strcmp(A.fault, faults{f,1}) & strcmp(A.level, lev{1});
            k1 = k & A.twin == 1;  k2 = k & A.twin == 2;
            fprintf('%-10s %-14s %-9s   %7.0f%% %7.0f%%   %7.0f%% %7.0f%%\n', cnames{c}, ...
                faults{f,1}, lev{1}, 100*mean(A.adequate_twin(k1)), 100*mean(A.adequate_twin(k2)), ...
                100*mean(A.adequate_any(k1)), 100*mean(A.adequate_any(k2)));
        end
    end
end
fprintf('\nWritten: adequacy_results_service.csv in %s\n\n', outdir);
end

function f = part_file(pdir, id, c)
f = fullfile(pdir, sprintf('part_%04d_%d.mat', id, c));
end

function progress_tick(mode, a, b)
persistent n
switch mode
    case 'reset', n = a;
    case 'tick'
        n = n + 1;
        fprintf('job %4d of %d done   elapsed %6.1f min\n', n, a, toc(b)/60);
end
end

function ok = part_current(f, prov)
ok = false;
if exist(f, 'file') ~= 2, return; end
w = whos('-file', f);
if ~any(strcmp({w.name}, 'prov')), return; end
L = load(f, 'prov');  ok = isequal(L.prov, prov);
end

function save_part(f, Tj, prov)
[d, n] = fileparts(f);
tmp = fullfile(d, ['tmp_' n '.mat']);
save(tmp, 'Tj', 'prov');
movefile(tmp, f);
end

function T = one_job(outdir, id, TL, cname, Tr, p, cfg3, faults)
L  = load(fullfile(outdir, sprintf('machine_%04d.mat', id)), 'R');  R = L.R;
loaded = TL > 0;
svseed = 700000 + 10*id + loaded;
qM = machine_params(p, R);  qM.machine = id;
[qM, ~] = service_mounting(qM, p, 7000000 + id);
q0 = service_conditions(qM, p, loaded, svseed);
Tp = 1.5;  Ts = 0.6;  tA = 0.5;  tS = 0.15;  V0 = 0.6*p.Vs;
pr = excitation('prbs','Vlo',V0*0.975,'Vhi',V0*1.025,'thold',0.05,'tEnd',Tp,'seed',3);
prof.V    = @(t) (t < Tp)*pr.V(min(t, Tp)) + (t >= Tp)*V0;
prof.open = @(t) false;
prof.name = 'prbs then constant';
W = struct('Ttot',Tp+Ts, 'dyn',[tA Tp], 'ss',[Tp+tS Tp+Ts]);
sseed = 900000 + 10*id + (TL > 0);
bseed = sseed + 5;

H     = sense(simulate(q0, cfg3, prof, W.Ttot, V0, bseed), q0, sseed, W);
qR    = service_conditions(qM, p, loaded, svseed + 1);
qR.eVs = q0.eVs;
noise = diffs(sense(simulate(qR, cfg3, prof, W.Ttot, V0, bseed + 1), qR, sseed + 1, W), H);
tw_   = (W.dyn(1):1e-4:W.dyn(2) - 1e-4)';
Vcmd  = mean(arrayfun(prof.V, tw_));
eVsHat = H.Vm/Vcmd - 1;
qA    = 2*pi/(p.enc.ppr*p.enc.quad);
noise.spd = max(noise.spd, sqrt(2)*qA/sqrt(12)/0.01);

ch  = {'curLP','spd','cur2x','vib','vib1x'};
cap = {logical([1 1 0 0 0]), logical([1 1 0 0 1])};
err = cell(1,2);
for tw = 1:2
    [qt, ct] = twin(p, Tr, tw);
    qt.eVs = eVsHat;
    if loaded
        qt.TL = p.TLfrac*p.Kt*p.Irated;  qt.J = qt.J + p.brake.J;
    end
    err{tw} = diffs(sense(simulate(qt, ct, prof, W.Ttot, V0, []), qt, sseed, W), H);
end

rows = {};  levname = {'smallest','middle'};
for f = 1:size(faults,1)
    for lev = 1:2
        qf  = apply_fault(q0, faults{f,1}, faults{f,1+lev});
        sig = diffs(sense(simulate(qf, cfg3, prof, W.Ttot, V0, bseed), qf, sseed, W), H);
        det = cellfun(@(n) sig.(n) > 2*noise.(n), ch);
        for tw = 1:2
            e   = err{tw};
            ok  = det & cellfun(@(n) e.(n) < sig.(n), ch);
            okT = ok & cap{tw};
            bestT = '';  if any(okT), bestT = ch{find(okT, 1)}; end
            bestA = '';  if any(ok),  bestA = ch{find(ok,  1)}; end
            rows(end+1,:) = {id, Tr.true_Tc/p.Tc, cname, tw, faults{f,1}, levname{lev}, ...
                faults{f,1+lev}, ...
                e.curLP, sig.curLP, noise.curLP, e.spd, sig.spd, noise.spd, ...
                e.cur2x, sig.cur2x, noise.cur2x, e.vib, sig.vib, noise.vib, ...
                e.vib1x, sig.vib1x, noise.vib1x, ...
                any(okT), bestT, any(ok), bestA};
        end
    end
end
T = cell2table(rows, 'VariableNames', {'machine','friction_factor','condition','twin', ...
    'fault','level','severity', ...
    'err_curLP','sig_curLP','noise_curLP', 'err_spd','sig_spd','noise_spd', ...
    'err_cur2x','sig_cur2x','noise_cur2x', 'err_vib','sig_vib','noise_vib', ...
    'err_vib1x','sig_vib1x','noise_vib1x', ...
    'adequate_twin','channel_twin','adequate_any','channel_any'});
end

function o = simulate(q, cfg, prof, T, V0, bseed)
x0 = steady_start(q, cfg, V0);
if cfg.bearing, q = make_bearing_noise(q, cfg, T, bseed); end
o  = run_sim(q, cfg, prof, T, x0);
end

function S = sense(o, q, seed, W)
s   = virtual_sensors(o, q, seed, {'cur','enc','acc','vsup'});
fs  = 1/(s.cur.t(2) - s.cur.t(1));
[bl, al] = butter(4, 50/(fs/2));
i   = double(s.cur.i);  iLP = filtfilt(bl, al, i);
th  = double(s.enc.theta);  m = round(0.005*fs);  n = numel(th);
w   = nan(n,1);  j = (m+1:n-m)';  w(j) = (th(j+m) - th(j-m))*fs/(2*m);
t   = s.cur.t;
kd  = t >= W.dyn(1) & t < W.dyn(2) & ~isnan(w);
S.iLP = iLP(kd);  S.w = w(kd);
kv  = s.vsup.t >= W.dyn(1) & s.vsup.t < W.dyn(2);
S.Vm = mean(double(s.vsup.v(kv)));
ks  = t >= W.ss(1) & t <= W.ss(2);
ic  = i(ks);  S.i2 = ordern(ic - mean(ic), th(ks), 2);
ka  = s.acc.t >= W.ss(1) & s.acc.t <= W.ss(2);
a   = double(s.acc.a(ka));  a = a - mean(a);
S.aRMS = sqrt(mean(a.^2));
S.a1   = ordern(a, interp1(t, th, s.acc.t(ka), 'linear', 'extrap'), 1);
end

function c = ordern(a, th, n)
t0 = th(1);  nrev = floor((th(end) - t0)/(2*pi));
k  = th <= t0 + nrev*2*pi;
tt = th(k);  aa = a(k);  dth = gradient(tt);
c  = 2*sum(aa.*exp(-1i*n*tt).*dth)/sum(dth);
end

function d = diffs(Sa, Sb)
d.curLP = sqrt(mean((Sa.iLP - Sb.iLP).^2));
d.spd   = sqrt(mean((Sa.w   - Sb.w).^2));
d.cur2x = abs(Sa.i2 - Sb.i2);
d.vib   = abs(Sa.aRMS - Sb.aRMS);
d.vib1x = abs(Sa.a1 - Sb.a1);
end

function x0 = steady_start(q, cfg, V)
idx = state_index(cfg);  R = q.R;
if cfg.thermal, R = R*(1 + q.alpha*q.theta); end
V   = V*(1 + q.eVs);
TL  = q.TL + q.dTL;
if strcmp(cfg.friction, 'viscous')
    w0 = (q.Kt*V/R - TL)/(q.Kt*q.Ke/R + q.b_lin);
else
    w0 = (q.Kt*V/R - q.Tc - TL)/(q.Kt*q.Ke/R + q.b);
end
x0 = zeros(idx.n,1);  x0(idx.i) = (V - q.Ke*w0)/R;  x0(idx.w) = w0;
end

function [q, c] = twin(p, Tr, model)
q = p;  q.theta = 0;  q.mr = 0;
if model == 1
    q.R = Tr.M1_R;  q.L = Tr.M1_L;  q.Ke = Tr.M1_Ke;  q.Kt = Tr.M1_Ke;
    q.J = Tr.M1_J;  q.b_lin = Tr.M1_b_lin;
    c = cfg_model1();
else
    q.R = Tr.M2_R;  q.L = Tr.M2_L;  q.Ke = Tr.M2_Ke;  q.Kt = Tr.M2_Ke;
    q.J = Tr.M2_J;  q.b = Tr.M2_b;  q.Tc = Tr.M2_Tc;  q.Ts = 1.3*Tr.M2_Tc;
    c = cfg_model2();  c.thermal = false;  c.gearbox = false;
end
end

function q = machine_params(p, R)
u = params_uncertainty();  q = p;
for j = 1:size(u.factors,1)
    f = R.factors(strcmp(R.names, u.factors{j,1}));
    moved = u.factors{j,4};
    for r = 1:numel(moved), q.(moved{r}) = p.(moved{r})*f; end
end
q.theta = R.theta;
end

function r = r_of_f(f, p)
smin = 1/(1 + p.sc.range(2));  smax = 1/(1 + p.sc.range(1));
r = 1/(smin + f*(smax - smin)) - 1;
end
