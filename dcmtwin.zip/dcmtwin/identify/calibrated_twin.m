function [q, cfg] = calibrated_twin(p, Trow, model)

q = p;  q.theta = 0;  q.mr = 0;
switch model
    case 1
        q.R = Trow.M1_R;  q.L = Trow.M1_L;  q.Ke = Trow.M1_Ke;  q.Kt = Trow.M1_Ke;
        q.J = Trow.M1_J;  q.b_lin = Trow.M1_b_lin;
        cfg = cfg_model1();
    case 2
        q.R = Trow.M2_R;  q.L = Trow.M2_L;  q.Ke = Trow.M2_Ke;  q.Kt = Trow.M2_Ke;
        q.J = Trow.M2_J;  q.b = Trow.M2_b;  q.Tc = Trow.M2_Tc;  q.Ts = 1.3*Trow.M2_Tc;
        cfg = cfg_model2();  cfg.gearbox = false;
    otherwise
        error('calibrated_twin:model', 'model must be 1 or 2');
end
end
