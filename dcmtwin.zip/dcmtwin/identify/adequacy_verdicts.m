function V = adequacy_verdicts(outdir, fname)

if nargin < 2 || isempty(fname), fname = 'adequacy_results_service.csv'; end
A  = readtable(fullfile(outdir, fname), 'TextType', 'string');
ch = ["curLP","spd","cur2x","vib","vib1x"];

[~, first] = unique(strcat(string(A.machine), "|", A.condition), 'stable');
U = A(first, :);
conds = unique(A.condition, 'stable');
floorv = zeros(numel(conds), numel(ch));
for c = 1:numel(conds)
    k = U.condition == conds(c);
    for j = 1:numel(ch)
        floorv(c,j) = sqrt(mean(U.("noise_" + ch(j))(k).^2));
    end
end
fprintf('\nPooled noise floors (rms over all repeats)\n');
fprintf('%-10s', 'condition');  fprintf('%12s', ch);  fprintf('\n');
for c = 1:numel(conds)
    fprintf('%-10s', conds(c));  fprintf('%12.5f', floorv(c,:));  fprintf('\n');
end

n = height(A);  twinOK = false(n,1);  anyOK = false(n,1);  detAny = false(n,1);
for r = 1:n
    fl  = floorv(conds == A.condition(r), :);
    sig = cellfun(@(x) A.("sig_" + x)(r), cellstr(ch));
    err = cellfun(@(x) A.("err_" + x)(r), cellstr(ch));
    det = sig > 2*fl;
    ok  = det & (err < sig);
    capm = capability(A.twin(r), A.fault(r), ch);
    twinOK(r) = any(ok & capm);
    anyOK(r)  = any(ok);
    detAny(r) = any(det);
end
V = A(:, {'machine','friction_factor','condition','twin','fault','level','severity'});
V.adequate_twin = twinOK;  V.adequate_any = anyOK;  V.detectable = detAny;
writetable(V, fullfile(outdir, 'adequacy_verdicts_service.csv'));

fprintf('\nFraction of machines for which each twin is adequate (final rules)\n');
fprintf('%-10s %-14s %-9s   %8s %8s   %8s %8s\n', 'condition','fault','severity', ...
        'M1 twin','M2 twin','M1 any','M2 any');
faults = unique(A.fault, 'stable');
for c = 1:numel(conds)
    for f = 1:numel(faults)
        for lev = ["smallest","middle"]
            k  = V.condition == conds(c) & V.fault == faults(f) & V.level == lev;
            k1 = k & V.twin == 1;  k2 = k & V.twin == 2;
            fprintf('%-10s %-14s %-9s   %7.0f%% %7.0f%%   %7.0f%% %7.0f%%\n', conds(c), ...
                faults(f), lev, 100*mean(V.adequate_twin(k1)), 100*mean(V.adequate_twin(k2)), ...
                100*mean(V.adequate_any(k1)), 100*mean(V.adequate_any(k2)));
        end
    end
end
fprintf('\nWritten: adequacy_verdicts_service.csv in %s\n\n', outdir);
end

function m = capability(twin, fault, ch)
m = ismember(ch, ["curLP","spd"]);
if fault == "imbalance"
    if twin == 1
        m(:) = false;
    else
        m = m | ch == "vib1x";
    end
end
end
