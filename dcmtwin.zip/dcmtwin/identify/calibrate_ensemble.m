function T = calibrate_ensemble(outdir, nMax)

files = dir(fullfile(outdir, 'machine_*.mat'));
[~, ord] = sort({files.name});  files = files(ord);
if nargin > 1 && ~isempty(nMax), files = files(1:min(nMax, numel(files))); end
n = numel(files);
p = params_default();
fprintf('\nCalibrating Models 1 and 2 to %d machines ...\n', n);

vars = {'machine', 'M1_R','M1_L','M1_Ke','M1_J','M1_b_lin', ...
        'M2_R','M2_L','M2_Ke','M2_J','M2_b','M2_Tc', ...
        'true_R','true_L','true_Ke','true_J','true_b','true_Tc','ref_b_lin', ...
        'Ke_spread','J1_step','J1_coast','J2_step','J2_coast', ...
        'J1_disagree','J2_disagree','V_lockedrotor','theta_degC','coast_stopped', ...
        'J1_restart_diff'};
rows = zeros(n, numel(vars));
parfor k = 1:n
    L = load(fullfile(outdir, files(k).name), 'R');  R = L.R;
    I  = identify_machine(R, p);
    tr = truth(R, p);
    d  = I.diag;
    rows(k,:) = [R.machine, ...
        I.M1.R I.M1.L I.M1.Ke I.M1.J I.M1.b_lin, ...
        I.M2.R I.M2.L I.M2.Ke I.M2.J I.M2.b I.M2.Tc, ...
        tr.R tr.L tr.Ke tr.J tr.b tr.Tc tr.b_lin, ...
        d.Ke_spread d.J1_step d.J1_coast d.J2_step d.J2_coast ...
        d.J1_disagree d.J2_disagree d.V_lockedrotor R.theta, all([R.coast.stopped]), ...
        d.J1_restart_diff];
end

T = array2table(rows, 'VariableNames', vars);
T = sortrows(T, 'machine');
writetable(T, fullfile(outdir, 'calibration_results.csv'));
save(fullfile(outdir, 'calibration.mat'), 'T');

e = @(id, tr) 100*(T.(id) - T.(tr))./T.(tr);
list = {'Model 1', 'R',     'M1_R',     'true_R';
        'Model 1', 'L',     'M1_L',     'true_L';
        'Model 1', 'Ke',    'M1_Ke',    'true_Ke';
        'Model 1', 'J',     'M1_J',     'true_J';
        'Model 1', 'b_lin', 'M1_b_lin', 'ref_b_lin';
        'Model 2', 'R',     'M2_R',     'true_R';
        'Model 2', 'L',     'M2_L',     'true_L';
        'Model 2', 'Ke',    'M2_Ke',    'true_Ke';
        'Model 2', 'J',     'M2_J',     'true_J';
        'Model 2', 'b',     'M2_b',     'true_b';
        'Model 2', 'Tc',    'M2_Tc',    'true_Tc'};
fprintf('\nIdentification error against the true value, %d machines\n\n', n);
fprintf('%-8s %-6s %12s %16s\n', 'model', 'param', 'bias (%)', '95% of |err| <');
for r = 1:size(list,1)
    x = e(list{r,3}, list{r,4});
    fprintf('%-8s %-6s %12.2f %16.2f\n', list{r,1}, list{r,2}, median(x), prctile(abs(x), 95));
end
fprintf('\nModel 1 b_lin is compared with a reference value only: the true friction\n');
fprintf('is not purely viscous, so it has no single true lumped coefficient.\n');
fprintf('\nInertia, disagreement between the step and coast-down methods (median, 95th pct)\n');
fprintf('  Model 1  %.1f %%  %.1f %%\n', 100*median(T.J1_disagree), 100*prctile(T.J1_disagree, 95));
fprintf('  Model 2  %.1f %%  %.1f %%\n', 100*median(T.J2_disagree), 100*prctile(T.J2_disagree, 95));
fprintf('Back EMF constant, spread across the three duties (median): %.3f %%\n', ...
        100*median(T.Ke_spread));
fprintf('Model 1 fit restarted from both methods: largest difference in J %.4f %%, ', ...
        100*max(T.J1_restart_diff));
fprintf('machines differing by more than 0.1 %%: %d\n', sum(T.J1_restart_diff > 1e-3));
fprintf('\nWritten: calibration_results.csv, calibration.mat in %s\n\n', outdir);
end

function tr = truth(R, p)
f  = @(name) R.factors(strcmp(R.names, name));
tr.R     = p.R*f('R')*(1 + p.alpha*R.theta);
tr.L     = p.L*f('L');
tr.Ke    = p.Ke*f('phi');
tr.J     = p.J*f('J');
tr.b     = p.b*f('fr');
tr.Tc    = p.Tc*f('fr');
tr.b_lin = p.b_lin*f('fr');
end
