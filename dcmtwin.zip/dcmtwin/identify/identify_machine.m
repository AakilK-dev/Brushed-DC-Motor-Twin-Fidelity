function I = identify_machine(R, p)

I.M1 = struct();  I.M2 = struct();  I.diag = struct();

lr = R.lockedrotor;  fs = lr.cur.fs;
i  = double(lr.cur.y);  v = double(lr.vsup.y);  t = (0:numel(i)-1)'/fs;
kss  = t >= 0.7*t(end);
iinf = mean(i(kss));  Vlr = mean(v(kss));
Rid  = Vlr/iinf;
fr   = i/iinf;
kf   = fr > 0.2 & fr < 0.9 & t < 0.7*t(end);
c    = polyfit(t(kf), log(1 - fr(kf)), 1);
Lid  = (-1/c(1))*Rid;

tA = R.opts.tA;  nS = numel(R.steady);
wS = zeros(nS,1);  iS = wS;  KeS = wS;  dwS = wS;
for k = 1:nS
    s  = R.steady(k);  fs = s.enc.fs;
    th = double(s.enc.y);  ii = double(s.cur.y);  vv = double(s.vsup.y);
    tt = (0:numel(th)-1)'/fs;
    w  = speed_from_angle(th, fs, round(0.005*fs));
    n1 = find(tt >= tA & ~isnan(w), 1, 'first');
    t2min = tt(end) - 0.3*(tt(end) - tt(n1));
    cand  = find(tt >= t2min & ~isnan(w));
    [~, j] = min(abs(w(cand) - w(n1)));  n2 = cand(j);
    seg = n1:n2;
    wS(k)  = (th(n2) - th(n1))/(tt(n2) - tt(n1));
    iS(k)  = mean(ii(seg));
    KeS(k) = (mean(vv(seg)) - Rid*iS(k))/wS(k);
    dwS(k) = abs(w(n2) - w(n1));
end
Keid = mean(KeS);  Ktid = Keid;
Tf   = Ktid*iS;
blin = sum(Tf.*wS)/sum(wS.^2);
cf   = polyfit(wS, Tf, 1);

Y = [];  X2 = [];  X1 = [];  C = struct('t',{},'w',{},'w0',{});
for k = 1:numel(R.coast)
    c  = R.coast(k);  fs = c.enc.fs;  th = double(c.enc.y);
    tt = (0:numel(th)-1)'/fs;
    w  = speed_from_angle(th, fs, round(0.005*fs));
    k0 = round((c.toff + 0.02)*fs) + 1;
    kE = find((1:numel(w))' > k0 & w < 5, 1, 'first');
    if isempty(kE), kE = numel(w) - round(0.005*fs); end
    sel = (k0:round(0.01*fs):kE-1)';
    Y  = [Y;  w(sel) - w(k0)];
    X2 = [X2; -(tt(sel) - tt(k0)), -(th(sel) - th(k0))];
    X1 = [X1; -(th(sel) - th(k0))];
    C(k).t = tt(sel) - tt(k0);  C(k).w = w(sel);  C(k).w0 = w(k0);
end
AB = X2\Y;  A = AB(1);  Bc = AB(2);
B1 = X1\Y;

g     = A + Bc*wS;
J2ss  = sum(Tf.*g)/sum(g.^2);
Tcid  = J2ss*A;
bid   = J2ss*Bc;

st = R.step;  fs = st.cur.fs;
ii = double(st.cur.y);  th = double(st.enc.y);  tt = (0:numel(th)-1)'/fs;
w  = speed_from_angle(th, fs, round(0.002*fs));
w(isnan(w)) = 0;
dth  = th - th(1);
Kint = cumtrapz(tt, Ktid*ii);
k    = tt >= 0.01 & tt <= tt(end) - 0.002;
X1s  = Kint - blin*dth;
X2s  = Kint - bid*dth - Tcid*cumtrapz(tt, tanh(p.beta*w));
J1step = sum(w(k).*X1s(k))/sum(w(k).^2);
J2step = sum(w(k).*X2s(k))/sum(w(k).^2);

J1coast  = blin/B1;
J2coast  = J2ss;

Vst  = median(double(st.vsup.y(tt > 0.005)));
kst  = tt >= 0.005 & tt <= tt(end) - 0.002;
wst  = w(kst);  tst = tt(kst);  wsc = max(abs(wst));
cost = @(z) m1_cost(exp(z(1)), exp(z(2)), Rid, Lid, Ktid, Vst, tst, wst, wsc, C, iS, wS);
ops  = optimset('TolX',1e-8,'TolFun',1e-12,'MaxFunEvals',2000,'MaxIter',2000,'Display','off');
zA   = fminsearch(cost, log([J1coast blin]), ops);
zB   = fminsearch(cost, log([J1step  blin]), ops);
if cost(zB) < cost(zA), z = zB; else, z = zA; end
J1fit = exp(z(1));  b1fit = exp(z(2));
J1restart = abs(exp(zA(1)) - exp(zB(1)))/J1fit;

I.M1 = struct('R',Rid,'L',Lid,'Ke',Keid,'Kt',Ktid, ...
              'J',J1fit,'b_lin',b1fit);
I.M2 = struct('R',Rid,'L',Lid,'Ke',Keid,'Kt',Ktid, ...
              'J',mean([J2step J2coast]),'b',bid,'Tc',Tcid);
I.diag = struct('Ke_per_duty',KeS','Ke_spread',std(KeS)/Keid, ...
                'speed_mismatch',dwS', ...
                'w_steady',wS','Tf_steady',Tf', ...
                'J1_step',J1step,'J1_coast',J1coast,'J1_fit',J1fit, ...
                'J1_restart_diff',J1restart, ...
                'b_lin_steady',blin,'b_lin_fit',b1fit, ...
                'J2_step',J2step,'J2_coast',J2coast, ...
                'b_line',cf(1),'Tc_line',cf(2), ...
                'J1_disagree',abs(J1step - J1coast)/mean([J1step J1coast]), ...
                'J2_disagree',abs(J2step - J2coast)/mean([J2step J2coast]), ...
                'V_lockedrotor',Vlr,'tau_e',Lid/Rid);
end

function w = speed_from_angle(th, fs, m)
n = numel(th);  w = nan(n,1);
j = (m+1:n-m)';
w(j) = (th(j+m) - th(j-m))*fs/(2*m);
end

function c = m1_cost(J, b, R, L, K, V, tst, wst, wsc, C, iS, wS)
rs = (wst - m1_step(tst, R, L, K, J, b, V))/wsc;
rc = [];
for k = 1:numel(C)
    rc = [rc; (C(k).w - C(k).w0*exp(-(b/J)*C(k).t))/C(k).w0];
end
rq = (K*iS - b*wS)./(K*iS);
c  = mean(rs.^2) + mean(rc.^2) + mean(rq.^2);
end

function w = m1_step(t, R, L, K, J, b, V)
A   = [-R/L, -K/L;  K/J, -b/J];
xss = -A\[V/L; 0];
[Vc, D] = eig(A);  lam = diag(D);
c   = Vc\(-xss);
w   = real(xss(2) + (Vc(2,:).*c.')*exp(lam*t(:).'));
w   = w(:);
end
