# Provenance of every value (final audit, 5 October 2026; modal mass revised 7 October; skeleton of Appendix C)

Kinds: MEASURED on the reference unit; SOURCED (datasheet or paper about the same item); TRANSFERRED (from another machine or rig, with the reason it transfers); DERIVED (computed from sourced inputs); ASSUMED (reasoned, sensitivity-tested); NUMERICAL (results shown not to depend on it); DESIGN (a choice of this study, with its reason).
Status: OK justified; SENS assumed or transferred, to be varied in the sensitivity analysis; GAP action needed; UNUSED not in any calculation, not to appear in the report.
Numbers in this table were computed from the code on 5 October, not recalled. Second pass (v1.0.29): the instrument chain sourced part by part, the bearing load derived per row for bench and service, the balance grades and insulation class sourced.

## A. Reference machine (Sankardoss and Geethanjali, 2017, measured on the unit)
| Value | Kind | Justification | Status |
|---|---|---|---|
| R = 0.162 Ω | MEASURED | Locked-rotor test at about 10% of rated current, slope of voltage on current (removes brush drop); winding temperature unrecorded, so taken as the ambient-temperature resistance (stated) | OK |
| L = 0.282 mH | MEASURED | LCR meter at standstill; Abdullah et al. find ±1.8% variation with rotor position on a similar machine | OK |
| K_e = 0.0503 V·s/rad | MEASURED | Slope of back EMF on measured speed at no load, several voltages | OK |
| K_t = K_e | DERIVED (correction) | Conservation of energy (Abdullah et al.); the paper's own power balance reduces to K_b; the published pair implies 105.2% efficiency at 24 V, 3 A | OK |
| J = 4.6e-4 kg·m² | MEASURED | Retardation (coast-down) test | OK |
| b_lin = 1.778e-4 N·m·s/rad | MEASURED | Single viscous coefficient, which therefore absorbs Coulomb friction and iron loss | OK |
| V_s = 24 V; 4600 rpm | SOURCED | Plate; the EC82 drawing gives 4600 rpm as the NO-LOAD speed; the model's no-load speed, 4505 rpm, is 2.1% lower | OK |
| P = 320 W | SOURCED | Paper; the manufacturer's drawing rates the matching model 300 W, which would lower the rated current 6% (stated) | OK |
| I_rated = 16.5 A | DERIVED | From 320 W with the measured parameters (15.5 A at 300 W); the plate's 3 A is the no-load current (EC82 drawing) | OK |

## B. Model 2
| Value | Kind | Justification | Status |
|---|---|---|---|
| T_c, b (Coulomb split) | TRANSFERRED + DERIVED | Fit to Abdullah et al.'s no-load torque table; the Coulomb plus viscous STRUCTURE validated against their data (validate_friction); total friction at the no-load speed preserved; the 41.6% FRACTION transferred from their motor | SENS (fraction) |
| β = 214 s/rad | NUMERICAL | Syakuro et al., heuristic; verify_numerics check 1: doubling β leaves the coast-down stopping time and steady point unchanged | OK |
| α = 0.004 /°C | SOURCED | Mellah et al.; copper 0.00393 within 2% | OK |
| k_T, k₀, H; 70 °C rise, 20 min | TRANSFERRED / DESIGN | No effect on any result: the temperature is set per run. They support the per-run treatment and the self-heating bounds (at most 0.009 °C over the identification battery, 0.013 °C per run). 70 °C lies below the class B limit of 80 K (IEC 60034-1 Table 7, resistance method; Leroy-Somer technical note 5202); 20 min assumed, inconsequential | OK |
| T_amb = 25 °C | DESIGN | Reference for R₀; temperatures are rises above it | OK |
| ΔT_w, 0 to 70 °C per session | DESIGN | Cold start to the rated rise | OK |
| f₁ = 85 Hz | TRANSFERRED | Rohani Bastami and Vahid's rig model (Behzad et al. used 125 Hz: rig-specific); with M = 5.2 kg implies a mount stiffness of 1.48 × 10⁶ N/m, plausible for stiff rubber mounts | SENS |
| ζ₁ = 0.05 | SOURCED | Barry Controls: rubber and neoprene isolators 0.05; Isotech neoprene mounts 0.1 | OK |
| M = 5.2 kg | DERIVED (corroborated) | Dunkermotoren 24 V brushed motors in an 80 mm frame: GR 80x40, 1800 g·cm², 2.8 kg; GR 80x80, 3200 g·cm², 4.0 kg; the line through them reaches 5.2 kg at the reference rotor's 4600 g·cm² (Figure C1). Corroborated by the shipping weight of a 320 W wheelchair gearmotor of 82.8 mm with gearbox and brake, about 8.4 kg each (SuperDroid TD-311-000). The 200 W EC82 gearmotor, 5.35 kg each packed without brake (Electronics Panga), is a lower-power model: on 5 October it was wrongly held against 5.2 kg and 4.0 kg adopted; corrected 7 October (student's decision, Option A). Range 4.0 kg (the GR 80x80, whose rotor has 30% less inertia: a lower bound) to 6.5 kg (leaves under 2 kg of the 320 W gearmotor's shipping weight for its gearbox, brake and packaging) | SENS (range) |
| Service mounting: f₁ coefficient of variation 0.15 | ASSUMED | Mount stiffness varying about ±30% between installations gives ±15% in frequency (f ∝ √k); reasoning only | SENS |
| Service mounting: ζ₁ 0.05 to 0.12 | SOURCED | Barry Controls: rubber or neoprene to butyl | OK |
| Service mounting: mass factor 1.25 to 1.75 | ASSUMED | Installed gearmotor, motor plus brake and gearbox: 6.5 to 9.1 kg with M = 5.2 kg, bracketing the about 8.4 kg shipping weight of a 320 W gearmotor with gearbox and brake (SuperDroid); the drawing gives no masses | SENS |
| mr, 5e-6 to 2.5e-5 kg·m | DERIVED meaning, SOURCED limit | ISO 1940-1:2003 (values kept in ISO 21940-11:2016): grade G = e·Ω; Table 1 groups electric motors of shaft height below 80 mm under G 6.3; the 82 mm frame puts the shaft near 41 mm. With the rotor estimated at 1.47 kg at 482 rad/s the range spans G 1.6 to G 8.2, and the G 6.3 limit, 1.93e-5 kg·m, lies inside it: severities from within tolerance to beyond it | OK |

## C. Model 3
| Value | Kind | Justification | Status |
|---|---|---|---|
| T_s = 1.3 T_c | TRANSFERRED | Brown and McPhee's comparison, μ_s/μ_d = 0.2/0.15 = 1.33 (a generic example) | OK |
| ω_s = 2 rad/s | ASSUMED | Not Brown and McPhee's 0.001 m/s; irrelevant at diagnosis speeds (Stribeck term e^(−7832) at 177 rad/s); affects only coast-downs | SENS (coast) |
| δ = 2 | SOURCED | Brown and McPhee's comparison value (Andersson et al.'s form) | OK |
| n_b = 24 | TRANSFERRED | Retana et al.'s machine; the EC82's bar count is unpublished; consistent with the model's own ripple order | SENS |
| n_p = 2 | ASSUMED | The maker builds 82 mm motors in two-pole and four-pole versions (Asia Machinery directory); four brushes would put the path asymmetry at four times shaft rate | SENS (n_p = 4) |
| ε_c = 0.018 | ASSUMED (surrogate) | Derived EMF ripple of an ideal 24-bar winding 0.43% (lower bound); real commutation adds impedance modulation (TI SLVAF08A), which the surrogate represents; ripple lies above the filter's 400 Hz cut-off and carries no fault signature | SENS |
| δ₀, G = 15, ΔK = 0.0388; r 0.5 to 20 | TRANSFERRED (calibrated) | Retana et al.: second harmonic 1.734%, harmonics up to 15 times, speed 1500 to 1560 r/min, r range; whether their relative effects transfer to a PM machine is uncertain | SENS (ΔK, G) |
| f₅, f₆ = 6100, 6200 Hz; ζ = 0.08 | TRANSFERRED | Rohani Bastami and Vahid's rig (Behzad et al.: 6200 Hz, 0.06); their role is a carrier band that the envelope analysis demodulates wherever it lies | SENS |
| M_l = 0.5 kg | ASSUMED | Local modes: only part of the housing moves, so far below the motor's mass; no data | SENS |
| Bearing 1206 geometry (N = 14, f_c = 0.413, BPFO 5.787) | TRANSFERRED (borrowed, stated) | The bearing of the defect model and its measured defect growth; wheelchair motors typically use deep-groove 6201 or 6202 bearings (vendor pages), so real defect orders would differ; shared by all models | OK (stated) |
| D_p = 46 mm | SOURCED | SKF 1206 EM: bore 30, outside 62 mm; shoulders 40.3 and 51.9 mm | OK |
| η_n, η_d = 1e8, 1e5 /m | TRANSFERRED | Rohani Bastami and Vahid (2021); Behzad et al. (2011) used 2e6 and 8e4 /m: surface-specific | SENS |
| c_v = 1.3 | DERIVED | Greenwood-Williamson summits as Behzad et al. adopt: 1.16 to 1.41 for d/s = 0.5 to 3 | OK |
| W per row: bench 3.61 N, service 9.65 N | DERIVED | Two rows share the radial load equally; only the defective row is modelled. Bench, through a coupling: rotor weight 7.22 N per bearing (rotor 1.47 kg, a solid cylinder of ASSUMED radius 25 mm from J). Service, installed gearmotor: plus the pinion separating force on the drive-end bearing, 12.1 N (0.166 N·m over an ASSUMED 5 mm pinion radius, 20°), 19.3 N per bearing. The old 20 N per row (40 N per bearing) had no derivation and was 2.1 times the derived service load | OK (radii SENS) |
| Q_max = 4.37 W/N | SOURCED | Harris and Kotzalas, zero clearance, consistent with Behzad et al.'s zero clearance; the 1206 EM's CN clearance stated as a limitation | OK |
| k_f = 1 (variants 0.25, 2) | ASSUMED, VARIED | No source; a spall mainly makes friction fluctuate (Sensors 2020); results reported across three values | SENS (decided) |
| v_roll = 0.05 m/s | NUMERICAL | Fade factor equals one at every operating speed | OK |
| Outer race; D 0.05 to 1 | DESIGN | Scope; D < 1 the single-contact regime (Rohani Bastami and Vahid) | OK |

## D. Instruments
| Value | Kind | Justification | Status |
|---|---|---|---|
| Current, bench: ACS712ELCTR-05B, 185 mV/A, ±10.8 A | SOURCED | Allegro datasheet: 185 mV/A; 5 V ratiometric, zero at 2.5 V, linear 0.5 to 4.5 V, so ±2.0 V/S = ±10.8 A; read by a 5 V MCP3208 (step 6.6 mA) | OK |
| Current noise, bench 5.34e-5 A/√Hz | DERIVED (corrected) | Datasheet 21 mV peak-to-peak over 80 kHz, as six standard deviations over a noise bandwidth of 80 kHz × π/2: 9.87 µV/√Hz; the old 2.24e-5 was 2.4 times too low. In the filter's 400 Hz band, 1.07 mA, matching the independently tuned 1.0 mA | OK |
| Current, service: ACS712ELCTR-20A, 100 mV/A, ±20 A, 5.17e-5 A/√Hz | SOURCED + DERIVED (corrected) | Datasheet 100 mV/A and 11 mV peak-to-peak; noise is roughly constant in AMPS across the family, not in volts as wrongly assumed before | OK |
| Converter: MCP3208, 12 bits, 5 V reference, 10 kHz per channel | SOURCED + DESIGN | Microchip datasheet: 100 ksps at 5 V, eight channels, so current and voltage share it; 10 kHz keeps the commutation ripple, up to 1.4 kHz, far below Nyquist. Channels are treated as sampled simultaneously (a multiplexed converter offsets them by tens of µs, small against the 1.74 ms electrical time constant: stated) | OK |
| Voltage divider 0.174 | DESIGN | 28.7 V full scale at the 5 V reference, about 1.2 times the supply; step 7.0 mV, as before | OK |
| Voltage noise 49.5 µV/√Hz on both channels (0.45 step rms) | ASSUMED | A real converter has noise of about half a step; the bench channel is no longer noiseless, since its only reason, preserving the old calibration, does not apply to a rebuild from scratch | OK |
| Encoder: Omron E6B2-CWZ6C, 1000 P/R × 4 | SOURCED | Maximum response 100 kHz, so maximum electrical speed 6000 rpm, above 4600; inertia at most 1e-6 kg·m², 0.2% of the rotor's | OK |
| Accelerometer PCB 352C33 (100 mV/g, ±50 g, 0.5 Hz to 10 kHz) | SOURCED | PCB manual | OK |
| Accelerometer converter: NI 9234, 24 bits, ±5 V, 50 kS/s; noise 3.33e-6 g/√Hz | SOURCED + DERIVED | NI datasheet: rates fM/256/n, so 50 kS/s with a 12.8 MHz external timebase; idle noise 50 µV rms over about 0.45 fs: 333 nV/√Hz, more than twice the accelerometer's; measured floor 3.66e-6 g/√Hz, 2.4 times the old value | OK |
| Anti-alias 8th order at 0.4 fs | ASSUMED | The averaged model has no content above the Nyquist frequency (no PWM switching), so aliasing is negligible; the filter defines the usable band | OK (reason) |
| Accelerometer modelled flat | DESIGN | Every analysed component lies in the specified band (stated limitation) | OK |

## E. Service conditions
| Value | Kind | Justification | Status |
|---|---|---|---|
| Brake: 1.0 N·m, 1.0 kg·cm², ±1% regulation, 75 W continuous | SOURCED | Magtrol HB-140M-2 datasheet | OK |
| Supply ±1% | SOURCED | Mean Well LRS-350-24 | OK |
| Datasheet limits taken as three standard deviations | DESIGN | Convention, stated | OK |
| Load 20% of rated torque | DESIGN | At 80% duty the brake's 75 W continuous rating allows at most 24.8% (206 mN·m; recomputed 1 November, was given as 24.7%, 205 mN·m); 20% is the largest round load at which all three duties run continuously (61 W at 80%; full duty would need about 76 W). Prof Wilke asks for load to be motivated AND varied | GAP (vary load) |
| Duties 40, 60, 80% | DESIGN | Upper: the brake's 75 W rating rules out full duty (76.6 W; the rating is reached at 98.0%), and 80% keeps a 19% margin (60.8 W) against coil-heating drift (Figure C7); NOT the highest sustainable duty, as first stated. Lower limit: reasoning to state (at lower speeds the imbalance force, ∝ ω², and the dither steps both shrink) | GAP (lower-limit reasoning) |

## F. Ensemble
| Value | Kind | Justification | Status |
|---|---|---|---|
| R spread 5%; flux spread 6% | TRANSFERRED | Wu's RK370CA tolerances, ±15% and ±18%, taken as three standard deviations | SENS |
| L 10%; J 5%; friction 30% lognormal | ASSUMED | Reasoning to state (friction lognormal as it cannot be negative); sources for manufacturing tolerances to seek | GAP (reasoning) + SENS |
| Latin hypercube; 500 machines in batches of 50; 1% stopping rule | DESIGN | McKay et al.; rule not met at the cap (2.7%), reported; band-edge precision 4.7% median | OK |

## G. Experiment design, estimation and analysis
| Value | Kind | Justification | Status |
|---|---|---|---|
| 150 sessions; 15 tuning; 100 hold-out | DESIGN | Precision argument; Prof Wilke asks for the number to be DETERMINED (learning curves) | GAP (determine) |
| Five folds grouped by machine | DESIGN | Every machine tested once, never on both sides | OK |
| Record 2.5 s, analysis after 0.5 s | DESIGN | Five mechanical time constants with the brake, about 0.18 s, plus anti-alias and filter start-up | OK |
| Dither ±2%, holds of 20, 40, 60 ms | DESIGN | Small steps; holds of the order of the mechanical time constant, so both responses are excited; identifiability shown by the matched checks | OK |
| Filter: 2 kHz, 400 Hz, 50 ms skip, σ_i 1 mA tuned, σ_θ 0.5 mrad, slow drift, harmonic states | DESIGN | Each reasoned and tested (report notes, 4.3) | OK |
| Features: envelope band 5.5 to 7 kHz; orders 1, 2, 24, 5.787 | DESIGN | Around the impact-excited modes; the model's own orders | OK |
| Random forest 200 trees; SVM RBF automatic scale; rule threshold 99th percentile | DESIGN | Forest error settles as trees are added (Breiman); 1% false-alarm design for the rules | OK |

## H. Unused (not to appear in the report)
| Value | Note |
|---|---|
| n_slots = 12 | Never used in a calculation |
| Modes 2 to 4 (90, 560, 600 Hz) | Not in any model's mode list |
