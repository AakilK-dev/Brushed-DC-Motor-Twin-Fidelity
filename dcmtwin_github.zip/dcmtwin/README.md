# dcmtwin

**Version 1.0.61, 9 November 2026.**  Check this line against the zip you have installed; `run_everything` prints it at the top of every log.

## Change log
| Version | Changes |
|---|---|
| 1.0.61 | **The legends of the four severity figures moved above the axes** (approved by the student, 9 November). Figure code only (`figures/make_figures.m`, section 6; `figures/redraw_figures.m` also accepts runs completed by 1.0.61): nothing that computes a result changed, so a full run computes exactly what 1.0.56 computed. In 1.0.60 the legend of `fig_severity_physics_bearing`, placed 'best' inside the axes, covered 8 of its 150 estimates (counted from the SVG: 11 marks inside the legend box, 3 of them the legend's own symbols), because that scatter fills every corner; the other three figures hid none. Each legend now sits above its axes and has two rows in every figure, so the four plot areas keep one height: one column for two entries, otherwise two columns filled column by column (the estimate and the line of equality on the left, the counts of estimates beyond the axis on the right). The bearing labels are shortened to 'Bearing, Model 2's filter' and 'Bearing, Model 1's filter' so that the widest legend, about 87% of the canvas by font metrics, fits; the log warns if a legend is wider than the canvas. Tested in Octave 8.4 on synthetic estimates (syntax only; Octave's legend layout differs from MATLAB's): the block runs, and the whole of `make_figures` parses. |
| 1.0.60 | **The electrical fingerprint figure split in two** (the student, 8 November: too many things on one set of axes). Figure code only (`figures/make_figures.m`; `figures/redraw_figures.m` also accepts runs completed by 1.0.60): nothing that computes a result changed, so a full run computes exactly what 1.0.56 computed. `fig_fingerprint_R_Ke` drew all five classes of reference runs (Model 2's filter) on one set of axes: the normal, bearing and imbalance runs lay on top of one another at the origin, and because the resistive fault spans about 30% of R and the shorted bar about 4%, the shorted bar's equal fall in R and Ke looked vertical. It is replaced by two figures to be placed side by side as (a) and (b) of one figure: `fig_fingerprint_resistive`, the resistive runs over the normal runs with Ke on a range of at least +/-1% (wide enough to show a change the size of the smallest shorted bar's, about -0.4%, so Ke is seen not to move), and `fig_fingerprint_shorted`, the shorted-bar runs over the normal runs on equal axes with the line of equal change. Bearing and imbalance runs, which lie among the normal runs in both estimates, are not drawn; the log prints their medians, the Ke ranges of the resistive and normal runs, and the axis ranges. Tested in Octave 8.4 on synthetic estimates (layout and syntax only): the block runs, and the whole of `make_figures` parses. |
| 1.0.59 | **Three figure fixes found in the 1.0.58 redraw** (6 November, approved by the student 7 November 16:36). Figure code and one comment only (`figures/make_figures.m`, `figures/make_appendix_c_figures.m`, `identify/adequacy_test.m`; `figures/redraw_figures.m` also accepts runs completed by 1.0.59): nothing that computes a result changed, so a full run computes exactly what 1.0.56 computed. (1) `fig_filter_resistance`: the y-label 'Estimated resistance relative to baseline (%)' ran about 5 mm off the canvas (the only one of 1,345 labels that did); now 'Estimated resistance change (%)'. (2) The four physics severity figures (`fig_severity_physics_*`) share the y-range -0.25 to 1.25, which hid 8 of the 150 bearing estimates (Model 2's filter) and 3 of the 150 imbalance estimates; an estimate beyond the range is now drawn at the edge it passed, as an open triangle pointing the way it went, counted in the legend ('Above the axis: n', 'Below the axis: n') and in the log line; the legend goes where it covers the fewest points ('best'). The error statistics in the log were always computed from every estimate and do not change. (3) Figure C3: the legend covered the curve between 32 and 40 bars; the y-axis now runs to 20% (ticks to 20), and the legend sits in the band above 6%, clear of the curve (highest point 3.9% at 8 bars) and of the dashed line, as C1 already does. The comment in `adequacy_test.m` now gives the final run's figures (a floor of about 3 mA, 3.15 mA at no load, some forty times smaller than the bench ripple, median 134 mA) instead of an early run's 2 mA and fifty times. Tested in Octave 8.4 on synthetic estimates (planted above, below and non-finite: every estimate drawn or counted once) and on the C3 block; every edited file parses. |
| 1.0.58 | **The order-spectrum figures no longer alias** (found 4 November while checking Section 4.4 against Randall and Antoni; held by the student, approved 6 November 08:18). Figure code only (`figures/make_figures.m`; `figures/redraw_figures.m` also accepts runs completed by 1.0.58): nothing that computes a result changed, so a full run computes exactly what 1.0.56 computed. The current and vibration order figures (`fig_spectrum_current`, `fig_spectrum_vibration`) resampled the signal at 64 and 256 points per revolution with no anti-alias filter; at 60% duty 256 points per revolution is about 11.5 kHz, so the reference's bearing vibration above about 5.7 kHz folded onto orders 1 to 10 and raised the normal run's bars 50 to 100 times. Both now compute each order with the features' own integral (`features_core`'s `ordern`, equation 4.17) at the channel's full rate, so each figure shows exactly what the features measure, and its log line checks the fault minus the baseline against the feature table (`A_i2`, `A_v1`). The envelope figure (`fig_spectrum_envelope`), which needs non-integer orders, still resamples, but after a low-pass at 0.4 of the angle-domain rate, the instruments' anti-alias rule. Tested in Octave 8.4 on synthetic runs: the figure values equal the features' exactly (difference 0); normal vibration bars 0.002 to 0.022 mg, against 0.16 to 1.3 mg before; an 8 mg line at 1x returned at 7.99 to 8.00 mg (7.50 to 8.43 before); a 200 mA line at 2x unchanged to 0.2 mA; the 24x line 50.3 mA for 50 (47.8 before, the interpolation's loss); the envelope spectrum unchanged to three figures. |
| 1.0.57 | **Figures redesigned, and a figures-only mode** (student's rules of 4 November: no crowded axes; colour for the spectral figures only; one decision per figure, approved 20:01). Nothing that computes a result changed: a full run computes exactly what 1.0.56 computes. FIGURES-ONLY MODE: `run_everything(outdir, 'figures')` on a completed run (1.0.56 or 1.0.57) redraws every figure from that folder's saved results and records, after removing the earlier figure files; the log records which version drew them (`figures_log_<date>.txt`, `FIGURES_REDRAWN.txt`); the two validation figures are recomputed as stage 2 computes them, since stage 2 prints but does not save their numbers. ONE CANVAS: every figure drawn off screen at 20 by 15.5 cm and saved whole (`exportgraphics` with `Padding` 'figure', R2025a and later), the axes fitted to their labels; in 1.0.54 the widths ran from 149 to 269 mm. SPLIT into separate figures on the same axes: the operating-point map (one per fault, each with the normal runs, the brake band and its predicted line), resistive recall (within the reference, from Model 2), the accuracy heatmap (four classes, 7 cells, and five classes, 5 cells: all 12 cells now drawn, 9 before), physics severity (resistive, bearing with each filter, imbalance), learning curves (by class set, all 7 curves, 5 before), onset traces and onset delays (one per fault), integrated severity (one per fault), hold-out accuracy (by class set), the bearing time record (normal and defect, each on its own scale). TABLE instead of the two adequacy charts: `figures/table_adequacy.csv`, with the fraction of machines in which each fault is detectable at all. COLOUR for the PSDs, spectrograms (parula) and order and envelope spectra. Calibration figure: Model 2 drawn on top, darker. C8: legend moved off the Coulomb level. Integrated recall: legend stacked. New files `ensemble/plot_ensemble.m` (the ensemble figures, from the tables `export_ensemble` writes), `analysis/plot_onset_figures.m` (the onset figures; in the figures-only mode it re-forms the typical machine's statistics from its saved records and estimates and stops if they do not reproduce the saved delays), `figures/redraw_figures.m`. Tested in Octave 8.4 on a stand-in folder (synthetic data only): all 79 figures drawn on one canvas, the onset check passes and fails as it should, the guards refuse an incomplete run, a run in progress, an older version and an unknown mode |
| 1.0.56 | **Filter divergences reported in the sensitivity analysis.** The MATLAB test of the new stages (test_new_stages, 4 November: every step passed; replay check identical to the last bit, every run of all three models) printed a near-singular innovation matrix in the filter during the four-brush variant. Whether that run diverged was not recorded, because v1.0.55 did not count filter divergences in the variants; a diverged run's estimates are NaN and its Set B enters the scores as zero changes. `sens_session` now counts the filter runs that diverge, per filter pair (`out.nFail`), and `run_sensitivity` prints the count on every variant's line, lists the variants with divergences after the tables, and writes a `filters_diverged` column to sensitivity_summary.csv, as stage 8 reports divergences for the base. No computation changes; stages 1 to 14 are those of 1.0.55, and stages 1 to 11 those of 1.0.54. |
| 1.0.55 | **Stages 12 to 15: least squares, the integrated tool, the hold-out test and the sensitivity analysis** (plan agreed 3 November). Stages 1 to 11 are unchanged and reproduce the v1.0.54 results bit for bit: the new stages only read their results, draw from their own seeds and write new files. (12) `lsq_estimate`: a batch least-squares estimator, linear in the parameters, that needs only the model structure (the armature equation integrated over 10 ms windows, with the twice-per-revolution back EMF; then the torque balance for the friction torque and inertia); `run_lsq_dataset` over the three datasets, checked against the truth; its Set B (`extract_features_lsq`, `lsq_rows`); `run_grid_lsq`: NEW Set A+B_LS cells, compared run by run with the filter's Set B. (13) `run_integrated` (`integrated_core`): type from the grid's own RF A+B predictions, competing-cause rules, severity given the type by the method chosen on the training folds, root-cause evidence, onset delay; deployment and upper bound; two figures. (14) `make_holdout_sessions` (the 100 hold-out machines, own seed), 'holdout' branches in `generate_dataset` and `run_ekf_dataset` (the other plans' code paths untouched), `extract_holdout_features`, `run_holdout`: the headline cells trained once on all 150 diagnosis sessions and tested once, intervals by resampling machines, the integrated tool, one figure. (15) `run_sensitivity`: 34 variants of the 15 assumptions agreed on 3 November, on 60 diagnosis sessions; a replay check against stages 4, 7 and 8 and a check of the base features against stage 9 before any variant; four tracked results with paired intervals and the decision rule; resumable per variant; table, CSV and four figures. Shared: `features_core` (extract_features' arithmetic as plain arrays), `fit_predict`, `tab_cols`, `tab_row`. Five verification scripts (46 checks) appended to the suite: 210 checks. The planned quick-test mode is replaced by `test_new_stages` (a test of stages 12 to 15, in MATLAB, on a copy of the complete v1.0.54 run, whose stages 1 to 11 are this version's): a quick mode would have needed size options in stages 3 to 11. Review before release: the replay check of `run_sensitivity` re-simulates every run of its session, not only the baseline runs, so it also proves the copy of the fault runs; three lines that indexed a function's result directly (`tab_cols(S.S).session`) rewritten in two steps. |
| 1.0.54 | **Stale check removed; runs tied to one code version.** The v1.0.53 run stopped in stage 1 on `verify_service`'s line 'bench channel would clip it': a leftover from the two-sensor design, asserting that the bench channel (once the ±10.8 A ACS712-05B) would clip the worst loaded case. Since v1.0.51 the bench and service channels are the same ±20 A sensor, so the line had no meaning left; it is removed, and the remaining line checks that the one sensor covers the worst loaded case (11.3 A of 20 A, with a 10% margin). The 1.0.53 note 'suite 165' counted that line as a pass without the whole suite having been run: the suite is now **164 checks**. `run_everything` now reads the version line of this README, records it in the run folder and prints it at the top of the log and in `BUILD_COMPLETE.txt`, and REFUSES to continue an unfinished run that another code version began, so one results folder can only ever hold one code version's results. Because a fix now always means a full rerun in a new folder, FIGURE DRAWING CAN NO LONGER STOP A RUN: the late-stage drawing calls that were unguarded (`plot_learning_mixed` in `run_learning_mixed`, the two onset figures in `run_onset`, and stage 11's Appendix C and signal figures) now report a failure in the log as a line beginning 'skipped', as `make_figures` already did; every computation still stops on error. Comments: `virtual_sensors` (no noiseless bench channel remains). No model or parameter change |
| 1.0.53 | **Converter noise from the MCP3208 datasheet** (DS21298E, read 2 November). Its typical SINAD, 72 dB, leaves 0.240 mV rms of its own noise and distortion beyond quantisation, about a fifth of a step. The voltage channel's noise, until now ASSUMED at 0.45 of a step (4.95e-5 V/√Hz), is now this derived value, 2.17e-5 V/√Hz referred to the motor; the current channel gains it too (sensor and converter combined, 3.29e-4 A/√Hz, +0.7%). Derived in `params_default` from its definitions (`p.adc`); the bench and service voltage channels are now set together, like the current channels. `verify_mounting` checks the converter noise against the datasheet arithmetic and that both channel pairs are identical (suite 165 checks). Encoder comment from its datasheet (CSM_E6B2-C_DS_E_6_3): why 1000 P/R (100 kHz response limit), starting torque 0.98 mN·m neglected. Run with `run_everything` |
| 1.0.52 | **One command, nothing carried over** (student's decision, 2 November, and Prof Wilke's request for one script that produces every result in the report). `run_everything(outdir)` replaces `rebuild_everything`: one argument, an empty folder, every stage from verification to the last figure, nothing read from any other folder. Removed: the comparison with an earlier build's calibration and the carrying over of its reserve split; the split is drawn in every run from its fixed seed (`allocate_reserve`), as the ensemble and session plans already were, so every run reproduces the same machines by construction. Moved into the run: `ekf_matched_check` (each twin's filter on its own twin's data), `check_normal_spread` and `shortcut_test` (the checks behind the mixed-training explanation), the onset plan (now with the other plans, stage 6), and the validation figures (`validate_friction(figdir)`, `validate_bearing(figdir)` write to figures/validation instead of the current folder). Removed as one-off code: `ekf_export_test` (an export for an outside cross-check). The shorted-bar surrogate's typed constants are recomputed in stage 2 (`calibrate_commutation`), and the run stops if `params_default` is out of date. Physics and results identical to 1.0.51 |
| 1.0.51 | **Current sensor noise corrected (FULL REBUILD).** The ACS712 datasheet gives its noise, 21 mV (05B) and 11 mV (20A) peak-to-peak, in a 2 kHz bandwidth (47 nF filter capacitor); the model had spread these over the 80 kHz signal bandwidth, leaving the virtual current sensor 6.3 times too quiet: now 3.27e-4 A/√Hz (was 5.17e-5). **One current sensor, the ACS712ELCTR-20A, on the bench and in service** (`p.cur_svc` is kept as a name and is identical to `p.cur`): the bench's 05B is specified only over ±5 A, below the bench tests' transients, its ±10.8 A had rested on an unsourced 0.5 to 4.5 V linear swing, and with the corrected noise its finer converter step no longer matters. about 6.2 mA rms in the Kalman filter's 400 Hz band (was 1.0 mA), so `ekf_tune` now tries 2, 3, 5, 7 and 10 mA (was 1 to 5 mA). Accelerometer converter noise from the NI 9234's stated density, 310 nV/√Hz (3.10e-6 g/√Hz; floor 3.44e-6, was 3.66e-6 derived from the idle-channel rms). `verify_mounting` checks the current density against the datasheet arithmetic, that the bench and service channels are identical, the ±20 A range and the new floor (suite 163 checks). Comments corrected in `params_default` (no-load speed 4505 rpm; anti-alias rejection at the Nyquist frequency, not at 0.4 fs) and `ensemble_tests` (sensor range; the locked-rotor test draws about 1.65 A). Every result that uses the current or the filter changes |
| 1.0.50 | `figures/make_signal_figures.m`, new, reads existing records only (no simulation): the basic signal analysis Prof Wilke asked for on 2 November. Welch PSDs written out so the scaling is explicit (periodic Hann, 0.5 s windows, half overlap, 2 Hz bins; checked on white noise of known density) of the normal run's current and vibration, each drawn with the floor its instrument chain should produce (sensor density through the eighth-order anti-alias filter and the decimation, plus quantisation), with an instrument check on Model 1's records; the current over 0.2 s; normal against shorted bar (current PSD), bearing defect and imbalance (vibration PSDs); 20 ms of vibration, normal against bearing defect; spectrograms of the start-up (imbalance run: why the first 0.5 s is dropped) and of the shorted bar, bearing and imbalance onsets on the typical scored onset machine; the same normal run's PSDs in Models 1, 2 and 3; `table_signal_statistics.csv`. `make_figures`: the operating-point map of Section 3.2.4 (`fig_operating_point_map`: change in speed per volt against change in mean current at 60% duty, each change of state's direction predicted from the steady-state equations, the brake offset's band of plus and minus three standard deviations); `fig_filter_resistance` legend moved below the normal run's line. `plot_learning_mixed`: every learning curve names its classes, Model 2's shared-four transfer line added beside Model 1's, axis labels 'Training machines' and 'Real machines in training'. `make_appendix_c_figures`: `Figure_rated_current` (Section 3.3.1). `aa_decimate` comment corrected (eighth order, as `p.aa.order`). `rebuild_everything` stage 11 also runs `make_signal_figures`. Tested in Octave 8.4 with stand-in records passed through `virtual_sensors`: the instrument check returns 1.00 for vibration and 1.07 for current (the excess is the dither's response). Run `make_signal_figures`, `make_figures`, `plot_learning_mixed` and `make_appendix_c_figures`; no dataset or result changes |
| 1.0.49 | Mixed training: the k real machines are now drawn by a seed set by the draw and the round only, so every configuration and every twin uses the same machines and the draws nest across k (before, each configuration and twin drew its own, so the comparisons mixed the twin's effect with the luck of the draw); every paired comparison is also printed draw by draw. Forests in `run_learning_mixed` and `shortcut_test` made reproducible with a pool open (`UseSubstreams` with a seeded `mlfg6331_64` stream: before, the workers' random numbers were outside `rng(seed)`, so reruns differed slightly). Feature-extraction figures (`make_figures` 7, 11, 12 and the new 13, `fig_spectrum_vibration`) all from one machine chosen by rule (`mid_session`), each marking where its feature is read; `run_onset` adds `fig_onset_traces` (each fault's own statistic over its threshold around onset, on the typical scored machine). Layout tested in Octave with stand-in signals. Rerun `run_learning_mixed`, `shortcut_test`, `make_figures` and `run_onset` |
| 1.0.48 | Rigid-body modal mass M = 5.2 kg (student's decision, 7 October, Option A), replacing 4.0 kg: the Dunkermotoren mass-inertia line extended to the reference rotor, corroborated by the 8.4 kg shipping weight of a 320 W wheelchair gearmotor with gearbox and brake (SuperDroid); the 10.7 kg pair used against it on 5 October was a 200 W model. Sensitivity range 4.0 to 6.5 kg (`p.M_range`); service factor kept, installed mass 6.5 to 9.1 kg. `verify_mounting` derives the mass from the line (suite stays at 162 checks; mounting checks run in Octave, 16 of 16). Figure C1 redrawn (adopted value with its range, both shipping weights as levels, legend clear of the data). `rebuild_everything` adds stage 10 (onset: allocation carried over from the old build, onset records, both filters, `run_onset`) and stage 11 (Appendix C figures). `allocate_reserve` now also checks that a carried-over allocation was made with this build's diagnosis and tuning machines (both cases tested in Octave). Unused legend font sizes removed from `make_appendix_c_figures` (`style_legend` always set 20) |
| 1.0.47 | Onset analysis: `run_ekf_dataset(outdir, 3, tw, 'onset')` filters the onset records; `run_onset` watches six statistics (R, Ke, friction from the filter; vibration level, 1x and envelope over 0.25 s windows) against each machine's baseline, thresholds from 20 calibration machines, scored on 40: delay, misses, false alarms, first to notice, for both twins; `fig_onset_delay`. Alarm core (`onset_alarm`, `onset_threshold`) tested in Octave |
| 1.0.46 | Fault onset: `run_sim` onset switch (`verify_onset`, 6 checks); `allocate_reserve` fixes hold-out, onset and spare machines once, checked disjoint; `make_onset_sessions`; `generate_dataset(outdir, 3, [], 'onset')` writes 6 s records with each fault switching on mid-record. Suite: 162 checks |
| 1.0.45 | Mixed-training figures replaced by two difference plots (student's choice): `fig_mixed_twin_adds` (twin plus k real minus k real alone, five classes) and `fig_mixed_fidelity` (Model 2 minus Model 1, shared four), each a line over its paired 95% band with a zero line; tested in Octave from the real accuracies |
| 1.0.44 | Learning-curve figure drawn as lines only (student's choice, option a); the largest plotted 95% half-width printed for the caption (2.3 points in the 6 October results) |
| 1.0.43 | `check_normal_spread` compares all 17 features between twin and reference normal runs and flags potential source cues |
| 1.0.42 | `shortcut_test` adds a dose-response test of the class balance: real normal runs with the normal class's weight kept (1x), unweighted (2x) and weighted (5x), with and without vibration (weights verified in Octave) |
| 1.0.41 | `shortcut_test`: does real normal data teach 'real means normal'? (with and without the vibration features); feature set 'ABnv' in `train_test_core`; mixed-training axis label shortened |
| 1.0.40 | `plot_learning_mixed`: the three figures redrawn from saved results (legend clear of the lines; real-data-alone dashed); `check_normal_spread`: tests whether the twin's normal data are cleaner than the reference's |
| 1.0.39 | `run_learning_mixed`: learning curves (20 to 120 training sessions) and mixed training (twin plus k real sessions, weighted and unweighted; real alone; twin plus real normal data), on the grid's folds, with an overlap check in every fold (`train_test_core`; cores tested in Octave, including a deliberate leak, caught); three figures; added to `rebuild_everything` with both interval functions |
| 1.0.38 | `grid_intervals` reports perfect or zero scores as rule-of-three bounds on sessions instead of zero-width intervals; `severity_intervals`: intervals and paired comparisons for the severity results (tested in Octave) |
| 1.0.37 | `grid_intervals`: 95% intervals for every grid score and paired comparisons, by resampling whole sessions (`boot_counts`, `boot_scores`; tested in Octave against direct computation); `run_grid` and `run_severity` record each test run's session |
| 1.0.36 | Grid heat map stars the rule cells of the five-class rows (rules cannot name imbalance); adequacy charts print each bar's value, so 0% is visible, with the legend above the plot |
| 1.0.35 | Severity figure omits the shorted bar until the sensitivity analysis (its physics estimate is exact by construction); adequacy charts' axis label shortened so it is not clipped |
| 1.0.34 | Current order figure is now a time-synchronous average at integer shaft orders, which removes the dither (tested in Octave); the envelope example uses the defect nearest D = 0.5, where the outer-race line is strongest |
| 1.0.33 | Order spectra fixed: each spectrum keeps its own order axis (a faulted run completes a different number of revolutions, so a shared axis failed; tested in Octave); `rebuild_everything` now runs `export_ensemble`; `run_severity` reports the signed bias and keeps every prediction |
| 1.0.32 | `make_appendix_c_figures(outdir)`: the eight Appendix C derivation figures in MATLAB, reading model values from `params_default`, with sourced constants cited and self-checks of the bearing loads and Coulomb torque against the parameter file; tested end to end in Octave 8.4, its values identical to an independent Python implementation. No simulation code changed |
| 1.0.31 | `rebuild_everything`'s calibration comparison now checks that the TRUE machines are identical (must be 0) and reports how far each ESTIMATE moved (small, not zero, since the bench instruments changed) |
| 1.0.30 | Current channel: the sensor saturates BEFORE the converter quantises, so saturated readings lie on the converter's grid (found by verify_sensors: the new ±10.81 A range is 1638.4 steps, so clipping after rounding left samples 0.4 of a step off the grid) |
| 1.0.29 | Final audit, second pass: sourced instrument chain (ACS712 into a 5 V MCP3208, ranges ±10.8 and ±20 A, datasheet noise; Omron encoder; NI 9234 with its noise); realistic noise on the bench voltage channel; bearing load derived per row, bench 3.61 N and service 9.65 N; one `cur_range` for every current range; provenance records every parameter; 156 checks |
| 1.0.28 | Value audit: rigid-body modal mass 4.0 kg (Dunkermotoren GR 80x80; EC82 gearmotor evidence), service factor 1.25 to 1.75; summit force spread c_v = 1.3, derived from the Greenwood-Williamson contact theory of Behzad, Bastami and Mba; k_f = 1 as base, 0.25 and 2 as variants |
| 1.0.27 | Service modal mass factor widened to 1.2 to 1.8 (about 6 to 9 kg): an installed wheelchair gearmotor moves with its brake and gearbox (Motion Technology EC82 drawing) |
| 1.0.26 | `rebuild_everything` replaces `rerun_after_mounting_fix`: recreates every result from scratch into an empty folder, in dependency order, resumable, refusing folders that hold another build's results |
| 1.0.25 | `rerun_after_mounting_fix` also reruns the bearing validation (`validate_bearing`), found missing by a completeness check |
| 1.0.24 | MOUNTING CORRECTED: rigid-body modal mass 5.2 kg (Dunkermotoren scaling), mode 1 damping 0.05 (Barry Controls), separate local-mode mass 0.5 kg; service installations drawn per machine (`service_mounting`), twins keep the bench values; provenance (`physics_provenance`) on ensemble, adequacy and dataset files, stale ones recomputed; `verify_mounting` (11 checks); `rerun_after_mounting_fix` rebuilds everything affected |
| 1.0.23 | Two order-spectrum figures in `make_figures`: current, normal against a shorted bar; vibration envelope, normal against an outer-race defect, with the defect order and harmonics marked |
| 1.0.22 | `figures/make_figures.m`: ten results figures from the saved results, house style |
| 1.0.21 | Shared four-class cells in the grid; `feature_importance` (one-against-the-rest forests, permutation importance); `run_severity` (random forest regression on Sets A and A+B, and physics inversion of each fault model); auxiliary columns X_w and X_bbase in the feature tables (re-extract) |
| 1.0.20 | Classification grid: `classification/run_grid.m`, within, forward and reverse cells, Sets A and A+B, random forest, support vector machine and the physics-rule baseline, folds grouped by machine |
| 1.0.19 | Feature extraction: `features/extract_features.m`, Sets A and B, one sample per run relative to the session baseline; friction as an absolute torque change |
| 1.0.18 | `check_estimates`: fault fingerprints in the filter's estimates and detection by severity; the dataset generator records the measurement settings in each session and rebuilds stale ones |
| 1.0.17 | `run_ekf_dataset` resumes only from files made with the current frozen settings and tuning; stale files are removed and recomputed, after an earlier version's results were found kept by the resume logic |
| 1.0.16 | The filter estimates the twice-per-revolution current component as two amplitude states in its measurement model (`o.harm`), after the reference's harmonic made it diverge on 2 of 3450 runs; positivity clamp limited to the physical parameters; four checks added to `verify_ekf` (139 in total); retune required |
| 1.0.15 | The filter detects divergence, stops, flags it (`E.failed`) and returns NaN estimates instead of propagating it; `ekf_find_failures` lists the runs on which it diverges |
| 1.0.14 | Tuning plan on reserve machines (`make_tuning_sessions`; `generate_dataset(..., 'tuning')`), `ekf_tune` to tune and freeze each twin's filter, `run_ekf_dataset` to run the frozen filters over the datasets |
| 1.0.13 | Service voltage channel `p.vsense_svc` with converter noise of about 0.45 LSB rms for the fault datasets, after a noiseless converter was found to bias the resistance estimate; the bench channel is unchanged and every earlier record reproduces exactly |
| 1.0.12 | The Kalman filter discards the first 50 ms of each record, where the simulated anti-alias filters start from rest; `ekf_export_test` added for a cross-check of the filter |
| 1.0.11 | Extended Kalman filter: `estimate/ekf_defaults.m`, `ekf_twin.m`, `ekf_matched_check.m`; `verify_ekf` added to the suite |
| 1.0.10 | Service current channel `p.cur_svc` (100 mV/A, ±16.5 A) for the fault datasets, after the first datasets clipped; two checks added to `verify_service` |
| 1.0.9 | Fault datasets: `datasets/make_sessions.m`, `generate_dataset.m`, `check_dataset.m`; helpers `true_machine.m`, `calibrated_twin.m`; final adequacy rules in `adequacy_verdicts.m` |
| 1.0.8 | Service conditions (brake and supply offsets); faster integration loop, verified identical |


## Setup

Unzip so that the folder `dcmtwin` contains the subfolders below.  In MATLAB,
change into `dcmtwin`, then run:

    addpath(genpath(pwd))
    run_everything('C:\dcm_final')        % any EMPTY or new folder

`run_everything` is the one command: it runs the verification suite (and
stops if any check fails), then computes every result, table and figure in
the report from scratch, in one pass, into that folder.  Nothing is read from
any other folder and nothing is carried over: every plan (ensemble, sessions,
the split of the machines) is drawn from its own fixed seed, so every run
reproduces the same machines and scenarios.  About 33 hours on 8 workers
(stages 1 to 11 about 17 h, the hold-out test about 1 h, the sensitivity
analysis about 15 h).  If
interrupted, run the same command on the same folder and it continues there,
provided the code version is unchanged; a run begun by another version is
refused, and must start again in a new folder.  The first line of the log
names the version.  To check the code alone, `run_all_verifications` runs the
suite (210 checks).

**After the final run, redraw the figures with 1.0.61 (a few minutes):**
only once the run has finished (BUILD_COMPLETE.txt in its folder), close
MATLAB, delete the old `dcmtwin` folder, unzip 1.0.61 in its place, start
MATLAB, change into `dcmtwin`, then:

    addpath(genpath(pwd))
    run_everything('C:\dcm_final', 'figures')

Never replace the code while a run is using it: MATLAB reads each file as a
stage first calls it, so a run would mix two versions.

**Before the final run of 1.0.55, test the new stages (about 2 h):**

    test_new_stages('C:\dcm_run', 'C:\dcm_test')

The first folder is the complete v1.0.54 run, which is only read; the second
is a new folder outside OneDrive, which receives a copy of it (several GB).
Stages 1 to 11 are those of v1.0.54 unchanged, so that copy holds exactly the
inputs stages 12 to 15 will meet in the final run.  The test runs those four
stages on the copy in MATLAB, with the real simulator, filter, forests and
tables: least squares and the integrated tool in full, the hold-out test with
6 spare machines standing in for the hold-out machines (which stay unseen
until the final run), and the sensitivity analysis with one variant of each
kind of change on 6 sessions.  A summary at the end lists every step as passed
or failed.  It is a test, never a result: nothing from it is used in the
report.  Delete the test folder afterwards.

## Layout

    dcmtwin/
      README.md                  this file
      REFERENCES.md              every source, what it supplies, where used,
                                 and the source verification log
      run_everything.m           THE one command: every result in the report
      run_all_verifications.m    every verification check (stage 1 of run_everything)
      test_new_stages.m          a TEST of stages 12 to 15 on a copy of the v1.0.54
                                 run, before the final run (never a result)

      params/                    WHAT the machine is
        params_default.m         nominal values, each tagged with its source
        params_uncertainty.m     unit to unit variation, as physical factors

      config/                    WHICH physics is switched on
        cfg_model1.m             linear lumped model
        cfg_model2.m             adds friction, thermal, imbalance, first mode
        cfg_model3.m             adds commutation, bearing, high modes

      models/                    the PHYSICS, one function per effect
        dcm_derivatives.m        state derivatives; calls the functions below
        state_index.m            positions of states, built from the config
        referred_params.m        gearbox referral
        friction_model.m         viscous, Coulomb and Stribeck friction
        commutation_gain.m       commutation ripple and path asymmetry
        bearing_force.m          shot noise bearing contact force

      faults/                    FAULTS as parameter changes
        apply_fault.m            resistive, shorted bar, bearing
        calibrate_commutation.m  regenerates the shorted bar calibration

      sim/                       RUNNING the model
        run_sim.m                fixed step RK4 integration
        service_conditions.m     brake and supply offsets for a run in service
        excitation.m
        service_mounting.m       the mounting of one installation in service             step, locked rotor, coast-down, PRBS, dither
        make_bearing_noise.m     pre-generated bearing noise
        thermal_response.m       slow thermal simulation, run separately
        sample_machines.m        Latin hypercube machine sampler

      sensors/                   MEASUREMENT, what instruments report
        virtual_sensors.m        current, voltage, encoder, accelerometer
        aa_decimate.m            anti-alias filter and decimation
        quantise.m               converter rounding and clipping

      analysis/                  signal analysis, onset, the integrated tool, the hold-out test
        order_amplitude.m        order analysis in the angle domain
        measured_accel.m         acceleration as a real accelerometer reports it
        run_onset.m              onset detection along the onset records (stage 10)
        plot_onset_figures.m     its figures (also the figures-only mode, with a check
                                 against the saved delays)
        integrated_core.m        the integrated tool on one test set: evidence,
                                 competing-cause rules, severity given the type
        run_integrated.m         the integrated tool, cross-validated (stage 13)
        plot_integrated.m        its figures
        run_holdout.m            the hold-out test, trained once, tested once (stage 14)
        plot_holdout.m           its figures

      sensitivity/               the SENSITIVITY ANALYSIS (stage 15)
        sens_variants.m          the 34 variants of the 15 agreed assumptions
        sens_params.m            each variant's parameter sets: reference, twins, bench
        sens_factors.m           doubled spreads, each machine at its own quantile
        sens_subset.m            the fixed 60 sessions, 20 per duty
        sens_session.m           one session under one variant: bench, re-simulated
                                 runs, filters, features
        sens_scores.m            the tracked cells, cross-validated on the 60
        sens_stats.m             the four tracked results for given session weights
        sens_verdict.m           the decision rule, with paired intervals
        run_sensitivity.m        replay check, base check, every variant, the table
        plot_sensitivity.m       one figure per tracked result

      plotting/                  the HOUSE STYLE for every figure
        fig_style.m              greys, the colours of the spectral figures, line
                                 widths, font sizes, the one canvas size
        new_figure.m             one figure, one axes, light theme, off screen, house canvas
        style_axes.m             bold labels at 20, ticks at 18, no title
        style_legend.m           bold legend text at 20
        save_figure.m            save as SVG on the house canvas

      figures/                   the REPORT FIGURES, from saved results and records only
        make_figures.m           results figures: features, grid, estimates, operating-point
                                 maps; the adequacy table
        make_signal_figures.m    time records, PSDs and spectrograms of the measured signals
        make_appendix_c_figures.m  Appendix C derivations and the rated-current figure
        redraw_figures.m         the FIGURES-ONLY mode: run_everything(outdir, 'figures')

      identify/                  CALIBRATION of the reduced models
        identify_machine.m       Models 1 and 2 from one machine's records
        calibrate_ensemble.m     every machine, graded against the truth
        adequacy_test.m          signatures, twin errors and noise for each machine
        adequacy_verdicts.m      final verdicts: pooled floor, fault-specific capability

      datasets/                  the FAULT DATASETS
        make_sessions.m          the session plan shared by all three models
        generate_dataset.m       one model's records, resumable
        check_dataset.m          quality control and physical checks
        make_tuning_sessions.m   normal runs on reserve machines, for tuning
        make_holdout_sessions.m  the hold-out plan: one session per hold-out machine

      estimate/                  STATE ESTIMATION
        ekf_defaults.m           the filter's settings, before tuning
        ekf_twin.m               augmented-state extended Kalman filter on a twin
        ekf_matched_check.m      a twin's filter on that twin's own dataset
        ekf_tune.m               tune on reserve machines, then freeze
        run_ekf_dataset.m        the frozen filters over every dataset run
        ekf_find_failures.m      list the runs on which a filter diverges
        check_estimates.m        fault fingerprints and detection in the estimates
        lsq_estimate.m           batch least squares, linear in the parameters, one record
        run_lsq_dataset.m        least squares over a dataset, checked against the truth

      ensemble/                  the REFERENCE ENSEMBLE
        ensemble_tests.m         virtual test battery for one machine
        run_ensemble.m           batch runner, resumable, with convergence
        export_ensemble.m        the ensemble tables (stage 3)
        plot_ensemble.m          their figures, from those tables

      features/                  FEATURES
        extract_features.m       Sets A and B of a dataset (stage 9)
        features_core.m          the same arithmetic as plain arrays (stages 12 to 15)
        lsq_rows.m, extract_features_lsq.m   Set B from the least-squares estimator
        extract_holdout_features.m           Sets A and B of the hold-out records

      classification/            CLASSIFICATION and severity (stage 9), and
        run_grid_lsq.m           the A+B_LS cells (stage 12)
        fit_predict.m            seeded forest, SVM and forest regression on codes
        tab_cols.m, tab_row.m    tables as plain arrays for the new stages

      verify/                    VERIFICATION, does the code solve its equations
        verify_model1.m ... verify_ensemble.m
        verify_features.m, verify_lsq.m, verify_sensitivity.m,
        verify_holdout.m, verify_integrated.m   the stages after stage 11

      validate/                  VALIDATION, against published measurements
        validate_friction.m      Abdullah et al., no-load friction
        validate_bearing.m       Rohani Bastami and Vahid, defect growth

## Design rules

1. One code base, three configurations. Models 2 and 3 are `cfg` settings,
   not separate implementations, so switching every added effect off must
   reproduce the model below exactly.
2. State positions come from `state_index(cfg)`. Never hard-code an index.
3. Each physical effect is a separate pure function of its arguments.
4. Noise is pre-generated on the integration grid and passed in, never drawn
   inside the derivative function.
5. Derived constants are computed in `params_default.m` from their
   definitions, not typed in, so correcting a source value updates them.
6. After ANY change, run `run_all_verifications`.

## What run_everything writes (all inside its folder)

    machine_####.mat             one file per reference machine (ensemble)
    ensemble_*.csv, *.svg        ensemble tables, convergence and histograms
    calibration.mat, *.csv       calibration of both twins, adequacy verdicts
    datasets/                    session plans, the machine split, every record
    estimates/                   the Kalman filter's estimates for every run
    features/, results/          feature tables; grid, severity, learning, onset;
                                 grid_lsq, integrated, holdout, sensitivity
    estimates/LS_D<d>/           least-squares estimates of every run (stage 12)
    datasets/holdout_*           the hold-out plan and records (stage 14)
    estimates/holdout_*/         both filters and least squares on the hold-out records
    sensitivity/                 the subset, the replay check and one folder per
                                 variant (result.mat with its provenance)
    integrated_summary.csv, holdout_summary.csv, sensitivity_summary.csv
    figures/                     results and signal-analysis figures, and those of
                                 stages 13 to 15 (integrated_*, holdout_*, sensitivity_*);
                                 table_adequacy.csv, table_signal_statistics.csv
    figures/validation/          validation figures
    figures/appendix_c/          Appendix C derivation figures
    build_log_<date>.txt         everything printed, including every table
    figures_log_<date>.txt,      the figures-only mode's log, and the record of each
    FIGURES_REDRAWN.txt          redraw (which code version, when, how many figures)

## Figures

Every figure uses the house style in `plotting/fig_style.m`: one graph per
figure, saved as SVG on one canvas, 20 by 15.5 cm, so figures placed at the
same width in the report print their text at the same size and split figures
line up; light theme regardless of MATLAB's own theme; no titles (the report
caption carries the title); bold axis labels and legends at size 20, tick
numbers at size 18.  Greyscale wherever greyscale works; colour only for the
PSDs, spectrograms and order and envelope spectra (normal blue, fault orange;
in the model PSDs the reference blue, Model 2 green, Model 1 magenta;
spectrograms in parula), each line keeping its own line style as well.
Where one set of axes would carry too much, the graphs are split into
separate figures on the same axes, to be placed side by side.  Change a
value in `fig_style` and every figure follows.

To redraw every figure of a completed run without recomputing anything:

    run_everything('C:\dcm_final', 'figures')

It reads only that folder's saved results and records, removes the earlier
figure files, draws every figure again with the code installed now, writes
`figures_log_<date>.txt` and records in `FIGURES_REDRAWN.txt` which version
drew them.  A few minutes.  It accepts a run completed by version 1.0.56,
1.0.57, 1.0.58, 1.0.59, 1.0.60 or 1.0.61, whose results are the same.
